<?PHP
include('libs/Htmlhelper.php');
$sm = '';
$options = array ('searching','applications','extensions');
$name="myselect";
$multi = "multiple";
$sm = Htmlhelper::selectMulti($options,$name,$multi,2,'my_class','sel_id');

$tb = Htmlhelper::table(3,6,'my_table',1);

$values = array ('left','center','right');
$ol_ul = 'ul';
$ul = Htmlhelper::olulgeneration($ol_ul,$values);

$m = array('Honda','Hummer','BMW','Toyota');
$s = array('AN','TU-144','Boing','SU');
$t = array('Tiger','Pantera','Т-34','Al Halid');
$TH = array('Cars'=>$m, 'Aircrafts'=>$s, 'Tanks'=>$t);
$dl = Htmlhelper::dL($TH);

$options = array('animals','peoples','someone',);
$rb = Htmlhelper::radioButton('myradio',$options,1);

$options = array('red','green','blue',);
$chb = Htmlhelper::checkboxes('myradio',$options,2);

include('templates/index.php');

