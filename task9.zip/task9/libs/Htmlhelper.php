<?PHP
class Htmlhelper
{
    public static $HL;
    public static $lnk;

    static function selectMulti($options, $name, $multi, $chek=1, $class,$id)
    {
        $res = "<select id=\"" . $id . "\" class=\"" . $class . 
        "\" name=\"" . $name . "\" $multi >";
        $c = 0;
        foreach ($options as $opt)
        { 
            $c++;
            if ($c == $chek)
            {
                $res .= "<option selected>$opt</option>" . "\n\r";
            } else {
                $res .= "<option>$opt</option>"."\n\r";
            }
        }
        $res .= "</select>" . "\n\r";
        return $res;
    }

    static function table($row,$col,$class,$br=0)
    {
        $rows = $row; 
        $cols = $col;
        $table = '';
        $table = "<table border=$br class=\"" . $class . "\" >" . "\n\r";
        for ($tr = 1; $tr <= $rows; $tr++)
        {
            $table .= '<tr>';
            for ($td = 1; $td <= $cols; $td++)
            {
                $table .= '<td>'. $tr*$td .'</td>';
            }
			$table .= '</tr>'."\n\r";
        }
        $table .= '</table>'."\n\r";
        return $table;
    }

    static function olulgeneration($ol_ul,$values)
    {   
        $res = "<$ol_ul>"."\n\r";
        foreach($values as $val)
        {   
            $val = htmlentities($val);
            $res .= "<li>$val</li>" . "\n\r";
        }
        $ol_ul = htmlentities($ol_ul);
        $res .= "</$ol_ul>" . "\n\r";
        return $res;
    }

    static function dL($values)
    {
        $res = "<dl>" . "\n\r";
        foreach ($values as $key=>$val)
        {   
            $key = htmlentities($key);
            $res .= "<dt>$key</dt>" . "\n\r";
            if (is_array($val)) 
            {
                foreach ($val as $s) 
                {
                    $s = htmlentities($s);
                    $res .= "<dd>$s</dd>" . "\n\r";
                }
            }
        }
        $res .= "</dl>" . "\n\r";
        return $res;
    }

    static function radioButton($name, $options, $default = '')
    {


            $name = htmlentities($name);
            $res = '';
            foreach ($options as $value=>$label)
            {
              $value = htmlentities($value);
              $res .= '<input type="radio" ';
              if ($value == $default)
                $res .= ' checked="checked" ';
              $res .= ' name="' . $name . '" value="' . $value . '" />' . $label . '<br />'."\n";
            };

        return $res;
    }


    static function checkboxes($name, $items, $default = '')
    {

            $name = htmlentities($name);
            $res = '';
            foreach ($items as $value=>$label)
            {
              $value = htmlentities($value);
              $res .= '<input type="checkbox" ';
              if($value == $default)
                $res .= ' checked="checked" ';
              $res .= ' name="' . $name . '" value="' . $value . '" />' . $label . '<br />'."\n";
            }


        return $res;
    }
    
}

?>