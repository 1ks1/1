<?PHP
echo "<br /><hr /><br />"."\n\r";
$options = array ('searching','applications','extensions');
$name="myselect";
$multi = "multiple";
echo Htmlhelper::selectMulti($options,$name,$multi);
echo "<br /><hr /><br />";
echo Htmlhelper::table(3,6);
echo "<br /><hr /><br />"."\n\r";
$values = array ('left','center','right');
$ol_ul = 'ul';
echo Htmlhelper::olulgeneration($ol_ul,$values);
echo "<br /><hr /><br />"."\n\r";
$m = array('Honda','Hummer','BMW','Toyota');
$s = array('AN','TU-144','Boing','SU');
$t = array('Tiger','Pantera','Т-34','Al Halid');
$TH = array('Cars'=>$m, 'Aircrafts'=>$s, 'Tanks'=>$t);
echo Htmlhelper::dL($TH);
echo "<br /><hr /><br />"."\n\r";
$options = array('animals','peoples','someone',);
echo Htmlhelper::radioButton('myradio',$options,1);
echo "<br /><hr /><br />"."\n\r";
$options = array('red','green','blue',);
echo Htmlhelper::checkboxes('myradio',$options,2);
?>