<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" href="csss/main.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>HTML helper</title>
</head>
<body>

<?PHP
echo $sm;
echo "<br /><hr /><br />";

echo $tb;

echo "<br /><hr /><br />"."\n\r";
echo $ul;
echo "<br /><hr /><br />"."\n\r";

echo $dl;
echo "<br /><hr /><br />"."\n\r";

echo $rb;
echo "<br /><hr /><br />"."\n\r";

echo $chb;
?>

</body>
</html>