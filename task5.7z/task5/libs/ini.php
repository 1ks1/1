<?PHP
include ('interface.php');


$cl = new myini;


if($_POST['myData']=="dataWrite")
{
    $key = "data_test";
    $val = $_POST['someData'];
    $cl->saveData($key, $val);

}
if($_POST['myData']=="dataRead")
{
    $key = "data_test";
    $val = $cl->getData($key);
}
if($_POST['myData']=="dataDel")
{
    $key = "data_test";
    $cl->deleteData($key)
}




class myini
{
    protected $a;

    public function setA()
    {
        $this->a = $a;
    }

    public function getA()
    {
        return $this->a;
    }



    public function getData($key)
    {
        $a = $_SESSION[$key];
        return $a;
    }
    public function saveData($key, $val)
    {
        $_SESSION[$key]=$val;
        if($_SESSION[$key] == $val)
        {
            return true;
        }
            return false;
    }
    public function deleteData($key)
    {
        unset($_SESSION[$key]);
        if(! isset($_SESSION[$key]))
        return true;
    }



}

?>
