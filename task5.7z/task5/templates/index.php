<?PHP


?>
<form method="POST">
Any data <input type="text" name="someData" value="someData">
w<input type="radio" name="myData" value="dataWrite">
r<input type="radio" name="myData" checked="true" value="dataRead">
d<input type="radio" name="myData" value="dataDel">
<input type="submit" name="submit" value="Enter"><hr />

ini<input type="radio" name="typeData" checked="true" value="ini">
json<input type="radio" name="typeData" value="json">
session<input type="radio" name="typeData" value="session">
coockies<input type="radio" name="typeData" value="coockies"><hr />

</form>
<?PHP
    echo "debug:<br />";
    if($_POST)
    print_r($_POST);
?>