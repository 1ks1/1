<?PHP


$mycookies = new MyCookies;
if (isset($_POST['submit'])&&($_POST['typeData'] == "coockies"))
{
    
        if($_POST['myData']=="dataWrite")
        {
            $key = $_POST['someKey'];
            $val = $_POST['someData'];
            if($mycookies->saveData($key, $val))
            {
                echo "<br />cookie $key = $val is set<br />";
            }else{
                echo "<br />cookie $key = $val error set />";
            }
        }
        if($_POST['myData']=="dataRead")
        {
            $key = $_POST['someKey'];
            echo $mycookies->getData($key);
        }
        if($_POST['myData']=="dataDel")
        {
            $key = $_POST['someKey'];
            if($mycookies->deleteData($key))
            {
                echo "cookie $key deleted";
            } else 
            {echo "$key deleting error";};
        }
}
?>