<?PHP
class mysession implements iWorkData
{
    protected $result;


    public function getRes()
    {
        return $this->result;
    }

    //read from ini
    public function getData($key)
    {
        if(strlen($key)>0)
        {
            if(isset($_SESSION[$key]))
            {
            $this->result = $_SESSION[$key];
            }else{
            $this->result = 'Error! No such session key';
            }
        }else{
            $this->result = "Error! Empty key value";
        }
    }

    //save to ini
    public function saveData($key, $val)
    {
        if(strlen($key)== 0 || strlen($val)== 0)
        {
            $this->result = "Error! Data empty!";
        }else{
            $_SESSION[$key]=$val;
            if($_SESSION[$key] == $val)
            {
                $this->result="key ($key) saved to SESSION";
                return true;
            }else{return false;}
        }
    }

    //delete from ini
    public function deleteData($key)
    {
        if(isset($_SESSION[$key]))
        {   
            unset($_SESSION[$key]);
            $this->result="Ok";
        }else{
            $this->result=$key." not exists";
        }
        
    }



}

$cl = new mysession;
if (isset($_POST['submit'])&&($_POST['typeData'] == "session"))
{
    
        if($_POST['myData']=="dataWrite")
        {
            $key = $_POST['someKey'];
            $val = $_POST['someData'];
            $cl->saveData($key, $val);
        }
        if($_POST['myData']=="dataRead")
        {
            $key = $_POST['someKey'];
            $val = $cl->getData($key);
        }
        if($_POST['myData']=="dataDel")
        {
            $key = $_POST['someKey'];
            $cl->deleteData($key);
        }
}
?>
