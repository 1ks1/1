<?PHP


class MyCookies implements iWorkData
{
    public function saveData($key, $val)
    {
        return (setcookie($key, $val));
    }
    public function getData($key)
    {
        if ($_COOKIE[$key])
        {
            return ($_COOKIE[$key]);
        }
        else
        {
            return "key not exists";
        }
        
    }
    public function deleteData($key)
    {
        return SetCookie($key,"");
    }
}

?>