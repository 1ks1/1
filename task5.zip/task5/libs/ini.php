<?php

class Myini implements iWorkData
{
    public function saveData($key, $val)
    {

    }
    public function getData($key)
    {

    }
    public function deleteData($key)
    {

    }
}


//$arr = parse_ini_file("settings.ini");
//print_r($arr);
?>