<?php

class Myini implements iWorkData
{
    protected $key;
    protected $val;
    protected $res;


    public function saveData($key, $val)
    {
        $file = array();
        $inifile='data.ini';
        if(file_exists($inifile)&&strlen($inifile)>0)
        {
            $file = parse_ini_file($inifile);  
            $file[$key] = $val;
        }else{
            $file[$key] = $val;            
        }
        $f = fopen($inifile, "w");
        fwrite ( $f, "[Test] \r\n" );
        foreach ($file as $key => $data)
        {
            fwrite ( $f, "$key = $data \r\n" );
        }
        fclose ($f);
 
        return $key;
    }
    public function getData($key)
    {
        $file = array();
        $inifile='data.ini';
        $res ='';
        if(file_exists($inifile)&&strlen($inifile)>0)
        {
            $file = parse_ini_file($inifile);
            foreach($file as $k=>$v)
            {
                if($key == $k)
                {
                    $res = $v;
                    break;
                }else{
                    $res = 'NO KEY EXISTS';
                }
                
            }
        }

        return $res;
    }
    public function deleteData($key)
    {


        $file = array();
        $inifile='data.ini';
        $res ='';
        if(file_exists($inifile)&&strlen($inifile)>0)
        {
            $file = parse_ini_file($inifile);
            foreach($file as $k=>$v)
            {
                if($key == $k)
                {
                    unset($file[$key]);
                    $res = "Deleted $key";
                    break;
                }else{
                    $res = 'NO KEY EXISTS';
                }
                
            }
        }

        return $res;
    }
}

?>