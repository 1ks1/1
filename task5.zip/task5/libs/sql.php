<?PHP
class MySql implements iWorkData
{
    protected $key;
    protected $val;
    protected $sqlclass;

    function __construct()
    {
        $this->sqlclass = new sql;
    }

    public function saveData($key, $val)
    {
        echo '===sqlSAVE DATA===';
        $this->sqlclass->dbConn();
        $query = "INSERT INTO TEST (id,name) VALUES ($key,'$val')";
        $res = mysql_query($query);
        
        if ($res == true)
        {
            $result = $res;
        }else{
            $result = mysql_error ( $this->sqlclass->link);
        }
        $this->sqlclass->dbClose();
        return $result;

    }


    public function getData($key)
    {
        echo '===sqlGET DATA===';
        $this->sqlclass->dbConn();
        $query = "SELECT * FROM TEST WHERE id=$key";
        $res = mysql_query($query);
        if($res !== false)
        {
            $rr = '';
            $arr = mysql_fetch_assoc($res);
            if(is_array($arr))
            {
                foreach($arr as $v)
                {
                    $rr = $v;
                }
                $result = $rr;
            }else{
                $result = mysql_error ( $this->sqlclass->link);
            }
            
        }else{
            $result = mysql_error ( $this->sqlclass->link);
        }
        $this->sqlclass->dbClose();
        return $result;
    }



    public function deleteData($key=11)
    {
        echo '===sqlDEL DATA===';
        $this->sqlclass->dbConn();
        $query = "DELETE FROM TEST WHERE id=$key";
        $res = mysql_query($query);
        
        if ($res == true)
        {
            $result = $res;
        }else{
            $result = mysql_error ( $this->sqlclass->link);
        }
        $this->sqlclass->dbClose();
        return $result;
    }
}

class sql extends MySql
{
    protected $host;
    protected $user;
    protected $passwd;
    protected $db;
    protected $link;

    function __construct()
    {
        $this->host = HOST;
        $this->db = DATABASE;
        $this->passwd = PASSWD;
        $this->user = USER;
    }

        function dbConn()
        {
            $this->link = mysql_connect(HOST, USER, PASSWD);
            mysql_select_db(DATABASE, $this->link) or die ($result = 'I cant select '.
            DATABASE.' : '.mysql_error());
            mysql_query("set names 'utf8'");
            return $this->link;
        }

        function dbClose()
        {
            return mysql_close ($this->link);
        }

        function query($m)
        {
            switch($m)
            {
                case 'read':
                $query=$this->getData($key);
                break;
                case 'write':
                $query=$this->saveData($key, $val);
                break;
                case 'del':
                $query=$this->deleteData($key);
                break;
            }

        
            $this->link = $this->dbConn();
            if($query !== false)
            {
                if (!$l) 
                {
				    die($result ='Wrong query: ' . mysql_error());
			    }else{
                    $res = mysql_query($query);
                       $st = '';
                        $arr = mysql_fetch_assoc($res);
                        

                        foreach($arr as $key=>$v)
                        {
                            $st .= $v;
                        }

                        //if SQL ERROR
                        $r = $st."<hr />".mysql_error($l)."<br />";
                    return $r;
                    
                }
            }else{$result = 'Error! Coz [*] is danied.';}
            return $result;
            
        }
}
?>