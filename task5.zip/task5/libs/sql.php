<?PHP
class MySql implements iWorkData
{
    protected $key;
    protected $val;
    protected $sqlclass;
    protected $table;
    

    function __construct()
    {
        $this->sqlclass = new sql;
    }

    public function saveData($key='a', $val=0)
    {   
        $this->sqlclass->dbConn();                  //connect
        $this->sqlclass->if_table_create(TABLE);    //create table if not exists
        $qquery = "INSERT INTO ".TABLE." (a,b) VALUES ('$key','$val')";
            $res = mysql_query($qquery);            //saving data
            if ($res == true)
            {
                $result = true;
            }else{
                $result = mysql_error ( $this->sqlclass->link);
            }

            $this->sqlclass->dbClose();             //disconect
        return $result;

    }


    public function getData($key)
    {
        $this->sqlclass->dbConn();                      //connect db
        $this->sqlclass->if_table_create(TABLE);
        $query = "SELECT b FROM ".TABLE." WHERE a='$key'";
        $res = mysql_query($query);                     //get (a-key,b-value) data from table
        if($res !== false)
        {
            $rr = '';
            $arr = mysql_fetch_assoc($res);
            if(is_array($arr))
            {
                foreach($arr as $v)
                {
                    $rr = $v;
                }
                $result = $rr;
            }else{
                $result = mysql_error ( $this->sqlclass->link);
            }
            
        }else{
            $result = mysql_error ( $this->sqlclass->link);
        }
        $this->sqlclass->dbClose();
        return $result;
    }



    public function deleteData($key=11)
    {
        $this->sqlclass->dbConn();
        $this->sqlclass->if_table_create(TABLE);
        $query = "DELETE FROM ".TABLE." WHERE a='$key'";
        $res = mysql_query($query);
        
        if ($res == true)
        {
            $result = $res;
        }else{
            $result = mysql_error ( $this->sqlclass->link);
        }
        $this->sqlclass->dbClose();
        return $result;
    }
}

class sql extends MySql
{
    protected $host;
    protected $user;
    protected $passwd;
    protected $db;
    protected $link;

    function __construct()
    {
        $this->host = HOST;
        $this->db = DATABASE;
        $this->passwd = PASSWD;
        $this->user = USER;
    }


    function if_table_create($table)
    {
        $sqlq = 'CREATE TABLE IF NOT EXISTS '.
        $table.' (a varchar(20),
                b varchar(20),
                PRIMARY KEY(a))';
        $res = mysql_query($sqlq);
    }

        function dbConn()
        {
            $this->link = mysql_connect(HOST, USER, PASSWD);
            mysql_select_db(DATABASE, $this->link) or die ($result = 'I cant select '.
            DATABASE.' : '.mysql_error());
            mysql_query("set names 'utf8'");
            return $this->link;
        }

        function dbClose()
        {
            return mysql_close ($this->link);
        }

           
}
?>