<?PHP

class MyJson implements iWorkData
{
    protected $k;
    protected $v;
    protected $res;

    function __construct()
    {
        
    }

    function getRes()
    {
        return $this->res;
    }
    function setRes($j)
    {
        $this->res=$j;
    }


    public function saveData($key, $val)
    {
        
        if(file_exists('data.json')&&strlen('data.json')>0)
        {
            $file = file_get_contents('data.json');  
            $taskList = json_decode($file,TRUE);                           
            unset($file); 
            $taskList = array_replace ( $taskList ,  array($key => $val) );
        }else{
            $taskList = array($key => $val);         
            file_put_contents('data.json',json_encode($taskList));        
            unset($taskList); 
        }
        
            if(json_last_error ())
            {
                $this->res = json_last_error ();
            }else{
                $this->res = true;
            }
        return $this->res;
    }
    public function getData($key)
    {
        $j = file_get_contents('data.json' );
        $data = json_decode($j,true);
        print_r($data);
        if( $j != false && !is_null($data))
        {
            foreach($data as  $e)
            {
                $data = array( $e);  
                    //$data[] = $e;
            }
            print_r($data);
            return $data;
        }
    }
    public function deleteData($key)
    {

        $j = file_get_contents('data.json');
        $data = json_decode($j,true);
        if( $j != false && !is_null($data))
        {
            foreach($data as $k => $e)
            {   
                if(!$key=="")
                {
                    if($k == $key)
                    {   
                        $data[]  = array($k => $e);
                    }
                }else{
                    $data  = array($k => $e);
                    //$data[] = $e;
                }
            }unset($array[1]);
            return $data;
        }

        
    }
}

$json = new MyJson;
if($_POST)
{
    if(($_POST['typeData']=='json')&&($_POST['myData']=='dataWrite'))
    {
        $json->saveData($_POST['someKey'], $_POST['someData']);
    }

    if(($_POST['typeData']=='json')&&($_POST['myData']=='dataRead'))
    {
        $json->setRes($json->getData($_POST['someKey']));
    }
}

?>