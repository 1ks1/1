<?PHP
session_start();
include('libs/connector.php');
if($_POST)
if($_POST['typeData'] == 'ini')
{
    $ini = new Myini;
    switch ($_POST['myData'])
    {
        case 'dataWrite': 
        $dWrite = $ini->saveData($_POST['someKey'], $_POST['someData']);
        break;
        case 'dataRead': 
        $dRead = $ini->getData($_POST['someKey']);
        break;
        case 'dataDel': 
        $dDel = $ini->deleteData($_POST['someKey']);
        break;
    }
}


if($_POST)
if($_POST['typeData'] == 'sql')
{
    $sql = new MySql;
    switch ($_POST['myData'])
    {
        case 'dataWrite': 
        $dWrite = $sql->saveData($_POST['someKey'], $_POST['someData']);
        break;
        case 'dataRead': 
        $dRead = $sql->getData($_POST['someKey']);
        break;
        case 'dataDel': 
        $dDel = $sql->deleteData($_POST['someKey']);
        break;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <?PHP
        include('templates/index.php');
    ?>
</body>
</html>