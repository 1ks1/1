<?PHP
session_start();
include('libs/connector.php');
if($_POST)
if($_POST['typeData'] == 'ini')
{
    $ini = new Myini;
    switch ($_POST['myData'])
    {
        case 'dataWrite': 
        $dWrite = "ini:".$ini->saveData($_POST['someKey'], $_POST['someData']);
        break;
        case 'dataRead': 
        $dRead = "ini:".$ini->getData($_POST['someKey']);
        break;
        case 'dataDel': 
        $dDel = "ini:".$ini->deleteData($_POST['someKey']);
        break;
    }
}


if($_POST)
if($_POST['typeData'] == 'sql')
{
    $sql = new MySql;
    switch ($_POST['myData'])
    {
        case 'dataWrite': 
        $dWrite = "sql:".$sql->saveData($_POST['someKey'], $_POST['someData']);
        break;
        case 'dataRead': 
        $dRead = "sql:".$sql->getData($_POST['someKey']);
        break;
        case 'dataDel': 
        $dDel = "sql:".$sql->deleteData($_POST['someKey']);
        break;
    }
}
$datas ='';
if ($_SESSION)
{   
    foreach ($_SESSION as $key => $value1)
    $datas[] = $key;
    $datas[] = "<br /> \r\n";
    $datas[] = $cl->getRes()."\r\n";
    if (is_array($datas))
    $datas = implode($datas);
  
} 

if ($_COOKIE)
{   
    foreach ($_COOKIE as $key => $val)
    $datac[] = $key;
    if (is_array($datac))
    $datac = implode($datac);
}
$datas2 ='';
if (isset($dWrite))
$datas2[] = "Writing = ".$dWrite."<br />";
if (isset($dRead))
$datas2[] = "Reading = ".$dRead."<br />";
if (isset($dDel))
$datas2[] = "Del = ".$dDel."<br />";
if (is_array($datas2))
$datas2 = implode($datas2);

        include('templates/index.php');
 
