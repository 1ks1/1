<?PHP
session_start();
include('libs/connector.php');
if($_POST)
if($_POST['typeData'] == 'ini')
{
    $ini = new Myini;
    switch ($_POST['myData'])
    {
        case 'dataWrite': 
        $dWrite = "ini:".$ini->saveData($_POST['someKey'], $_POST['someData']);
        break;
        case 'dataRead': 
        $dRead = "ini:".$ini->getData($_POST['someKey']);
        break;
        case 'dataDel': 
        $dDel = "ini:".$ini->deleteData($_POST['someKey']);
        break;
    }
}


if($_POST)
if($_POST['typeData'] == 'sql')
{
    $sql = new MySql;
    switch ($_POST['myData'])
    {
        case 'dataWrite': 
        $dWrite = "sql:".$sql->saveData($_POST['someKey'], $_POST['someData']);
        break;
        case 'dataRead': 
        $dRead = "sql:".$sql->getData($_POST['someKey']);
        break;
        case 'dataDel': 
        $dDel = "sql:".$sql->deleteData($_POST['someKey']);
        break;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <?PHP
        include('templates/index.php');
    ?>
</body>
</html>