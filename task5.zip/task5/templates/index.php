<form method="POST">
Key <input type="text" name="someKey" value="">
Value <input type="text" name="someData" value="">
w<input type="radio" name="myData" value="dataWrite">
r<input type="radio" name="myData" checked="true" value="dataRead">
d<input type="radio" name="myData" value="dataDel">
<input type="submit" name="submit" value="Enter"><hr />

session<input type="radio" name="typeData" checked="true" value="session">
json<input type="radio" name="typeData" value="json">
ini<input type="radio" name="typeData" value="ini">
coockies<input type="radio" name="typeData" value="coockies"><hr />
</form>
<p><?PHP 


if($_SESSION)
{   
    echo '<b style="color:green;">SESSION keys:</b><br/>';
    foreach ($_SESSION as $key => $value1)
    echo " $key ";
    echo "<br />";
    echo $cl->getRes();
    echo "<hr />"; 
}
if($_COOKIE)
{   
    echo '<b style="color:green;">COOKIE keys:</b><br/>';
    foreach ($_COOKIE as $key => $val)
    echo " $key ";
    echo "<br />";
    echo "<hr />"; 
}
?></p>
<?PHP
////DEBUGGING

    echo '<b style="color:#f00;">debug info</b>:<br />';
    echo "<hr />POSTS data:<br />";
    if($_POST)
    print_r($_POST);
    echo "<hr />SESSION data:<br />";
    if($_SESSION)
    print_r($_SESSION);
    echo "<hr />COOKIE data:<br />";
    if($_COOKIE)
    print_r($_COOKIE);
    echo "<hr />JSON data:<br />";
    if(file_exists('data.json')&&strlen('data.json')>0)
    {
        print_r(json_decode(file_get_contents('data.json'),true));
        
    }

?>