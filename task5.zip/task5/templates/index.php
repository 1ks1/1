<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form method="POST">
Key <input type="text" name="someKey" value="">
Value <input type="text" name="someData" value="">
w<input type="radio" name="myData" value="dataWrite">
r<input type="radio" name="myData" checked="true" value="dataRead">
d<input type="radio" name="myData" value="dataDel">
<input type="submit" name="submit" value="Enter"><hr />

session<input type="radio" name="typeData" checked="true" value="session">|
json<input type="radio" name="typeData" value="json">|
ini<input type="radio" name="typeData" value="ini">|
coockies<input type="radio" name="typeData" value="coockies">|
sql<input type="radio" name="typeData" value="sql"><hr />
</form>
<p>
    <b>SESSION keys:</b><br/>
    <?PHP echo ($datas); ?>
    <hr />
    <b>COOKIE keys:</b><br/>
    <?PHP echo ($datac); ?>
    <br />
    <hr />
</p>

<?PHP
echo ($datas2);
?>
</body>
</html>
<?PHP
////DEBUGGING

/*
    echo '<b style="color:#f00;">debug info</b>:<br />';
    echo "<hr />POSTS data:<br />";
    if($_POST)
    print_r($_POST);
    echo "<hr />SESSION data:<br />";
    if($_SESSION)
    print_r($_SESSION);
    echo "<hr />COOKIE data:<br />";
    if($_COOKIE)
    print_r($_COOKIE);
    echo "<hr />JSON data:<br />";
    if(file_exists('data.json')&&strlen('data.json')>0)
    {
        print_r(json_decode(file_get_contents('data.json'),true));
        
    }
*/
?>