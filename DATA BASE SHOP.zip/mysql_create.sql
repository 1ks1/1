CREATE TABLE `books` (
	`id` int(11) NOT NULL,
	`bookname` varchar(20) NOT NULL UNIQUE,
	`price` FLOAT(20) NOT NULL,
	`iso` varchar(50) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `autors` (
	`id` int(11) NOT NULL,
	`autorname` varchar(20) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

CREATE TABLE `ba` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_book` int(11) NOT NULL,
	`id_autor` int(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `deleted_books` (
	`id` int(11) NOT NULL,
	`bookname` varchar(20) NOT NULL,
	`price` FLOAT(20) NOT NULL,
	`iso` varchar(50) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Clients` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(20) NOT NULL,
	`fname` varchar(20) NOT NULL,
	`email` varchar(50) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Cart` (
	`id` int(11) NOT NULL,
	`id_client` int(11) NOT NULL,
	`id_book` int(11) NOT NULL,
	`count` int(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `genres` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`genre` varchar(11) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

CREATE TABLE `bg` (
	`id` bigint NOT NULL AUTO_INCREMENT,
	`id_book` int(11) NOT NULL,
	`id_genre` int(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Orders` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_client` int(11) NOT NULL,
	`id_cart` int(11) NOT NULL UNIQUE,
	`order_data_for` DATE(11) NOT NULL UNIQUE,
	`order_data_created` DATE(11) NOT NULL,
	`summ` FLOAT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

ALTER TABLE `ba` ADD CONSTRAINT `ba_fk0` FOREIGN KEY (`id_book`) REFERENCES `books`(`id`);

ALTER TABLE `ba` ADD CONSTRAINT `ba_fk1` FOREIGN KEY (`id_autor`) REFERENCES `autors`(`id`);

ALTER TABLE `Cart` ADD CONSTRAINT `Cart_fk0` FOREIGN KEY (`id_client`) REFERENCES `Clients`(`id`);

ALTER TABLE `Cart` ADD CONSTRAINT `Cart_fk1` FOREIGN KEY (`id_book`) REFERENCES `books`(`id`);

ALTER TABLE `bg` ADD CONSTRAINT `bg_fk0` FOREIGN KEY (`id_book`) REFERENCES `books`(`id`);

ALTER TABLE `bg` ADD CONSTRAINT `bg_fk1` FOREIGN KEY (`id_genre`) REFERENCES `genres`(`id`);

ALTER TABLE `Orders` ADD CONSTRAINT `Orders_fk0` FOREIGN KEY (`id_client`) REFERENCES `Clients`(`id`);

ALTER TABLE `Orders` ADD CONSTRAINT `Orders_fk1` FOREIGN KEY (`id_cart`) REFERENCES `Cart`(`id`);

