var port = 80;
var express = require('express');
var bodyParser = require('body-parser');
var urlencodeparser = bodyParser.urlencoded({extends:false});
var server = express();
var somedata = [];

server.use(bodyParser.json());

server.use('/', express.static('public'));

server.get('/test.json', (req, res) => {
    res.json({
        test: 'OK'
    });
});

// server.use(function (request, response) {
//     console.log(request.body);
//     response.sendFile(__dirname + "/public/404.html");
// });

server.all('/all_data', (req, res) => {
    res.send('All data OK');
})

server.post('/set_test', (req, res) => {
    console.log(req.body);
    res.json(req.body);
});

server.post('/', urlencodeparser, (req, res) => {
    console.log(req.body.text);
    somedata.push({test:req.body.text});
    res.sendFile(__dirname + "/public/index.html");
});

server.post('/vars', urlencodeparser, (req, res) => {
    console.log(somedata);
    res.send(somedata);
});

server.listen(port, () => {
    console.log('Server runned on port:', port);
});
