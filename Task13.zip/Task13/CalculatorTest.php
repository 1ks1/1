<?PHP
require 'Calculator.php';
 
class CalculatorTests extends PHPUnit_Framework_TestCase
{
    private $calculator;
 
    protected function setUp()
    {
        $this->calculator = new Calculator(4,2);
    }
 
    protected function tearDown()
    {
        $this->calculator = NULL;
    }
 
    public function testplus()
    {
        $result = $this->calculator->plus();
        $this->assertEquals(6, $result);
    }
	
	    public function testminus()
    {
        $result = $this->calculator->minus();
        $this->assertEquals(2, $result);
    }
	
	    public function testdivision()
    {
        $result = $this->calculator->division();
        $this->assertEquals(2, $result);
    }
	
	    public function testmultiplication()
    {
        $result = $this->calculator->multiplication();
        $this->assertEquals(8, $result);
    }
	
	  public function testsquare()
    {
        $result = $this->calculator->square();
        $this->assertEquals(2, $result);
    }
	
	  public function testonDivTo()
    {
        $result = $this->calculator->onDivTo();
        $this->assertEquals(0.25, $result);
    }
	
		public function testsetMem()
    {
        $result = $this->calculator->setMem(15);
        $this->assertEquals(15, $result);
		return $result;
    }
	
		public function testmemClear()
    {
        $result = $this->calculator->memClear();
        $this->assertTrue($result);
    }
	
		public function testmemPlus()
    {
		$this->calculator->setMem(4);
        $result = $this->calculator->memPlus();
        $this->assertEquals(8, $result);
    }
	
	
}