<?PHP
class Htmlhelper
{
    public static $HL;
    public static $lnk;



    static function selectMulti($options,$name,$multi)
    {
        $res = "<select name=\"$name\" $multi >";
        foreach($options as $opt)
        {
            $res .= "<option>$opt</option>";
        }
        $res .= "</select>";
        return $res;
    }

    static function radioButton($cheked,$name,$value)
    {

        return $res;
    }


}

?>