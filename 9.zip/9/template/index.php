<?PHP
////SELECT MULTI
$options = array ('1 option','2 option','3 option');
$name="myselect";
$multi = "multiple";
echo Htmlhelper::selectMulti($options,$name,$multi);
?>