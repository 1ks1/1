<?PHP
    /*define('folder','/home/user11/public_html/PHP/task1/files');
    //define('workfolder','/home/user11/public_html/PHP/task1/');
    //define('template','/home/user11/public_html/PHP/task1/template/index.php');
    //define('folder','C:/Users/Dude/Desktop/USBWebserver v8.6/root/files');
    */
    define('root_folder','C:/Users/Dude/Desktop/USBWebserver v8.6/root/');
    define('upload_folder','files/');
    
?>