<?PHP
    phpinfo();
?>