<?PHP
///// IF UPLOADING FILE /////
if($_FILES){
$res=upload_myfile();
if ($res>0){
    //get error code text func
    $s = upl_err($res);
    echo "<hr />$s<hr />";
}else{
    $url=$_SERVER['PHP_SELF'];
    header("Location: $url");
}

//relocation header if it nead
//$url=$_SERVER['PHP_SELF'];
//header("Location: $url");
}


///// IF DELETING /////
if (isset($_GET['f'])){
    $file = $_GET['f'];
    $err = del_file($file);
    if ($err == 0){
        $url=$_SERVER['PHP_SELF'];
        header("Location: $url");
    }else{
        echo "Error! $err";
    }
}
//executing files for win
if (isset($_GET['e'])){
    $file = $_GET['e'];
    start_exe($file);
}




///// FILELIST SHOW /////
        //just folder name
        $uf = upload_folder;
        //fuul path of upload folder
        $dirpath = root_folder.$uf;
            //if uploaddir not exists then create
            if (!is_dir($dirpath)) {
                mkdir($dirpath, 0777, true);
            }
        $cdir = scan_my_dir($dirpath);
        $count = 0;
        if (count($cdir)>2){
            echo (count($cdir)-2)." file(s) total";
            //generate table list
                    foreach ($cdir as $value){
                        if ($value != ".." && $value != "."){
                            $count ++;
                            $fp = $dirpath.$value;
                            $fpi = file_perm_info($fp);
                            $dfile = $uf.$value;
                            $a = filesize($fp);
                            $a = ReadableSize($a);
                            echo "<tr>";
                            echo "<td>$count </td><td>".$fpi."</td><td>$value </td><td>$a</td>";
                            echo "<td><a href=\"index.php?f={$value}\">Delete</a></td>";
                            echo "<td><a href=\"index.php?e={$value}\" title=\"for windows exe\" >Start</a></td>";
                            echo "<td><a href=\"{$dfile}\">Download</a></td>";
                            echo "</tr>";
                        }
                    }  
        //if files count is 0 ZERRO
        }else{echo "[-]";}
?>     