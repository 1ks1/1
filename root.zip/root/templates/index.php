<?PHP
///IF UPLOADING
if($_FILES){
$res=upload_myfile();
if ($res>0){
    $s = upl_err($res);
    echo "<hr />$s<hr />";
}else{echo "File uploaded!";}

//$url=$_SERVER['PHP_SELF'];
//header("Location: $url");
}


//IF DELETING
if (isset($_GET['f'])){
    $file = $_GET['f'];
    del_file($file);
}
if (isset($_GET['e'])){
    $file = $_GET['e'];
    start_exe($file);
}




//FILELIST SHOW
        $dirpath = upload_folder;
            //if uploaddir not exists
            if (!is_dir($dirpath)) {
                mkdir($dirpath, 0777, true);
            }
        $cdir = scan_my_dir($dirpath);
        $count = 0;
        if (count($cdir)>2){
            echo (count($cdir)-2)." file(s) total";
            //generate table list
            echo "<tt>";
            echo "<td>#</td><td>fileperms</td><td>name</td><td>size</td><td>remove</td><td>execute it</td>";
            echo "</tt>";
                    foreach ($cdir as $value){
                        if ($value != ".." && $value != "."){
                            $count ++;
                            $fpi = file_perm_info($dirpath.$value);
                            $a = filesize($dirpath.$value);
                            $a = ReadableSize($a);
                            echo "<tr>";
                            echo "<td>$count </td><td>".$fpi."</td><td>$value </td><td>$a</td>";
                            echo "<td><a href=\"index.php?f={$value}\">Delete</a></td>";
                            echo "<td><a href=\"index.php?e={$value}\">Start</a></td>";
                            echo "</tr>";
                        }
                    }  
        //if files count is 0 ZERRO
        }else{echo "[-]";}
?>     