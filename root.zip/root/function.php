<?php
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

function ReadableSize($size){
    $base = log($size) / log(1024);
    $suffix = array("", "KB", "MB", "GB", "TB");
    $f_base = floor($base);
    return round(pow(1024, $base - floor($base)), 1) . $suffix[$f_base];
  }

function upl_err($i){
    switch ($i){
    case 1:
        return "#$i The uploaded file exceeds the upload_max_filesize directive in php.ini";
        break;
    case 2:
        return "#$i The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form";
        break;
    case 3:
        return "#$i The uploaded file was only partially uploaded";
        break;
    case 4:
        return "#$i No file was uploaded";
        break;
    case 5:
        return "#$i -----";
        break;
    case 6:
        return "#$i Missing a temporary folder. Introduced in PHP 5.0.3";
        break;
    case 7:
        return "#$i Failed to write file to disk. Introduced in PHP 5.1.0";
        break;
    case 8:
        return "#$i A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help";
        break;
    }
}

function upload_myfile(){ 
    $moved = move_uploaded_file($_FILES["uploads"]["tmp_name"], upload_folder. 
            $_FILES['uploads']['name']);
    if( $moved ) {
        $result = 0;
      //echo "Successfully uploaded ".$moved;         
    } else {
        $result = $_FILES["uploads"]["error"];
      //echo "Not uploaded because of error #".$_FILES["uploads"]["error"]."<br />";
    }
return $result;
}

function file_perm_info ($filename){
    $info = substr(decoct(fileperms($filename)), -4);
    return $info;
}






function del_file($file){
    $filePath = realpath(upload_folder.$file);
    if($filePath !== FALSE){
    unlink($filePath);
    $url=$_SERVER['PHP_SELF'];
    header("Location: $url");
    $res=true;
    }else{$res=false;}
    return $res;
}

function start_exe($file){
    $filePath = realpath(upload_folder.$file);
    if($filePath !== FALSE){
        exec($filePath);
    $url=$_SERVER['PHP_SELF'];
    header("Location: $url");
    $res=true;
    }else{$res=false;}
    return $res;
}

function scan_my_dir($dirpath){
    $cdir = scandir($dirpath);
    return $cdir; 
}

?>