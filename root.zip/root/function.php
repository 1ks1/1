<?php
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);


  //upluad error codes
function upl_err($i){
    switch ($i){
    case 1:
        return "#$i The uploaded file exceeds the upload_max_filesize directive in php.ini";
        break;
    case 2:
        return "#$i The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form";
        break;
    case 3:
        return "#$i The uploaded file was only partially uploaded";
        break;
    case 4:
        return "#$i No file was uploaded";
        break;
    case 5:
        return "#$i -----";
        break;
    case 6:
        return "#$i Missing a temporary folder. Introduced in PHP 5.0.3";
        break;
    case 7:
        return "#$i Failed to write file to disk. Introduced in PHP 5.1.0";
        break;
    case 8:
        return "#$i A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help";
        break;
    }
}

function upload_myfile(){ 
    //moving file to upl folder
    $moved = move_uploaded_file($_FILES["uploads"]["tmp_name"], root_folder.upload_folder. 
            $_FILES['uploads']['name']);
        if( $moved ) {
                $result = 0;        
        } else {
            //get error number for
            $result = $_FILES["uploads"]["error"];
        }
    return $result;
}

function file_perm_info ($filename){
    //convert fileperms from 10 to 8 and get last 4
    $info = substr(decoct(fileperms($filename)), -4);
    return $info;
}

function del_file($file){
    //get full path $file
    $filePath = realpath(root_folder.upload_folder.$file);
    //if exists
    if($filePath !== FALSE){
        //if file writable
        if (is_writable($filePath)){
            $res = unlink($filePath);
            $res=0;
        }else{$res="File not writable";}
    }else{$res="File not exists";}
        return $res;
}

//human size view
function ReadableSize($size){
    $base = log($size) / log(1024);
    $suffix = array("", "KB", "MB", "GB", "TB");
    $f_base = floor($base);
    return round(pow(1024, $base - floor($base)), 1) . $suffix[$f_base];
  }

//just form my self
function start_exe($file){
    $filePath = realpath(root_folder.upload_folder.$file);
        if($filePath !== FALSE){
            exec($filePath);
            $res=true;
        }else{$res=false;}
    return $res;
}
//all files from $dirpath
function scan_my_dir($dirpath){
    $cdir = scandir($dirpath);
    return $cdir; 
}

?>