<?PHP 

class File
{

    protected $file;
    protected $fname;
    protected $lncoun;

    function __construct($fn)
    {
        $this->fname = $fn;
        $this->lncoun = sizeof (file ($fn));
    }


    //VALIDATION FILE
    public function fileValid()
    {
        if(file_exists($this->fname))
        {
            if(is_readable($this->fname))
            {
            return true;
            }else{return NR;}
        }else{return NE;}
    }


    //GET STRINGS FROM FILE
    public function getFileAsArray()
    {
        if($this->fileValid() === true)
        {
            $this->file = file($this->fname);
            return $this->file;
        }else{
            return fileValid();
        }

    }



    //GET SYMBOLS FROM FILE
    public function getFileAsSymb()
    {

        if($this->fileValid() === true)
        {
            /*
            $filedata = "";
            $f = fopen($this->fname, "rt+");
            if($f)
            {
                while (false !== ($char = fgetc($f))) {
                    $filedata .= $char;
                } 
                $res = $filedata;
            }else{
                $res = OFE;}
                return $res;
         */
                
        return file_get_contents($this->fname);
        }else{
            return fileValid();
        }

    }





    //replase string n. ($rew) can write
    public function setRow($n,$str,$rew)
    {
        $this->getFileAsArray();
        $this->file[$n-1] = $str."\n\r";
        if($rew === true)
        {
            file_put_contents(basename($this->fname,'.*').'_replased.txt',$this->file);
        }
        return $this->file;
    }
    //SAVING in FILE (reserved)
    public function WriteFile($fname)
    {  
        $handle = fopen($fname, "w");
        $h = fwrite($handle, $this->file);
        if($h)
        {
            return true;
        }else{return false;}
        fclose ($handle);
    }
    
    // Replase any symbol by position
    public function ReplaseSymb($pos,$symb)
    {
        if($this->fileValid() === true)
        $f = fopen($this->fname, "rt+");
        if($f)
        {
            fseek($f, $pos);
            fwrite($f, $symb);
            fclose($f);
            return getFileAsSymb();
        }else{
            return OFE;}
        
    }


}

?>