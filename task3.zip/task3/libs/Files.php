<?PHP 

class File
{

    protected $file;
    protected $fpath;


    function __construct($fn)
    {
        $this->fpath = $fn;
    }



    public function getFileAsArray()
    {
        if($this->fileValid() === true)
        {
            $this->file = file($this->fpath);
            return $this->file;
        }else{
            return fileValid();
        }

    }



    public function fileValid()
    {
        if(file_exists($this->fpath))
        {
            if(is_readable($this->fpath))
            {
            return true;
            }else{return NR;}
        }else{return NE;}
    }




    public function getFileAsSymb()
    {

        if($this->fileValid() === true)
        {
            
            return implode(file($this->fpath));
        }else{
            return fileValid();
        }

    }


    public function setRow($n,$str,$rew)
    {
        $this->getFileAsArray();
        $this->file[$n-1] = $str."\n\r";
        if($rew === true)
        {
            file_put_contents($this->fpath,$this->file);
            return $this->file;
        }
        return $this->file;
    }

    public function rewriteFile()
    {
        $handle = fopen($this->fpath, "w");
        $h = fwrite($handle, $this->file);
        if($h)
        {
            return true;
        }else{return false;}
        fclose ($handle);
    }
    

    public function ReplaseSymb($pos,$symb)
    {
        if($this->fileValid() === true)
        $f = fopen($this->fpath, "rt+");
        if($f)
        {
            fseek($f, $pos);
            fwrite($f, $symb);
            fclose($f);
            return getFileAsSymb();
        }else{
            return OFE;}
        
    }


}

?>