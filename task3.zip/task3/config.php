<?PHP
define('FILE','textfile.txt');
define('NE','File not exists');
define('NW','File not writable');
define('NR','File not readable');
define('NC','File have no content');
define('OFE','Open file error!');
?>