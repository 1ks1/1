<pre>
<?PHP
    if(isset($_POST['pl']))
    echo $Rf->readAllFrom();
    if(isset($_POST['repChinStr']))
    echo $Rf->repChinStr();
    if(isset($_POST['repLatter']))
    echo $Rf->repLatter();
    if(isset($_POST['readLatters']))
    print_r( $Rf->rLatters());
    if(isset($_POST['repSbStr']))
    print_r( $Rf->repAllSubStr());   repChinStr
    


    echo "<hr />DEBUG:<br />";
    if ($_POST)
    {
        print_r ($_POST);
    }
?>
</pre>
