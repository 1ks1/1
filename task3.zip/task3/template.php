<pre>
<?PHP
    if(isset($_POST['pl']))
    echo $Rf->readAllFrom();
    if(isset($_POST['strN']))
    echo $Rf->setStringFromFile();
    if(isset($_POST['repChN']))
    echo $Rf->repChNuber();
    if(isset($_POST['repLatter']))
    echo $Rf->repLatter();
    if(isset($_POST['readLatters']))
    print_r( $Rf->rLatters());
    if(isset($_POST['repSbStr']))
    print_r( $Rf->repAllSubStr());
    if(isset($_POST['replaceStr']))
    echo($Rf->setStringWrite()); 
    
    


    echo "<hr />DEBUG:<br />";
    if ($_POST)
    {
        print_r ($_POST);
    }
?>
</pre>
