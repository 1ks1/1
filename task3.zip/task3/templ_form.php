        <?PHP 
        if (isset($_SESSION['filename']))
        {
            echo '<input type="text" name="file" value="'.$_SESSION['filename'].'" />';
        } 
        ?>
        <input type="text" name="file" value="file.txt" />
        <input type="submit" name="pl" value="print numbering strings" />
        <input type="submit" name="readLatters" value="print all symbols" />
        <br />  <br />
        <input type="submit" name="repLatter" value="replace all char" />
        <input type="submit" name="repSbStr" value="replace substring" />
        <input type="text" name="latterA" value="a" size="5" /> to 
        <input type="text" name="latterB" value="a" size="5" />
        <br /><br />
        <input type="submit" name="repChN" value="replace char nuber " />
        <input type="text" name="chrN" value="5" size="5" />
        <input type="text" name="chr" value="o" size="5" />
        <br /><br />
        <input type="submit" name="strN" value="replace char nuber " />
        <input type="text" name="numberstr" value="0" size="5" />
        
    
        