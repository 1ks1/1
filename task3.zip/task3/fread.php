<?PHP
$Rf = new Rfile();
class Rfile
{

    public function getFileStrings($fname){
        if(file_exists($fname))
        {
            if (is_readable($fname))
            {
                $file = file($fname);
            }else $file = "Can't Read file $fname";
        }else $file = "File $fname not exists!";
        return $file;
    }
    public function getFile($fname){
        if(file_exists($fname))
        {
            if (is_readable($fname))
            {
                $f = fopen($fname, "r");
                    if ($f)
                    {
                        $content = "";
                        while (!feof($f))
                        {
                            $char = fgetc($f);
                            $content = $content.$char;
                        }
                    }
                fclose($f);

            }else $content = "Can't Read file $fname";
        }else $content = "File $fname not exists!";
        return $content;
    }
    public function readAllFrom()
    {
                $lines=$this->getFileStrings($_POST['file']);
                $content = "";
                $counter = 0;
                foreach ($lines as $line) {
                    $counter ++;
                    $content = $content.$counter." ".$line;
                }
            
            return $content;
    }


    public function repLatter()
    {
        $lines=$this->getFileStrings($_POST['file']);
        $a = $_POST['latterA'];
        $b = $_POST['latterB'];
        if (!strlen($a.$b) == 2){
            $content = "No such symbols";
        }else{
            $content = "";
            foreach ($lines as $line) 
            {
            $str = str_replace($a, $b, $line);
            $content = $content.$str;
            }
        }
            return $content;
    }

    public function repAllSubStr()
    {
        $lines=$this->getFileStrings($_POST['file']);
        $a = $_POST['latterA'];
        $b = $_POST['latterB'];

            $content = "";
            foreach ($lines as $line) 
            {
            $str = str_replace($a, $b, $line);
            $content = $content.$str;
            }

            return $content;
    }



    public function rLatters()
    {
        $content = $this->getFile($_POST['file']);
        return $content;
        
    }

    public function repChNuber()
    {   
        $n = $_POST['chrN'];
        $ch = $_POST['chr'];
        $s = $this->getFile($_POST['file']);
        $str_length = strlen($s);

        if ($n <= $str_length){
            $s[$n]=$ch;
            $content = $s;
        }else{
            $content = "Char number is bas";
        }

        return $content;
    }


    public function setStringFromFile()
    {
        $str = $_POST['numberstr'];
        $lines=$this->getFileStrings($_POST['file']);
        $content = $lines[$str];
        return $content;
    }
}
?>