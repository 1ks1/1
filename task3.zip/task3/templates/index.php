<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Files</title>
</head>
<body>
    <h1><?PHP echo FILE ?></h1>
    <?PHP
        echo '<br/><b>File as array of string:</b><br />';
        foreach($cl->getFileAsarray() as $s)
        {
            echo $s.'<br />';
        }
        echo "<br/><b>File replace string $n to $str :</b><br />";
        echo "for saving pleas set 3 param as (,,true)<br />"; 
        foreach($file as $s)
        {
            echo $s.'<br />';
        }
        echo '<br/><br/><b>File as symbols:</b><br />';
        echo ($fs);
        echo '<hr/>';
    ?>
</body>
</html>