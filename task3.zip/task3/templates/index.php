<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Files</title>
</head>
<body>
    <h1><?PHP echo FILE ?></h1>
    <?PHP
        $cl = new File(FILE);

        echo '<br/><b>File as array of string:</b><br />';
        foreach($cl->getFileAsarray() as $s)
        {
            echo $s.'<br />';
        }
        $n = 2;
        $str = "12345";
        echo "<br/><b>File replace string $n to $str :</b><br />";
        $n = 2;
        $str = "12345";
        $file=$cl->setRow($n,$str,true);
        foreach($file as $s)
        {
            echo $s.'<br />';
        }
        

        echo '<br/><br/><b>File as symbols:</b><br />';
        print_r ($cl->getFileAsSymb());
        echo '<hr/>';
    ?>
</body>
</html>