<?PHP
include('config.php');
include('libs/Files.php');
include('templates/index.php');
?>