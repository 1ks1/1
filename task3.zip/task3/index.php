<?PHP
include('config.php');
include('libs/Files.php');
$n = 2;
$str = "12345";
$cl = new File(FILE);
$fs = $cl->getFileAsSymb();
$file=$cl->setRow($n,$str,true);
include('templates/index.php');
?>