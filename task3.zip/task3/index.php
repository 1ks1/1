<?PHP
session_start();
include('fread.php')
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>file reading</title>
</head>
<body>
    <form action="" method="POST">
    <?PHP
        include('templ_form.php');
    ?>
    </form>
    <hr />
    <?PHP
        include('template.php')
    ?>
</body>
</html>