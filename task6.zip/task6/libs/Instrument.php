<?PHP
class Instrument implements iInstrument
{
    private $name;
    private $category;

    function setName($name)
    {
        $this->name = $name;
    }
	function setCategory($category)
    {
        $this->category = $category;
    }
    function  getName()
    {
       return $this->name;
    }
	
	function getCategory()
	{
		return $this->category;
	}
    
}
