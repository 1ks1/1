<?PHP
class Band implements iBand
{
    private $name;
    private $genre;
    private $musican = array();
    
    function setName($n)
    {
        $this->name = $n;
    }

    function setGenre($g)
    {
        $this->genre = $g;
    }

    public function getName()
    {
        return $this->name;
    }
    public function getGenre()
    {
        return $this->genre;
    }
    public function addMusician(iMusician $obj)
    {
        $this->musican[] = $obj;
    }
    public function getMusician()
    {
        return $this->musican;
    }
}