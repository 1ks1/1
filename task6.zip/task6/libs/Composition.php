<?PHP
class Muz
{
    private $bnd;
    public __construct()
    {
        $this->bnd = new Band();
    }

    function main
    {

    }
}

class MuzExt extends Muz
{
    protected $BandExA;
    public function __construct()
    {
        $this->BandExA = new BandExt();
    }

    function InstrA()
    {

    } 
    function InstrB()
    {
        
    } 
    function InstrC()
    {
        
    } 
}

class Band
{
    function main
    {

    }
}

class BandExt extends Band
{
    function BandA()
    {

    } 
    function BandB()
    {
        
    } 

}
?>