<?PHP


interface iBand
{
    public function getName();
    public function getGenre();
    public function addMusician(iMusician $obj);
    public function getMusician();
}

interface iMusician
{
    public function addInstrument(iInstrument $obj);
    public function getInstrument();
    public function assingToBand(iBand $nameBand);
    public function getMusicianType();
}

interface iInstrument
{
    public function getName();
    public function getCategory();
}


class Instrument implements iInstrument
{
	
    function  getName()
    {
       
    }
	
	function getCategory()
	{
		
	}
    
}


class Musician implements iMusician
{
	
    public function addInstrument(iInstrument $obj)
	{
		
	}
    public function getInstrument()
	{
		
	}
    public function assingToBand(iBand $nameBand)
	{
		
	}
    public function getMusicianType()
	{
		
	}
}

class Band implements iBand
{
    
    public function getName()
    {

    }
    public function getGenre()
    {

    }
    public function addMusician(iMusician $obj)
    {

    }
    public function getMusician()
    {
        
    }
}
?>