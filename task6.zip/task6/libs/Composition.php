<?PHP


interface iBand
{
    public function getName();
    public function getGenre();
    public function addMusician(iMusician $obj);
    public function getMusician();
}

interface iMusician
{
    public function addInstrument(iInstrument $obj);
    public function getInstrument();
    public function assingToBand(iBand $nameBand);
    public function getMusicianType();
}

interface iInstrument
{
    public function getName();
    public function getCategory();
}


class Instrument implements iInstrument
{
    public $name;
    public $category;
	
    function  getName()
    {
       return $this->name;
    }
	
	function getCategory()
	{
		return $this->category;
	}
    
}


class Musician implements iMusician
{
    public $instrument;
    public $musiciantype;
    public $nameband;
    
    public function addInstrument(iInstrument $obj)
	{
		$this->instrument = $obj;
    }
    
    public function getInstrument()
	{
		return $this->instrument;
	}
    public function assingToBand(iBand $nameBand)
	{
		$this->nameband = $nameBand;
	}
    public function getMusicianType()
	{
		return $this->musiciantype;
	}
}

class Band implements iBand
{
    public $name;
    public $genre;
    public $musican;
    
    public function getName()
    {
        return $this->name;
    }
    public function getGenre()
    {
        return $this->genre;
    }
    public function addMusician(iMusician $obj)
    {
        $this->musican = $obj;
    }
    public function getMusician()
    {
        return $this->musican;
    }
}
?>