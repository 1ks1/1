<?PHP


class Band
{
    function main()
    {

    }
}

class Muz
{
    private $bnd;
    public function __construct()
    {
        $this->bnd = new Band();
    }

    function main()
    {

    }
}


class MuzExt extends Muz
{
    protected $BandExA;
    public function __construct()
    {
        $this->BandExA = new BandExt();
    }

    function InstrA()
    {

    } 
    function InstrB()
    {
        
    } 
    function InstrC()
    {
        
    } 
}



class BandExt extends Band
{
    function BandA()
    {

    } 
    function BandB()
    {
        
    } 

}
?>