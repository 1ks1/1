<?PHP
class Musician implements iMusician
{
    private $instrument = array();
    private $musiciantype;
    private $firstName;

    function setFirstName($name)
    {
        $this->firstName = $name;
    }

    function getFirstName()
    {
        return $this->firstName;
    }
    
    function setMusiciantype($mt)
    {
        $this->musiciantype = $mt;
    }

    public function addInstrument(iInstrument $obj)
	{
		$this->instrument[] = $obj;
    }
    
    public function getInstrument()
	{
		return $this->instrument;
	}
    public function assingToBand(iBand $nameBand)
	{
        $nameBand->addMusician($this);
        //$this->nameband = $nameBand;
	}
    public function getMusicianType()
	{
		return $this->musiciantype;
	}
}