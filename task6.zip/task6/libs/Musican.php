<?PHP
class Musician implements iMusician
{
    private $instrument;
    private $musiciantype;
    private $nameband;
    
    function setMusiciantype($mt)
    {
        $this->musiciantype = $mt;
    }

    public function addInstrument(iInstrument $obj)
	{
		$this->instrument = $obj;
    }
    
    public function getInstrument()
	{
		return $this->instrument;
	}
    public function assingToBand(iBand $nameBand)
	{
		$this->nameband = $nameBand;
	}
    public function getMusicianType()
	{
		return $this->musiciantype;
	}
}