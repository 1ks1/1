<?PHP
include('libs/Composition.php');
include('templates/index.php');

$Viola = new Instrument;
$Guitar = new Instrument;
$Gong = new Instrument;

$Guitarist = new Musician;
$Violist = new Musician;
$Gongist = new Musician;
?>