<?PHP
include('libs/Composition.php');


$Instrument = new Instrument;
$Band = new Band;
$Musican = new Musician;


$Musican->addInstrument($Instrument);
$Band->addMusician($Musican);

include('templates/index.php');