<?PHP
include('libs/Composition.php');
include('libs/Band.php');
include('libs/Musican.php');
include('libs/Instrument.php');

$Musican1 = new Musician;
$Instrument1 = new Instrument;
$Band = new Band;


$Instrument1->setName('Guitar');
$Instrument1->setCategory('String');

$Musican1->setMusiciantype('Bass');
$Musican1->addInstrument($Instrument1);
$Musican1->assingToBand($Band);


$Band->setName('BandName');
$Band->setGenre('BandGenre');
$Band->addMusician($Musican1);


include('templates/index.php');