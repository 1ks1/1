<?PHP
include('libs/Composition.php');
include('libs/Band.php');
include('libs/Musican.php');
include('libs/Instrument.php');

$Musican1 = new Musician;
$Musican2 = new Musician;
$Instrument1 = new Instrument;
$Instrument2 = new Instrument;
$Band = new Band;


$Instrument1->setName('Guitar');
$Instrument1->setCategory('Rock');

$Instrument2->setName('Viola');
$Instrument2->setCategory('String');

$Musican1->setMusiciantype('RockGuitarist');
$Musican1->setFirstName('Vasilij');
$Musican1->addInstrument($Instrument1);
$Musican1->assingToBand($Band);

$Musican2->setMusiciantype('Bassist');
$Musican2->setFirstName('Dominica');
$Musican2->addInstrument($Instrument2);
$Musican2->assingToBand($Band);


$Band->setName('Duet company');
$Band->setGenre('Classics');
$Band->addMusician($Musican1);
$Band->addMusician($Musican2);


include('templates/index.php');