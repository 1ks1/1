<?PHP
include('libs/Composition.php');
include('templates/index.php');
?>