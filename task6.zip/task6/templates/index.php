<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Compos</title>
    <style>
    body {text-shadow:0 0 3px #777;color:#777;}
    b{text-shadow:0 0 3px #777;color:#234;}
    </style>
</head>
<body>
    <h2>Composition test obj</h2>
<pre>
<?PHP
echo "In the group <b>" . $Band->getName() . "</b> of <b>" . $Band->getGenre() . "</b>:<hr />";
foreach ($Band->getMusician() as $m)
{
    echo "<br /><br /><b>" . $m->getFirstName() . "</b> is <b>" . $m->getMusicianType();
    echo "</b>. Playing on ";
    foreach ($m->getInstrument() as $instr)
    {
        echo "<b>" . $instr->getCategory() . "</b>";
        echo " <b>" . $instr->getName() . "</b>";
    }
}
?>
</pre>
</body>
</html>