<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Compos</title>
</head>
<body>
    <b>Composition</b>
<pre>
<?PHP print_r($Band); ?>
<hr />
<?PHP
echo $Band->getName() . " of " . $Band->getGenre() . "<br />";
echo $Band->getMusician()[0]->getMusicianType() . " ";
echo $Band->getMusician()[0]->getInstrument()->getCategory() . 
" " . $Band->getMusician()[0]->getInstrument()->getName() . "<br />";

echo $Band->getName() . " of " . $Band->getGenre() . "<br />";
echo $Band->getMusician()[1]->getMusicianType() . " ";
echo $Band->getMusician()[1]->getInstrument()->getCategory() . 
" " . $Band->getMusician()[1]->getInstrument()->getName() . "<br />";
?>

</pre>
</body>
</html>