const http = require("http");
const fs = require("fs");
var head_html = fs.readFileSync('head', 'utf8');
var body_html = fs.readFileSync('body', 'utf8');
var end_html = fs.readFileSync('foot', 'utf8');


http.createServer(function(request, response){
var a = head_html;
var b;

	if(request.url === "/" ){
	
			for( var ArrVal in request.headers ) {
			b +=  ArrVal+'  = '+request.headers[ArrVal]+'<br />';
			}

			a += '';
			a += '<pre>This is nodejs SERVER</pre><br />';
			a += "Url: " + request.url+'<br />';
			a += "Тип запроса: " + request.method+'<br />';
			a += "User-Agent: " + request.headers["user-agent"]+'<br />';
			a += "Все заголовки"+'<br />';
			a += b+'<br />';
			a += "--------------------------------------"+'<br />';
			a += body_html;
			a += end_html;	
			
			console.log("--------------------------------------");
			 console.log("Url: " + request.url);
			console.log("Тип запроса: " + request.method);
			console.log("User-Agent: " + request.headers["user-agent"]);
			console.log("Все заголовки");
			console.log(request.headers);
			
			response.setHeader("UserId", 12);
			response.setHeader("Content-Type", "text/html; charset=utf-8;");
				
    }else{
		response.setHeader("UserId", 12);
		response.setHeader("Content-Type", "text/html; charset=utf-8;");
		response.statusCode = 404;
        a = "<h2>404</h2>";
	}
	
	
	//
	if (request.url == '/favicon.ico')
	{
		var img = fs.readFileSync('favicon.ico');
		response.writeHead(200, {'Content-Type': 'image/x-icon' });
		response.end(img, 'binary');
	}else{
		 response.end(a);
	}
	
	
   
}).listen(80);
