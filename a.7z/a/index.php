<?PHP
    include('config.php');
    include('sql.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SQL</title>
</head>
<body>
    <form action="" method="POST">
    table <input type="text" name="sql_table" value="TEST" /><br />
    fields <input type="text" name="sql_fields" value="id" /><br />
    condition <input type="text" name="sql_conditions" value=""><br />
        <input type="submit" name="sql_q" value="sql_q send">
    </form>

<?PHP
include('template.php');
?>
</body>
</html>