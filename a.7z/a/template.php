<?PHP
    if(isset($_POST))
    {
        echo "DEBUG POSTS:<hr />";
        print_r($_POST);
    }

    $cl = new SQL;
    if(isset($_POST['sql_q']))
    {
    echo "<hr />Q:<br />";
    echo $cl->msql_conn();
    echo "<hr />";
    }
?>