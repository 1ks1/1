<?PHP
define("USER","user11");
define("PASSWORD","user11");
define("DATABASE","user11");
define("LOCALHOST","127.0.0.1");
?>