<?PHP

    class SQL
    {

        protected $table;
        protected $fields;
        protected $uslovija;
        public $link;


        function msql_conn(){
            $this->link = mysql_connect('127.0.0.1', 'user11', 'user11');
            if (!$this->link) {
                die($this->link ="Error! ". mysql_error());
            }
            mysql_close($this->link);
            return $this->link;
        }

        public function setTable(){
            $this->table = $_POST['sql_table'];
        }
        public function setFields(){
            $this->table = $_POST['sql_fields'];
        }


        protected function select()
        {  
            $this->msql_conn();



            $result = "select * from TEST";
            return $result;
        }
        protected function insert()
        {
            
        }
        protected function update()
        {
            
        }
        protected function delete()
        {
            
        }


    }


    class SQLQ extends SQL
    {
        
    }


?>