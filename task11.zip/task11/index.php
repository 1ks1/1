<?PHP
include('libs/config.php');
include('libs/Sql10.php');
include('libs/AR.php');

$A = new Ar;
$users = $A->users()->getAllUsers();

$id = 1;
$userid1 = $A->users()->byId($id);

$add = 'uncoment string 13 in index.php';
//if($A->user('4','SomeUser')->save()) $add = 'user added';
$currentuser = $A::$user;

$rem = 'uncoment string 17 in index.php';
//if($A->user('4','SomeUser')->remove()) $rem = 'user removed';

$findStr = 'a';
$find = $A->users()->findName($findStr);
if (!empty($A::$qqq))
$q = $A::$qqq;
$found = [];
foreach ($find as $val)
{
    $found[] = $val['name'];
}
$found = implode('<br />',$found);


include('templates/index.php');