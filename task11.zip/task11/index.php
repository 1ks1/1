<?PHP
include('libs/config.php');
//include('libs/Sql.php');
include('libs/SqlStaticTable.php');


$res_select = '';
$res_save = '';
$table = 'my_test';
$name = "Vasilij";
$db = DATABASE;

$b = new SqlTable;

//print_r($b->save(2,$name));
//print_r($b->userByName($name));

include('templates/index.php');