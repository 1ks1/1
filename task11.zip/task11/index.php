<?PHP
include('libs/config.php');
include('libs/Sql10.php');
include('libs/AR.php');

$A = new Ar;
$users = $A->users()->getAllUsers();

$id = 1;
$userid1 = $A->users()->byId($id);

$add = 'uncoment string 13 in index.php';
if($A->user('4','RenamedUser02345')->save()) $add = 'user added';
$qadd = $A->getQuery();

$qr = '';
$rem = 'uncoment string 17 in index.php';
if($A->user('4','RenamedUser02345')->remove()) $rem = 'user <b>' . Ar::$user['name'] . '</b> removed';
$qr = $A->getQuery();

$findStr = 'a';
$find = $A->users()->findName($findStr);
$tmpq = $A->getQuery();
if (!empty($tmpq))
$q = $A->getQuery();
$found = [];
foreach ($find as $val)
{
    $found[] = $val['name'];
}
$found = implode('<br />',$found);


include('templates/index.php');