<?PHP
class SqlTable
{
    protected $id;
    protected $allusers;
    protected $name;
    protected $colls;
    protected $pdo;


    

    function __construct()
    {
        $this->table = TABLENAME;
        $this->colls = $this->getColsFromTable();
    }

    public function test() {
        return (get_object_vars($this)); 
    }

    function setId($id)
    {
        $this->id = $id;
    }

    function getId()
    {
        return $this->id;
    }

    function setName($name)
    {
        $this->name = $name;
    }

    function getName()
    {
        return $this->name;
    }

    function getAllUsers()
    {
        return $this->allusers;
    }

    function userById($id)
    {
        $user = [];
        $l = $this->connect();
        $rows = $this->query("SELECT name,id FROM " . $this->table . " WHERE id = '$id'");
        foreach ($rows as $k => $u)
        {
            $user[$k] = $u;
        }
        return $user;
    }

    function userByNmae($name)
    {
        $user = [];
        $l = $this->connect();
        $rows = $this->query("SELECT name,id FROM " . $this->table . " WHERE name = '$name'");
        foreach ($rows as $k => $u)
        {
            $user[$k] = $u;
        }
        return $user;
    }

    function existsId($idvalue)
    {
        $found = false;
        foreach ($this->userById($idvalue) as $key => $val)
        {
            if ($key == 'id' && $val == $id) $found = true;
        }
        return $found;
    }

    function existsName($name)
    {
        
        $found = false;
        foreach ($this->userByName($name) as $val)
        {
            if ($val == $name)
            { 
                $found = true;
            }
        }
        return $found;
    }

    function save ($id,$name)
    {   

        $result = false;
        if ($this->existsId($id))
        {   
            $result = $this->query("UPDATE $this->table SET id=$id,name='$name' WHERE id=$id");
        }
        else
        {
            $result = $this->query("INSERT INTO $this->table ('id','name') VALUES ('$id', '$name')");
        }

        return $result;
    }

    function delete ($id,$user)
    {
        $result = false;
        if ($this->existsId($id))
        {
            $result = $this->query("DELETE FROM $this->table WHERE id=$id");
        }
        return $result;
    }


    function getColsFromTable()
    {
        $c = [];
        $l = $this->connect();
        $rows = $this->query("SELECT * FROM " . $this->table);
        return $rows[0];
        foreach ($rows[0] as $k => $v)
        {
            $c[] = $v;
        }
        $this->colls = $v;
        return $this;
    }

    function users()
    {
        $users = [];
        $l = $this->connect();
        $rows = $this->query("SELECT name,id FROM " . $this->table);
        foreach ($rows[0] as $k => $u)
        {
            $users[$k] =  $u;
        }
        $this->allusers = $users;
        return $this;
    }

    function userByName($name)
    {
        $user = [];
        $l = $this->connect();
        $rows = $this->query("SELECT name,id FROM " . $this->table . " WHERE name = '$name'");
        foreach ($rows[0] as $k => $u)
        {
            $user[$k] = $u;
        }
        return $user;
    }


    function query($sql)
    {
        echo '<br />';print_r($sql);echo '<br />';#debug
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }



            function connect()
            {
                $dsn = "mysql:host=" . HOST . ";dbname=" . DATABASE . ";charset=" . CHARSET;
                $user = USER;
                $password = PASSWD;
                $opt= [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES  => false
                ];

                try{
                    $this->pdo = new PDO($dsn, $user, $password, $opt);
                    return $this->pdo;
                }
                catch(PDOException $e) 
                {
                    print_r('Connect error!');//debug
                    return $e->getMessage();  
                }
                
            }  
    }


    class Sql extends SqlTable
    {

         
    }