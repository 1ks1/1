<?PHP
class Ar extends My_sql
{
    private $users; 
    public static $user;

    function getAllUsers()
    {
        if (isset($this->users))
        return $this->users;
    }

    function byId($id)
    {
        $res = false;
        if (isset($this->users))
        {
            foreach($this->users as $k=>$val)
            {
                if ($val['id'] == $id)
                {
                    $res = $val;
                }
            }
        }
        
        if (is_array($res))
        {
            return $res;
        }else{return false;}
        
    }

    function users()
    {
        $this::$qqq = ('SELECT * FROM '.TABLENAME);
        $this->setQuery($this::$qqq);
        $this->users = $this->sel('select');
        return $this;
    }

    function user($id,$name)
    {
        $this::$user['id'] = $id;
        $this::$user['name'] = $name;
        return $this;
    }

    function save()
    {
        if (is_array($this::$user))
        {
            if (false == $this->byId($this::$user['id']))
            {
                $this::$qqq = ("INSERT INTO " . 
                TABLENAME . " (id,name) VALUES " . "(" . 
                $this::$user['id'] . ",'" . 
                $this::$user['name'] . "')");
                $this->setQuery($this::$qqq);
                $this->users = $this->sel('insert');    

            } else {

                $this::$qqq = ("UPDATE " . 
                TABLENAME . " SET id=" . $this::$user['id'] . 
                ",name='" . $this::$user['name'] .
                "' WHERE id=" . $this::$user['id']);

                $this->setQuery($this::$qqq);
                $this->users = $this->sel('update');

            }

            
            
            return true;
        } else{return false;}

    }

    function remove()
    {
        if (is_array($this::$user))
        {
            $this::$qqq = ("DELETE FROM " . 
            TABLENAME . " WHERE id=" . $this::$user['id']);
            $this->setQuery($this::$qqq);
            $this->users = $this->sel('delete');
            return true;
        } else{return false;}

    }

    function findName($findStr)
    {
      
            $this::$qqq = ("SELECT * FROM " . 
            TABLENAME . " WHERE name LIKE " . "'%$findStr%'");
            $this->setQuery($this::$qqq);
            print_r($this->getQuery());
            $this->users = $this->sel('select');
            return $this->users;
      

    }

  
}