<?PHP
class Ar extends My_sql
{
    private $users; 
    public static $user;

    function getAllUsers()
    {
        if (isset($this->users))
        return $this->users;
    }

    function byId($id)
    {
        $res = false;
        if (isset($this->users))
        {
            foreach($this->users as $k=>$val)
            {
                if ($val['id'] == $id)
                {
                    $res = $val;
                }
            }
        }
        
        if (is_array($res))
        {
            return $res;
        }else{return false;}
        
    }

    function users()
    {
        $this->setTable(TABLENAME)->setWhat('*');
        $this->users = $this->sel('select');
        return $this;
    }

    function user($id,$name)
    {
        $this::$user['id'] = $id;
        $this::$user['name'] = $name;
        return $this;
    }

    function save()
    {
        $this::$qqq = '';
        if (is_array($this::$user))
        {
            if (false == $this->byId($this::$user['id']))
            {
                $this->setTable(TABLENAME)->setWhat('id,name')->
                setValues($this::$user);
                $this->users = $this->sel('insert'); 
                $this::$qqq = $this->query;   

            } else {
                $this->setTable(TABLENAME)->
                setValues($this::$user);
                $this->users = $this->sel('update');
                $this::$qqq = $this->query;
            }

            
            
            return true;
        } else{return false;}

    }

    function remove()
    {
        $this::$qqq = '';
        if (is_array($this::$user))
        {
            $this->setTable(TABLENAME)->
            setWhere("id='".$this::$user['id']."'");
            $this->users = $this->sel('delete');
            $this::$qqq = $this->query;
            return true;
        } else{return false;}

    }

    function findName($findStr)
    {
            $this::$qqq = '';
            $this->setTable(TABLENAME)->
            setWhere("name LIKE " . "'%$findStr%'");
            $this->users = $this->sel('select');
            $this::$qqq = $this->query;
            return $this->users;
      

    }

  
}