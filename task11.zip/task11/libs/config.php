<?PHP
//SQL//
//define("USER","user11");
//define("PASSWD","user11");
define("DATABASE","user11");
define("HOST","127.0.0.1:3307");
define("USER","root");
define("PASSWD","usbw");
define("CHARSET","utf8");
define("TABLENAME","MY_TEST");
define("DBTYPE" ,"1");
?>