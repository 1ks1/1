<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>task11</title>
</head>
<body>
    <pre>
    Task11: Создать класс для реализации Актив рекордс:
В работе нужно применить Sql (Task4) класс и таблицу MY_TEST из бд MySQL
</pre>
<a href="http://www.php.net/manual/ru/book.pdo.php">PDO</a> | 
<a href="http://habrahabr.ru/post/137664/">pdo2</a> | 
<a href="http://labdes.ru/php-pdo-mysql-examples">PDO3</a> | 
<a href="https://ru.wikipedia.org/wiki/ActiveRecord" title="Wiki">ActiveRecord</a>

<hr />
<?PHP
echo '<h2><b>DEMO</b></h2>';
echo '<h4>All User Names:</h4>';
echo "|id|name";
foreach($users as $v)
{
    echo "<br />|".implode('|',$v);
}
echo '<br/><hr/>';

echo '<h4>User by ID (1):</h4>';
echo '|id|name <br/>';
foreach($userid1 as $k => $v)
{
    echo "| $v";
}
echo '<hr/>';
echo '<h4>new User -> save:</h4>';
echo "q = $qadd<br />";
echo $add . ' <br/>';

echo '<hr/>';
echo '<h4>User -> remove:</h4>';
echo $rem . ' <br/>';


echo '<hr/>';
echo '<h4>User -> findName:</h4>';
echo "current q: $q <br /><br />";
echo($found);
echo ' <br/>';

?>
</body>
</html>