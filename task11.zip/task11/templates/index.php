<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>task11</title>
</head>
<body>
    <pre>
    Task11: Создать класс для реализации Актив рекордс:
В работе нужно применить Sql (Task4) класс и таблицу MY_TEST из бд MySQL
</pre>
<a href="http://www.php.net/manual/ru/book.pdo.php">PDO</a> | 
<a href="http://habrahabr.ru/post/137664/">pdo2</a> | 
<a href="http://labdes.ru/php-pdo-mysql-examples">PDO3</a> | 
<a href="https://ru.wikipedia.org/wiki/ActiveRecord" title="Wiki">ActiveRecord</a>

<hr />
<?PHP

//test obj

?>
</body>
</html>