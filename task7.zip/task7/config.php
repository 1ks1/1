<?php
define('TEMPLATE', 'templates/index.php');

