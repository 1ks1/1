<?php
define('TEMPLATE', 'template/index.php');

