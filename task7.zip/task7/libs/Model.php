<?php 

class Model
{ 
	private $fioName;
	private $mEmail;
	private $subject;
	private $mEmailTo;
	private $message;
	private $headers;

   public function __construct()
   {

   }
   	
	public function getArray()
   {	    
		$aAr = array('%TITLE%' => 'Contact Form', 
		'%ERRORS%' => 'Empty field');
		return 	$aAr;
   }
	
	public function checkForm()
	{
		$this->fioName;
		$this->mEmail;
		$this->subject;
		$this->message;
		$this->mEmailTo;
		
		
			if (filter_var($_POST['email_from'], FILTER_VALIDATE_EMAIL))
			$this->mEmail = $_POST['email_from'];

			if (filter_var($_POST['email_to'], FILTER_VALIDATE_EMAIL)) 
			$this->mEmailTo = $_POST['email_to'];

			if (strlen(trim($_POST['fioName']))>2)
			$this->fioName = trim($_POST['fioName']);
		
			if (strlen(trim($_POST['mTheme']))>2)
			$this->subject = $_POST['mTheme'];

			if (strlen(trim($_POST['message']))>2)
			$this->message = $_POST['message'];

			$this->headers = 'From: '.$this->mEmail."\r\n";
			$this->headers = $this->headers.'Reply-To: webmaster@example.com' . "\r\n" .'X-Mailer: PHP/';
			
			


			if(isset($this->mEmail)&&isset($this->fioName)&&isset($this->mEmailTo)&&isset($this->message))
			{
				
				return true;
			}else{
			
				return false;
			}

					
	}
   
	public function sendEmail()
	{
		return (mail($this->mEmailTo, $this->subject, $this->message, $this->headers)) ;
		// return mail()
	}		
}
