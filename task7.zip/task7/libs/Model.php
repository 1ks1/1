<?php 

class Model
{ 
	private $fioName;
	private $mEmail;
	private $subject;
	private $mEmailTo;
	private $message;
	private $headers;
	private $Errors;
	

   public function __construct()
   {
		
   }


   	
	public function getArray()
   {	    


	


		$aAr2 = array('%fio%' => '',
		'%from%' => '',
		'%to%' => '',
		'%mbody%' => '',
		'%ERfrom%' => '',
		'%ERto%' => '',
		'%ERfio%' => '',
		'%ERmsg%' => '',
		'%ip%' => $_SERVER['SERVER_ADDR']
		);

		
		if(isset($this->Errors['from']))
		$aAr2['%ERfrom%'] = 'Error from';

		
		if(isset($this->Errors['to']))
		$aAr2['%ERto%'] = 'Error to';
	
		
		if(isset($this->Errors['fio']))
		$aAr2['%ERfio%'] = 'Error fio';

	
		if(isset($this->Errors['message']))
		$aAr2['%ERmsg%']='Error message';

	
			if (isset($_SESSION['from']))
				$aAr2['%from%']=$_SESSION['from'];
			

			if (isset($_SESSION['to']))
			{
				$aAr2['%to%']=$_SESSION['to'];
			}
			

			if (isset($_SESSION['fio']))
			{
				$aAr2['%fio%']=$_SESSION['fio'];
			}

		

		$aAr1 = array('%TITLE%' => 'Contact Form');

		$aAr = array_merge ($aAr1,$aAr2);
		return 	$aAr;
   }
	
	public function checkForm()
	{

			unset($this->Errors);
			if (filter_var($_POST['email_from'], FILTER_VALIDATE_EMAIL))
			{
				$this->mEmail = $_POST['email_from'];
				$_SESSION['from'] =  $_POST['email_from'];
			}else{
				unset($_SESSION['from']);
				$this->Errors['from']='not valid email';
			}
			if (filter_var($_POST['email_to'], FILTER_VALIDATE_EMAIL)) 
			{
				$_SESSION['to'] =  $_POST['email_to'];
				$this->mEmailTo = $_POST['email_to'];
			}else{
				unset($_SESSION['to']);
				$this->Errors['to']='not valid email';
			}
			if (strlen(trim($_POST['fioName']))>2)
			{
				$_SESSION['fio'] =  $_POST['fioName'];
				$this->fioName = trim($_POST['fioName']);
			}else{
				unset($_SESSION['fio']);
				$this->Errors['fio']='must to be more than 2 symbols';
			}
			if ($_POST['mTheme'])
			{	
				if($_POST['mTheme'] == 'option1')
				{
					$_SESSION['subject'] = '';
				}else{
					$_SESSION['subject'] =  $_POST['mTheme'];
					$this->subject = $_POST['mTheme'];
				}
				
				
			}
			

			if (strlen(trim($_POST['message']))>2)
			{
				date_default_timezone_set('Etc/GMT+2');
				$date = date('Y-m-d H:i:s');
				$this->message = $_POST['message']."\n\r server".
				$_SERVER['SERVER_ADDR']."\n\r remote".
				$_SERVER['REMOTE_ADDR']."\n\r".$date;
				
			}else{
				$this->Errors['message']='must to be more than 2 symbols';
			}

			$this->headers = 'From: '.$this->mEmail."\r\n";
			$this->headers = $this->headers.'Reply-To: '.$this->fioName .
			 "\r\n" .'X-Mailer: PHP/';
			


	
 
			
			if(isset($this->mEmail)&&
			isset($this->fioName)&&
			isset($this->mEmailTo)&&
			isset($this->message))
			{
				
				return true;
			}else{
			
				return false;
			}

					
	}
   
	public function sendEmail()
	{
		return (mail($this->mEmailTo, $this->subject, $this->message, $this->headers)) ;
		// return mail()
	}		
}
