import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'clndr-list',
  //template: '<button>Magic</button>',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css'],
})


export class CalendarComponent implements OnInit {
  title = 'Calendar';
  filterDate = undefined;
	selectedDate = new Date();	
	curMon = this.mnn();
	curYear = this.yearnow();
	currentMonthAndYear = this.getMonth(this.curMon)+' '+this.curYear;	
			

          ngOnInit() {
          }


          getMonth(n) {
            var monthsz =  ['Yan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Now','Dec'];
            return monthsz[n];
            }
            
            yearnow() {
              this.curYear = (new Date()).getFullYear();
              return (new Date()).getFullYear();
            }

            mnn() {
              this.curMon = (new Date()).getMonth();
              return (new Date()).getMonth();
            }


            previousMonth() {
              var tmpDate = this.selectedDate;
              var tmpMonth = tmpDate.getMonth() - 1;
            this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
            this.selectedDate.setMonth(tmpMonth);
            this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
            }
          
            nextMonth() {
              var tmpDate = this.selectedDate;
              var tmpMonth = tmpDate.getMonth() + 1;
            this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
            this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
          }


          setDate(date) {
            
                    if (date === this.filterDate) {
                      this.filterDate = undefined;
                    }else{
                      this.filterDate = date;
                    }
                    
                    
              }



              isActive(date) {
                console.log(date === this.filterDate);
                return date === this.filterDate;
              }
            
            isWeekend(date) {
                return ((date.getDay() == 0) || (date.getDay() == 6));
              }



              getCalendarMatrix(date) {
                var calendarMatrix = []
          
                var startDay = new Date(date.getFullYear(), date.getMonth(), 1)
                var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0)
          
                // Modify the result of getDay so that we treat Monday = 0 instead of Sunday = 0
                var startDow = (startDay.getDay() + 6) % 7;
                var endDow = (lastDay.getDay() + 6) % 7;
          
                // If the month didn't start on a Monday, start from the last Monday of the previous month
                startDay.setDate(startDay.getDate() - startDow);
          
                // If the month didn't end on a Sunday, end on the following Sunday in the next month
                lastDay.setDate(lastDay.getDate() + (6 - endDow));
          
                var week = []
                while (startDay <= lastDay) {
                  week.push(new Date(startDay));
                  if (week.length === 7) {
                    calendarMatrix.push(week);
                    week = []
                  }
                  startDay.setDate(startDay.getDate() + 1)
                }
                return calendarMatrix;
              }

              gridArray() {
                var grid = this.getCalendarMatrix(this.selectedDate);
                return grid;
              }
            
            formattedDate() {
                return this.filterDate.getDate() + '  '+
              this.getMonth((this.filterDate.getMonth()+1)) + ' of ' +
              this.filterDate.getFullYear();
              }

}
