import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Shop from '@/components/Shop.vue'
import p404 from '@/components/404.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
	 {
      path: '/shop',
      name: 'Shop',
      component: Shop
    },
	{
      path: '/*',
      name: 'p404',
      component: p404
    }
  ]
})
