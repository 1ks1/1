<template>
<div>
<input type="text" v-model="sometext">
<p>{{sometext}}</p>
</div>
</template>

<script>
export default{
	data () {
		return{
			sometext: ''
		}
	}
}

</script>