<template>
<div>
<router-link to="/">HOME</router-link> {{name}}
<h1>{{greeting}}</h1>
            <ul class="items-store">
        
                <li v-for="(item, index) in items" :key="index" >
                    <button @click="add(index)">+</button>
                        {{ item.name }} - {{ item.price }} 
                
                </li>
				
				<hr />
				
				<app-cart v-bind:cartt="cart" v-on:kk="remove"></app-cart>
                <span class="span-cart" v-if="count_items > 0">Total:{{count_items}} ({{allPrice}}) UAN </span>
				<app-field></app-field>
            </ul>
			
  </div>

</template>

<script>
import Input from './field.vue';
import Cart from './cart.vue';
    export default {
	name: 'Shop',
	components:{
		'app-field':Input,
		'app-cart':Cart
		},
	
	
    data () {
			return {
			  greeting: 'SHOP',
			  cart: JSON.parse(localStorage.cart || '[]'),
				items:[
								{ name: 'Kingston',price: 240,id: 1,count: 1 },
								{ name: 'Transsend',price: 110,id: 2,count: 1 },
								{ name: 'Sandisk',price: 90,id: 3,count: 1 },
								{ name: 'SD',price: 310,id: 4,count: 1 }
						]
			};
			
			
	},		
			
			
	methods:{
			
			 add: function(index) {
                console.log(this.items[index].count + '---');
                if (this.cart.indexOf(this.items[index]) === -1) {
                    this.cart.push(this.items[index]);
                }else{
				this.items[index].count += 1;
				}
			},
			remove: function(key, e) {
                    this.cart.splice(key, 1);
                }
	},

	computed:{
     
            allPrice: function() {
                var sum = 0;
                for (let i = 0; i < this.cart.length; i++) {
                    sum += this.cart[i].price * this.cart[i].count;
                }
                console.log(sum);
               return sum;
            },
            
            count_items: function() {return this.cart.length}
            
    },

	watch: {
            cart: function(newVal) {
            localStorage.cart = JSON.stringify(newVal);
            },
            //следит за вложенностями в объекте
            //deep: true;
    }



}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
h1 {color:#00ccaa;}
.items-store { color:#008; text-align:left;display:inline;}
.span-cart {color:#040;font-weight:600;text-align:left;display:block;}
</style>