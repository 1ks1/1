<template>
<div class="cart">
				<li v-for="(itm, key, summ) in cartt" :key="key" >
                        <button @click="remove(key)">-</button>
                            <b>{{itm.name}}</b>  {{itm.price*itm.count}} UAN 
                </li>

<li>_-=`{{cartmsg}}=-_</li>
</div>
</template>
<script>
export default{
	props:['cartt'],
	data () {
		return{
			cartmsg: 'CART',
		}
	},
	methods:{
			remove: function(key, e) {
					//alert();
                    this.$emit('kk',this.key);
                }
	},
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
.cart {font-weight:400;
text-align:left;display:block;
box-shadow:0px 0px 3px #ccc;}
</style>