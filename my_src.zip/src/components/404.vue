<template>
<div>

Как вы здесь оказались? <br />
<b>{{msg}}</b><br /><br />
<router-link to="/">
GO HOME YANKEE
</router-link>


</div>
</template>

<script>
export default {

  name: '404',
  data () {
			return {
			  msg: '404'
			}
  }
  
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
* {font-family:Tahoma;text-shadow:0 0 2px #444;
}
b{
border-radius:5px;
background:linear-gradient(#fff,#ccc,#fff);
box-shadow:2px 4px 5px #000;
color:#fff;
text-shadow:0px -2px 1px #ccc, 
0px 5px 2px #333;
font-size:80px;
}
</style>
