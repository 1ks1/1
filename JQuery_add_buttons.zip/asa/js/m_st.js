
$(function() {
    var $bt_a = $("p.g_add");
    var $bt_d = $('p.g_del');
    var $off = $('#OFF');
    $bt_d.hide(0);
    
    $bt_a.on('click',function(event) {
    var id = event.target.id;
    showel(event);
    localStorage.setItem(id,'1');
    $('#it2 #'+id).show(200);
      });

      $bt_d.on('click',function(event) {
        var id = event.target.id;
        showel(event);
        localStorage.removeItem(id);
        $('#it2 #'+id).hide(300);
      });

      $off.on('click', function(){
        $bt_d.hide(500);
      });
      function showel(e){
        $("#log")
        .html("clicked: " + 
        e.target.nodeName + ' ' + 
        e.target.id);
      };
});


