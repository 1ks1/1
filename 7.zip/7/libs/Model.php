<?php 

class Model
{ 
	private $fioName;
	private $mEmail;
	private $subject;
	private $mEmailTo;
	private $message;
	private $headers;
	

   public function __construct()
   {
		
   }


   	
	public function getArray()
   {	    

		
		


		$aAr2 = array('%fio%' => 'FIO',
		'%from%' => 'FROM',
		'%to%' => 'TO',
		'%mbody%' => 'yor message',
		'%ip%' => $_SERVER['SERVER_ADDR']
		);

		if ($_SESSION['from'])
		$aAr2['%from%']=$_SESSION['from'];
		if ($_SESSION['to'])
		$aAr2['%to%']=$_SESSION['to'];
		if ($_SESSION['fio'])
		$aAr2['%fio%']=$_SESSION['fio'];
	

		$aAr1 = array('%TITLE%' => 'Contact Form', 
		'%ERRORS%' => 'Empty field');

		$aAr = array_merge ($aAr1,$aAr2);
		return 	$aAr;
   }
	
	public function checkForm()
	{
		$this->fioName;
		$this->mEmail;
		$this->subject;
		$this->message;
		$this->mEmailTo;
		
		
			if (filter_var($_POST['email_from'], FILTER_VALIDATE_EMAIL))
			{
				$this->mEmail = $_POST['email_from'];
				$_SESSION['from'] =  $_POST['email_from'];
			}else{
				$_SESSION['from'] = 'Error FROM';
			}
			

			if (filter_var($_POST['email_to'], FILTER_VALIDATE_EMAIL)) 
			{
				$_SESSION['to'] =  $_POST['email_to'];
				$this->mEmailTo = $_POST['email_to'];
			}else{$_SESSION['to']='Error TO';}
			

			if (strlen(trim($_POST['fioName']))>2)
			{
				$_SESSION['fio'] =  $_POST['fioName'];
				$this->fioName = trim($_POST['fioName']);
			}else{
				$_SESSION['fio'] = 'Error FIO. Min 3 symb.';
			}
			
		
			if ($_POST['mTheme'])
			$_SESSION['subject'] =  $_POST['mTheme'];
		
			

			if (strlen(trim($_POST['message']))>2)
			$this->message = $_POST['message']."\n\r server".
			$_SERVER['SERVER_ADDR']."\n\r remote".
			$_SERVER['REMOTE_ADDR']."\n\r";

			$this->headers = 'From: '.$this->mEmail."\r\n";
			$this->headers = $this->headers.'Reply-To: webmaster@example.com' .
			 "\r\n" .'X-Mailer: PHP/';
			
			


			if(isset($this->mEmail)&&isset($this->fioName)&&isset($this->mEmailTo)&&isset($this->message))
			{
				
				return true;
			}else{
			
				return false;
			}

					
	}
   
	public function sendEmail()
	{
		return (mail($this->mEmailTo, $this->subject, $this->message, $this->headers)) ;
		// return mail()
	}		
}
