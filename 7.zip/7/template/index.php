<html>
<head>
	<title>%TITLE%</title>
</head>
<body>
<div><h2>Contact Form</h2></div>
<div style="color: #F00; font-size: 15px;"><strong>%ERRORS%</strong></div>
<form action="" method="POST">
	<input type="text" name="fioName"  placeholder="FIO" value="%fio%" /><br /><br />
	<input type="email" name="email_from"  placeholder="from" value="%from%" /><br /><br />
	<input type="email" name="email_to"  placeholder="to" value="%to%" /><br /><br />
	<select name="mTheme" >
		<option value="option1" selected>Please Select</option>
		<option value="option2">option2</option>
		<option value="option3">option3</option>
	</select><br /><br />
	<textarea name="message" id="" cols="30" rows="3" placeholder="email text">%mbody%</textarea><br /><br />
	<input type="submit" name="submit"  /><input type="reset" /><br />
</form>
</body>
</html>