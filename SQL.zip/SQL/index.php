<?PHP
include('config.php');
include('libs/Sql.php');
$MySql = new Sql;
$jt = '';
$rowsNow = " rows now is ".$MySql->countTableRows()." <br />";
if ($_POST)
{
    if ($_POST['START']=='START')
    {
        $MySql->if_table_create();
        $MySql->generateInsers();
        $jt = "Job time is : ".$MySql->timeW;
    }
}

if ($_POST)
{
    if ($_POST['addpk']=='addpk')
    {
        $MySql->if_table_create();
        $MySql->addPK();
        $jt = "Job time is : ".$MySql->timeW;
    }
}
if ($_POST)
{
    if ($_POST['delpk']=='delpk')
    {
        $MySql->if_table_create();
        $MySql->delPK();
        $jt = "Job time is : ".$MySql->timeW;
    }
}


include('templates/index.php');

