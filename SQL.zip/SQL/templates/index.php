<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Testing DB</title>
</head>
<body>
    <div class="main">
    <h3>Teating database MySql</h3>
    <p>Base name is "sqltest (id int, name text, descr text) " <br />
        will autocreating if not exists</p>
    <form action="" method="POST" style="background:linear-gradient(#ddd,#fff); 
    height:120px; width:30%; border:1px solid #ccc;border-radius:5px;
    box-shadow:2px 4px 7px #ccc;">
    <input type="SUBMIT" name="START" value="START">start insert(ing)<br />
    <input type="SUBMIT" name="addpk" value="addpk">add primary key<br />
    <input type="SUBMIT" name="delpk" value="delpk">drop primary key<br />
    <?PHP
    echo $jt."<br />".$rowsNow;
    ?>
    </form>
    </div>
</body>
</html>