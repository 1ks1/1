<h2>Registration</h2>
<form action="" method="POST">
<input type="text" name="name" placeholder="Name"><br />
<input type="text" name="lastname" placeholder="Last Name"><br />
<input type="text" name="reg_email" placeholder="email"><br />
password: <br />
<input type="test" name="passwd"><br />
password confirm:<br /> 
<input type="text" name="confirm_pass"><br />
<button type="submit" name="RegistrationBatton">Registration</button>
<button type="submit" name="RegCancel">Cancel</button>
</form>
<?PHP echo $error; ?>