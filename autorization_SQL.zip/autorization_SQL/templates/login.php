<h1>Autorization</h1>
<form action="" method="POST">
<input type="text" name="email" placeholder="email"><br />
<input type="password" placeholder="password" name="password"><br />
<button type="submit" name="LoginBtn">Login</button>
<button type="submit" name="Reg" value="Reg">Register</button>
</form>
<?PHP echo $error; ?>