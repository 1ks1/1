<h1>Hello, <?PHP echo $user;?></h1>

