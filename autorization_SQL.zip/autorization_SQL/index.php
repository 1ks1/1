<?PHP 
session_start();
include('autoload.php');
$cl = new Autorization;

$logoutText = '<form action="" method="POST"><input type="submit" name="Logout"value="Logout"></form>';
$error = '';
if($_POST)
//print_r($_POST);

$user = 'Guest';
if (isset($_SESSION['User']))
$user = $_SESSION['User'] . " " . $logoutText;

if(isset($_POST['LoginBtn']))
{
    $logname = $cl->login($_POST['email'],$_POST['password']);
    if(strlen($logname) > 2)
    {
        $_SESSION['Login'] = true;
        $user = $logname . " " . $logoutText;
        if($user == false)
        {
            $user = 'Guest ' . $logoutText;
        }else{$_SESSION['User'] = $user . " " . $logoutText;}
    }else{$error = 'Wrong email or password';}
    
}

if(isset($_POST['RegistrationBatton']))
{
    $regData = [];
    $error = '';
    if (! strlen($_POST['lastname']) > 3 && isset($_POST['lastname']))
    $error .= 'Error: lastname ';
    if (! strlen($_POST['name']) > 3  && isset($_POST['name']))
    $error .= 'Error: name ';
    if (! strlen($_POST['reg_email']) > 6  && isset($_POST['reg_email']))
    $error .= 'Error: email ';
    if (isset($_POST['lastname']))
    if (! strlen($_POST['passwd']) > 6  && !  $_POST['confirm_pass'] == $_POST['passwd'])
    $error .= 'Error: password < 6  or confirm ';
    if (strlen($error) < 1 )
    {
        $regData['lastname'] = $_POST['lastname'];
        $regData['name'] = $_POST['name'];
        $regData['email'] = $_POST['reg_email'];
        $regData['password'] = $_POST['passwd'];
        $regData['confirm_pass'] = $_POST['confirm_pass'];
        $res = $cl->register($regData);
    }
    $error = $res;
}

if(isset($_POST['Reg']) && $_POST['Reg'] == 'Reg')
{
    $_SESSION['Reg'] = true;
}


if(isset($_POST['Logout']))
{
    unset($_SESSION['Login']);
    unset($_SESSION['Reg']);
}

if(isset($_POST['RegCancel']))
{
    unset($_SESSION['Reg']);
}




include('templates/head.php');
if(!isset($_SESSION['Login']) || $_SESSION['Login'] == false)
{
    if(!isset($_SESSION['Reg']))
    {
        include('templates/login.php');
    } else {
        include('templates/reg.php');
    }
    
}else{
    include('templates/index.php');
}

// header("Content-Type: text/html; charset=UTF-8");
// header('Refresh: 5; URL=http://site.ru'); //redirect с задержкой 
// echo 'Вы будете перенаправлены на главную страницу через 5 секунд.';
include ('templates/futter.php');