<?PHP 

class Autorization Extends DB
{
    protected $pdo;

    function __construct()
    {
        $this->pdo = $this->connect();
    }
    
    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    function select($q)
    {
        $sth = $this->pdo->prepare($q);
        $sth->execute();
        $red = $sth->fetchAll();
        $arr = [];
        if (is_array($red))
        foreach ($red as $key=>$val) 
        {
            $arr[$key] = $val;
        }else{
            return $red;
        }
        return $arr;
    }

    function query($q)
    {
        $sth = $this->pdo->prepare($q);
        $sth->execute();
    }
    

    function login($email,$password)
    {
        $password = md5($password);
        $q = 'SELECT count(email) from users where email=' . "'$email'";
        $res = $this->select($q);
        if ($res[0]['count(email)'] == 1)
        {
            $qw = 'SELECT name,lastname from users where email=' . "'$email'";
            $res2 = $this->select($qw);
            return $res2[0]['name'] . " " . $res2[0]['lastname'];
        }
        return false;
    }

    function register($data)
    {
        foreach($data as $k=>$v)
        {
            if ($this->strValid($data[$k]) == false)
            return 'Error! not valid simbols or empty field!';
        }
        if (strlen($data['password']) < 5)
        return 'Error! Passwod 5 chars minimum (******)';
        $data['password'] = md5($data['password']);
        $q = "SELECT count(email) from users where email='" . $data['email'] . "'";
        $res = $this->select($q);
        $count = $res[0]['count(email)'];
        if ($count > 0)
        return 'Error! User exists!';
        $str = $data['email'];
        if (preg_match("/^[a-zA-Z0-9_\-.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-.]+$/",$str,$go) !== 1)
        return 'Error! Wrong email!';

        $q = "insert into users (name,email,lastname,password) values ('" . 
        $data['name'] . "','". 
        $data['email'] ."' ,'" . 
        $data['lastname'] . "','" . $data['password'] . "')";
        $res = $this->query($q);

        $q = "SELECT count(email) from users where email='" . $data['email'] . "'";
        $res = $this->select($q);
        if ($count < $res[0]['count(email)'])
        {
            return 'Congrats, ' . $data['name'] . '!';
        }else{
            return 'Error! Registeration bad!';
        }
            
        
    }


    
}