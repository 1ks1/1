<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SQL</title>
</head>
<body>
        <?PHP
            if(isset($s))
            if(is_array($s))
            {
                foreach($s as $v)
                {
                    if(is_array($v))
                    {
                        foreach($v as $b){echo $b."<br />";}
                    }else{
                    echo $v."<br />";
                    }
                }
            }else{echo $s;}
            
            if(isset($ins))
            print_r("<br />".$ins."<br />");

            if(isset($upd))
            print_r("<br />".$upd."<br />");

            if(isset($del))
            print_r("<br />".$del."<br />");
   
        ?>
</body>
</html>