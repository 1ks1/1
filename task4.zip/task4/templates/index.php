<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SQL</title>
</head>
<body>
        <?PHP
            $sql = new Sql(DATABASE,'TEST');
            echo '<b>=== test SELECT === </b><br />';
            $arrayd = $sql->sq('name','id=1');
                if(is_array($arrayd))
                foreach($arrayd as $key => $val)
                {
                    print_r($val['name'])."<br />";
                }else{print_r($arrayd)."<br />";}     
                
            echo '<br /><b>=== test SELECT * === </b><br />';
            echo $sql->sq('*','id=1')."<br/>";

            echo '<br /><b>=== OTHER WILL BE SOON === </b><br />';
            echo '<br />';
            $sql->iq('name','id=1');
            echo '<br />';
            $sql->uq('name','id=1');
            echo '<br />';
            $sql->dq('name','id=1');
        ?>
</body>
</html>