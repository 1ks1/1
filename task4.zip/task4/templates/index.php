<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SQL</title>
    <style>
    body{margin:0;padding:0;}
    .main{padding: 0 100px;background:linear-gradient(#eef,#fff);}
    .bd
    {   width:100%;
        height:20px;
        background:linear-gradient(#ccc,#fff,#444);
        box-shadow:0 5px 5px #333;
        text-shadow:0 0 3px #000;
        margin:0 0 25px 0;
    }
    table
    {
        text-shadow:0 0 2px #000;
        font-size:12px;
        margin:1px;
    }
    </style>
</head>
<body>
<div class="main">
        <div class="bd">MySQL</div>
        <?PHP
            if(isset($hText))
            foreach($hText as $ht)
            {
                echo $ht;
            }
        ?>
        <div class="bd">PostgreSQL</div>
        <?PHP 
            if(isset($hText2))
            foreach($hText2 as $ht2)
            {
                echo $ht2;
            }
        ?>
</div>
</body>
</html>