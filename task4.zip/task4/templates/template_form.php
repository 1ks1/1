    <form action="" method="POST">
        <br />examples[ insert into TEST (id,name) values (2,'Vasilij') ]<br />
        or [DELETE FROM TEST WHERE id=2]<br />
        SHOW TABLES<br />drop table table_name<br />DESC tablename<br />
        <pre>
        [CREATE TABLE CUSTOMERS(
   ID   INT              NOT NULL,
   NAME VARCHAR (20)     NOT NULL,
   AGE  INT              NOT NULL,
   ADDRESS  CHAR (25) ,
   SALARY   DECIMAL (18, 2),       
   PRIMARY KEY (ID))]</pre><br />
         DB_name: <input type="text" name="databasename" value="user11"><br />
        <input type="submit" name="send_test" value="sndquery">
        <input type="text" name="sql_test" value="SELECT name FROM TEST" size="40">
        <br /><br />
    </form>