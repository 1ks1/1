<?PHP
    if(isset($_POST))
    {
        echo "DEBUG POSTS:<hr />";
        print_r($_POST);
    }

    $cl = new SQLB;


    if(isset($_POST['sql_test']))
    {echo "<hr />Q:<br />";
     $res = $cl->msql_conn($_POST['sql_test']);
        if(is_array($res))
        {
        foreach ($res as $col) 
            {
                echo "<br /> --------  <br />";
                print_r($col);
            }
        }else
        echo $res;  
    }

?>