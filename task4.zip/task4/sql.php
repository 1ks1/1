<?PHP

    class SQL
    {

        protected $tables;
        protected $fields;
        protected $uslovija;
        protected $database;
        protected $table;

        public function setTable(){
            $this->fields[] = $_POST['sql_table'];
        }
        public function setFields(){
            $this->table[] = $_POST['sql_fields'];
        }


        protected function select()
        {  
            $this->msql_conn();
            $result = "select * from TEST";
            return $result;
        }


    }


    class SQLB extends SQL
    {
        private $sqlstr;
        private $method;
        protected $link;
        protected $condb;
        private $result = array();

        public function msql_conn($query)
        {
            $qr=$query;
            return $this->msql_con($qr);
        }


        function getConn(){
            return $this->conn;
        }
        function setConn($c){
            $this->conn = $c;
        }
        function setDbName($db){
            $this->database = $db;
        }

        public function Method()
        {
            $m=stripos ( $this->sqlstr , 'SELECT' );
            return $m;
        }


        function getDBconnectLink()
        {
            $lnk = mysql_connect(LOCALHOST, USER, PASSWORD);
            mysql_select_db(DATABASE, $lnk) or die ($result = 'I cant select '.DATABASE.' : '.mysql_error());

            return $lnk;
        }


        function msql_con($qr)
        {   $q=$qr;
            $lnk = $this->getDBconnectLink();
                if ($lnk) 
                {
                    //set charset
                    mysql_query("set names 'utf8'");
                    $res = mysql_query($q);
                    $this->result = "";
                        if (!$res) 
                        {
						    die($this->result ='Wrong query: ' . mysql_error());
						}else{
                            while ($line = mysql_fetch_assoc($res)) 
                            {
							    $this->result[] = $line;
							}
						}
                }else{
                    $this->result = "Have no connect with DB";
                }
                    //echo "<br />рву линк<br />";
                    mysql_close($lnk);
                    return $this->result;
        }
    }


?>