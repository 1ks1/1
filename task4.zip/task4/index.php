<?PHP
include('config.php');
include('libs/Sql.php');
            $table = 'TEST';
            $db = DATABASE;
            $what = 'Sofia';
            $where = 'id=3';
            $column = 'name';
            $limit = 10;
            $sql = new Sql($db,$table,$what,$where,$limit,$column);
            // s - select, i = insert, d = delite, u = update
            //$ins = $sql->query('i'); //INSERT INTO
            $s = $sql->query('s'); //SELECT
            //$upd = $sql->query('u'); //UPDATE
            //$del = $sql->query('d'); //DELETE
include('templates/index.php');

?>