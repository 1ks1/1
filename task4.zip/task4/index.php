<?PHP
include('config.php');
include('libs/Sql.php');
include('libs/PostgeSQL.php');

            $schema = 'TEST.';
            $table = 'TEST';
            $db = DATABASE;
            $what = 'name';
            $where = 'id=8';
            $column = 'name';
            $limit = 10;
            $values = '';

            $sql = new Sql($db,$table,$what,$where,$limit,$column);
            $pgs = new PS($db,$schema.$table,$what,$where,$limit,$column);
            
            

            //SQL
            $s = array();
            //f(str(table),str(fields),str(where))
            $s[] = $sql->selectQuery($table,'id, name','name LIKE \'%%\' ');
            $what = 'id, name';
            $values = "100, 'TeSt' ";
            $s[] = $sql->inserttQuery($table,$what,"100,'SinglPlayer'"); //INSERT INTO
            $s[] = $sql->selectQuery($table,'id, name','name LIKE \'%%\' ');

            $rv = array('id'=>100,'name'=>'UpdatedName');
            //f(str(table),array(params),str(where))
            $s[] = $sql->updateQuery($table,$rv,'id=100'); //UPDATE
            $s[] = $sql->selectQuery($table,'id, name','name LIKE \'%%\' ');
            $col = 'id';
            $val = 100;
            $rd = array('id'=>100);
            $s[] = $sql->delQuery($table,$rd);
            $s[] = $sql->selectQuery($table,'id, name','name LIKE \'%%\' ');

            
            
            ///PSQL
            $s2 = array();
            $what ='id, name';
            $table="test.test";
            $where = "";
            $s2[] = $pgs->selectQuery($table,$what,$where); 
            $s2[] = $pgs->insertQuery($table,$what,"200,'Network'"); 
            $s2[] = $pgs->selectQuery($table,$what,$where); 
            $rv = array('id'=>200,'name'=>'UpdatedNetwork');
            $s2[] = $pgs->updateQuery($table,$rv,'id=200'); //UPDATE
            $s2[] = $pgs->selectQuery($table,$what,$where); //SELECT
            $col = 'id';
            $val = 100;
            $condition = array('id'=>200);
            $s2[] = $pgs->delQuery($table,$condition);
            $s2[] = $pgs->selectQuery($table,$what,$where); //SELECT
            
            unset($hText);
            if(isset($s))
            {       
                    
                    $tSel = '';
                    foreach($s as $v)
                    {
                        if(is_array($v))
                        {
                            foreach($v as $b){$tSel .= $b."<br />";}
                        }else{
                            $tSel .= $v."<br />";
                            $hText[]= $v;
                        }
                    }
            }else{$tSel = '';}

            ////pSql vars/////////////
            unset($hText2);
            if(isset($s2))
            {     
                    $tSel2 = '';
                    foreach($s2 as $v2)
                    {
                        if(is_array($v2))
                        {
                            foreach($v2 as $b2){$tSel .= $b2."<br />";}
                        }else{
                            $tSel2 .= $v2."<br />";
                            $hText2[]= $v2;
                        }
                    }
            }else{$tSel2 = '';}
            

include('templates/index.php');

?>