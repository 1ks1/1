<?PHP
    include('config.php');
    include('libs/sql.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SQL</title>
</head>
<body>
<?PHP
include('templates/template_form.php');
include('templates/template.php');
?>
</body>
</html>