<?PHP
include('config.php');
include('libs/Sql.php');
include('templates/index.php');
?>