    <form action="" method="POST">
        <br />for example[ insert into TEST (id,name) values (2,'Vasilij') ]<br />
        <input type="submit" name="send_test" value="send_test">
        <input type="text" name="sql_test" value="SELECT name FROM TEST" size="40">
        <br /><br />
    </form>