<?PHP

    class SQLquery
    {
        protected $where;
        protected $what;
        protected $db;
        protected $table;
        protected $limit;


        function __construct()
        {
        }

        public function Qvalid($fields)
        {
            if(strpos($fields, '*') === false)
            return true;
            return false;

        }

        public function select()
        {
            if($this->Qvalid($this->what))
                return "SELECT '$this->what' FROM $this->table WHERE $this->where";
                return false;
        }
        public function insert()
        {
            if($this->Qvalid($this->what))
                return "INSERT INTO $this->table SET $this->columns='$this->what'";
                return false;
        }
        public function update()
        {
            if($this->Qvalid($this->what))
                return "UPDATE $this->table SET $this->columns='$this->what' WHERE $this->where";
                return false;
        }
        public function delete()
        {
            if($this->Qvalid($this->what))
                return " DELETE FROM $this->table WHERE $this->where";
                return false;
        }
    }

    class Sql extends SQLquery 
    {
        
        
        function __construct($db,$table,$what,$where,$limit,$columns)
        {
            $this->db = $db;
            $this->table = $table;
            $this->what = $what;
            $this->where = $where;
            $this->limit = $limit;
            $this->columns = $columns;
        }

        
        function dbConnect()
        {
            $lnk = mysql_connect(HOST, USER, PASSWD);
            mysql_select_db($this->db, $lnk) or die ($result = 'I cant select '.
            $this->db.' : '.mysql_error());
            mysql_query("set names 'utf8'");
            return $lnk;
        }



        function query($m)
        {
            switch($m)
            {
                case 's':
                $query=$this->select();
                break;
                case 'i':
                $query=$this->insert();
                break;
                case 'd':
                $query=$this->delete();
                break;
                case 'u':
                $query=$this->update();
                break;
            }

            $l = $this->dbConnect();
            if($query !== false)
            {
                if (!$l) 
                {
				    die($result ='Wrong query: ' . mysql_error());
			    }else{
                    $res = mysql_query($query);
                       $st = '';
                        $arr = mysql_fetch_assoc($res);
                        

                        foreach($arr as $key=>$v)
                        {
                            $st .= $v;
                        }

                        //fi SQL ERROR
                        $r = $st."<hr />".mysql_error($l)."<br />";
                    return $r;
                    
                }
            }else{$result = 'Error! Coz [*] is danied.';}
            return $result;
            
        }

    }
?>