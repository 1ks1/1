<?PHP

    class SQLquery
    {
        protected $fields;
        protected $query;
        protected $db;
        protected $table;



        public function setDB($db,$table)
        {
            $this->db = $db;
            $this->table = $table;
        }

        public function Qvalid($fields)
        {
            if(strpos($fields, '*') === false)
            return true;
            return false;

        }

        public function select($fields,$where)
        {
            if($this->Qvalid($fields))
                return "SELECT $fields FROM $this->table WHERE $where";
                return false;
        }
        public function insert($fields,$where)
        {
            if($this->Qvalid($fields))
                return "INSERT $this->table VALUES $fields WHERE $where";
                return false;
        }
        public function update($fields,$where)
        {
            if($this->Qvalid($fields))
                return "UPDATE $this->table SET $fields WHERE $where";
                return false;
        }
        public function delete($fields,$where)
        {
            if($this->Qvalid($fields))
                return " DELETE FROM $this->table WHERE $where";
                return false;
        }
    }

    class Sql extends SQLquery 
    {
        protected $res;
        function __construct($db,$table)
        {
            $this->setDB($db,$table);
        }


        
        function dbConnect($q)
        {
            $lnk = mysql_connect(HOST, USER, PASSWD);
            mysql_select_db($this->db, $lnk) or die ($result = 'I cant select '.
            $this->db.' : '.mysql_error());
            mysql_query("set names 'utf8'");
            $this->res = mysql_query($q);
            return $this->res;
        }



        function sq($fields,$b)
        {
            echo "Q=".$this->select($fields,$b)."<br />";
            $query=$this->select($fields,$b);
            if($query)
            if (!$this->dbConnect($query)) 
            {
				die($result ='Wrong query: ' . mysql_error());
			}else{
                while ($line = mysql_fetch_assoc($this->res)) 
                {
                    $result[] = $line;
                }
            }else{$result = 'Error! Coz [*] is danied.';}
            
            return $result;
            
        }

        
        function iq($fields,$b)
        {
            print_r('INSERT');
            //echo $this->insert($fields,$b);
        }
        function uq($fields,$b)
        {
            print_r('UPDATE');
            //echo $this->update($fields,$b);
        }
        function dq($fields,$b)
        {
            print_r('DELETE');
            //echo $this->delete($fields,$b);
        }
    }
?>