<?PHP

    class SQLquery
    {
        protected $fields;
        protected $query;
        protected $db;
        protected $table;



        public function setDB($db,$table)
        {
            $this->db = $db;
            $this->table = $table;
        }

        public function Qvalid($fields)
        {
            if(strpos($fields, '*') === false)
            return true;
            return false;

        }

        public function select($fields,$where)
        {
            if(strpos($fields, '*') === false)
                return "SELECT $fields FROM $this->table WHERE $where";
                return 'Error! [* is denied]';
        }
        public function insert($fields,$where)
        {
            if(strpos($fields, '*') === false)
                return "INSERT $this->table VALUES $fields WHERE $where";
                return 'Error! [* is denied]';
        }
        public function update($fields,$where)
        {
            if(strpos($fields, '*') === false)
                return "UPDATE $this->table SET $fields WHERE $where";
                return 'Error! [* is denied]';
        }
        public function delete($fields,$where)
        {
            if(strpos($fields, '*') === false)
                return " DELETE FROM $this->table WHERE $where";
                return 'Error! [* is denied]';
        }
    }

    class Sql extends SQLquery 
    {
        function __construct($db,$table)
        {
            $this->setDB($db,$table);
        }


        




        function sq($fields,$b)
        {
            echo $this->select($fields,$b);
        }
        function iq($fields,$b)
        {
            echo $this->insert($fields,$b);
        }
        function uq($fields,$b)
        {
            echo $this->update($fields,$b);
        }
        function dq($fields,$b)
        {
            echo $this->delete($fields,$b);
        }
    }
?>