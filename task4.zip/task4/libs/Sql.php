<?PHP

    class SQLquery
    {
        protected $where;
        protected $what;
        protected $db;
        protected $table;
        protected $limit;
        protected $lnk;
        protected $query;
        protected $values;
        protected $arr;


        function __construct()
        {
        }

        public function Qvalid($fields)
        {   
            $fld = $fields;
            if(is_array($fields)){$fld = implode($fields);}
            if(strpos($fld, '*') === false)
            return true;
            return false;

        }

        public function select()
        {
            if($this->Qvalid($this->what))
                return "SELECT $this->what FROM $this->table WHERE $this->where LIMIT $this->limit";
                return false;
        }
        public function insert()
        {
            if($this->Qvalid($this->what))
                return "INSERT INTO $this->table ($this->what) VALUES ($this->values)";
                return false;
        }
        public function update()
        {
            if($this->Qvalid($this->what))
            {
                $gg = "UPDATE $this->table SET ";
                if(is_array($this->what))
                foreach($this->what as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= "$k=$v ,";
                    }else{  $gg .= "$k='$v' ,";}
                }
                
                $gg = rtrim($gg, ',');
                $gg .= "WHERE $this->where";
            }
            return $gg;
            return false;    
                
        }

        public function delete()
        {
            if($this->Qvalid($this->arr))
            {
                $gg = "DELETE FROM $this->table WHERE ";
                if (is_array($this->arr))
                foreach($this->arr as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= $k.'='.$v.',';
                    }else{   $gg .= $k.'=\''.$v.'\',';}
                }
                $gg = rtrim($gg, ',');
                return $gg;
            }
                
                return false;
        }

        function generateHtmlResult($q,$r)
        {   $html = '<table class="table-bordered">';
            $html .= '<tr><td>'.$q.'</td></tr>';
            $html .= '<tr><td>'.$r.'</td></tr>';
            $html .= '</table>';
            return $html;
        }


    }

    class Sql extends SQLquery 
    {
        
        
        function __construct($db,$table,$what,$where,$limit,$columns)
        {
            $this->db = $db;
            $this->table = $table;
            $this->what = $what;
            $this->where = $where;
            $this->limit = $limit;
            $this->columns = $columns;
        }

        
        function dbConnect()
        {
            $this->lnk = mysql_connect(HOST, USER, PASSWD);
            mysql_select_db($this->db, $this->lnk) or die ($result = 'I cant select '.
            $this->db.' : '.mysql_error());
            mysql_query("set names 'utf8'");
            return $this->lnk;
        }
        function dbClose()
        {
            mysql_close ($this->lnk);
            unset($this->lnk);
        }


            function selectQuery($table,$what,$where,$limit='10')
            {
                $this->table = $table;
                $this->what = $what;
                $this->where = $where;
                $this->limit = $limit;
                $this->query=$this->select();

                $this->lnk = $this->dbConnect();
                if(($this->query !== false) && ($this->lnk))
                $r = '';

                if($fff = mysql_query($this->query))
                while($arr = mysql_fetch_assoc($fff))
                {
                    if($arr)
                    foreach($arr as $key=>$v)
                    {
                        $r .= $v." | ";
                    }

                    //if SQL ERROR
                $r .=  "<br />".mysql_error($this->lnk);
                }
                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            
            }
    
            function inserttQuery($table,$what,$values)
            {
                $this->what = $what;
                $this->values =$values;
                $this->table = $table;
                $this->lnk = $this->dbConnect();
                $this->query=$this->insert();

                if(($this->query !== false) && ($this->lnk))
                if(!mysql_query($this->query))
                {
                    $r = mysql_error($this->lnk);
                }else{
                    $r ='OK';
                }
                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            }
            
            function updateQuery($table,$what,$where)
            {
                $this->what = $what;
                $this->where =$where;
                $this->table = $table;
                $this->lnk = $this->dbConnect();
                $this->query=$this->update();

                if(($this->query !== false) && ($this->lnk))
                if(!mysql_query($this->query))
                {
                    $r = mysql_error($this->lnk);
                }else{
                    $r ='OK';
                }
                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            }

            function delQuery($table,$arr)
            {
                $this->arr = $arr;
                $this->table = $table;
                $this->lnk = $this->dbConnect();
                $this->query=$this->delete();

                if(($this->query !== false) && ($this->lnk))
                {
                    if(!mysql_query($this->query))
                    {
                        $r = mysql_error($this->lnk);
                    }else{
                        $r ='OK';
                    }
                }else{$r ='Err. query bad or link_db bad';}

                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            }

    }
?>