<?PHP

    class SQL
    {

        protected $tables;
        protected $fields;
        protected $uslovija;
        protected $database;
        protected $table;

        public function setTable(){
            $this->fields[] = $_POST['sql_table'];
        }
        public function setFields(){
            $this->table[] = $_POST['sql_fields'];
        }


        protected function select()
        {  
            $this->msql_conn();
            return $result;
        }


    }




    ///child class
    class SQLB extends SQL
    {
        private $sqlstr;
        private $method;
        protected $link;
        protected $condb;
        private $result = array();

        public function msql_conn($query)
        {
            $qr=$query;
            ////filter// * //filter///
            //if (strripos ( string $qr , '*' )>0)
            //{
            // return " (*) Error!";
            //}

            $r = explode(' ',strtolower (trim($qr)));
            $re = strtolower ($r[0]);
            echo $re;
            switch ($re) {
                case "select":
                    return $this->msql_con($qr);
                    break;
                case "desc":
                    return $this->msql_con($qr);
                    break;
                case "show":
                    return $this->msql_con($qr);
                    break;
                default:
                    return $this->msql_notselect($qr);
                    break;
            }
            
        }

        function getDBconnectLink($database=DATABASE)
        {
            $database=trim($database);
            if(isset($_POST['databasename'])&&strlen(trim($_POST['databasename']))>0)
            $database=trim($_POST['databasename']);
            $lnk = mysql_connect(LOCALHOST, USER, PASSWORD);
            mysql_select_db(DATABASE, $lnk) or die ($result = 'I cant select '.
            DATABASE.' : '.mysql_error());
            return $lnk;
        }

         //if nead string or array answear
        function msql_con($qr)
        {   $q=$qr;
            $lnk = $this->getDBconnectLink();
                if ($lnk) 
                {
                    //set charset
                    mysql_query("set names 'utf8'");
                    $res = mysql_query($q);
                    $this->result = "";
                        if (!$res) 
                        {
						    die($this->result ='Wrong query: ' . mysql_error());
						}else{
                                while ($line = mysql_fetch_assoc($res)) 
                                {
                                    $this->result[] = $line;
                                }
						}
                }else{
                    $this->result = "Have no connect with DB";
                }
                    //echo "<br />рву линк<br />";
                    mysql_close($lnk);
                    return $this->result;
        }





        //if nead FOLS/TRUE
        function msql_notselect($qr)
        {   $q=$qr;
            $lnk = $this->getDBconnectLink();
                if ($lnk) 
                {
                    //set charset
                    mysql_query("set names 'utf8'");
                    $res = mysql_query($q);
                    $this->result = "";
                        if (!$res) 
                        {
						    die($this->result ='Wrong query: ' . mysql_error());
						}else{
                                    $this->result[] = true;
						}
                }else{
                    $this->result = "Have no connect with DB";
                }
                    mysql_close($lnk);
                    return $this->result;
        }


    }


?>