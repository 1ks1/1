<?PHP

    class PostgreeSQL
    {
        protected $where;
        protected $what;
        protected $db;
        protected $table;
        protected $limit;
        protected $lnk;
        protected $query;
        protected $values;
        protected $arr;


        function __construct()
        {
        }

        public function Qvalid($fields)
        {   
            $fld = $fields;
            if(is_array($fields)){$fld = implode($fields);}
            if(strpos($fld, '*') === false)
            return true;
            return false;

        }

        public function select()
        {
            $w="";
            if(strlen($this->where)>0){$w = " WHERE $this->where";}
            if($this->Qvalid($this->what))
            {
                return "SELECT $this->what FROM $this->table $w";
                //return "SELECT * FROM test.test";
            }
                return false;
        }
        public function insert()
        {
            if($this->Qvalid($this->what))
                return "INSERT INTO $this->table ($this->what) VALUES ($this->values)";
                return false;
        }
        public function update()
        {
            if($this->Qvalid($this->what))
            {
                $gg = "UPDATE $this->table SET ";
                if(is_array($this->what))
                foreach($this->what as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= "$k=$v ,";
                    }else{  $gg .= "$k='$v' ,";}
                }
                $gg = rtrim($gg, ',');
                $gg .= "WHERE $this->where";
            }
            return $gg;
            return false;    
                
        }

        public function delete()
        {
            if($this->Qvalid($this->arr))
            {
                $gg = "DELETE FROM $this->table WHERE ";
                if (is_array($this->arr))
                foreach($this->arr as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= $k.'='.$v.',';
                    }else{   $gg .= $k.'=\''.$v.'\',';}
                }
                $gg = rtrim($gg, ',');
                return $gg;
            }
                
                return false;
        }

        function generateHtmlResult($q,$r)
        {   $html = '<table class="table-bordered">';
            $html .= '<tr><td>'.$q.'</td></tr>';
            $html .= '<tr><td>'.$r.'</td></tr>';
            $html .= '</table>';
            return $html;
        }


    }

    class PS extends PostgreeSQL 
    {
        
        
        function __construct($db,$table,$what,$where,$limit,$columns)
        {
            $this->db = $db;
            $this->table = $table;
            $this->what = $what;
            $this->where = $where;
            $this->limit = $limit;
            $this->columns = $columns;
        }

        
        function dbConnect()
        {
            $constr = "host=".HOST." port=5432 dbname=".DATABASE_PG." user=".USER_PG." password=".PASSWD_PG;
            $this->lnk = pg_connect($constr);
            return $this->lnk;
        }
        function dbClose()
        {
            pg_close ($this->lnk);
            unset($this->lnk);
        }


            function selectQuery($table,$what,$where='',$limit='10')
            {
                $this->table = $table;
                $this->what = $what;
                $this->where = $where;
                $this->limit = $limit;
                $this->query=$this->select();

                $this->lnk = $this->dbConnect();
                if(($this->query !== false) && ($this->lnk))
                $r = '';
                //ask db
                if(is_resource($ff = pg_query ($this->query)))
                {
                    //get array from DB
                    while($arr = pg_fetch_assoc($ff))
                    {
                    
                        foreach($arr as $v)
                        {
                            $r .= $v." | ";
                        }

                    //if SQL ERROR
                    $r .=  "<br />";//.pg_result_error($this->lnk);
                    }
                }else{$r = pg_last_error($fff);}
                
                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            
            }
    


            
            function insertQuery($table,$what,$values)
            {
                $this->what = $what;
                $this->values =$values;
                $this->table = $table;
                $this->lnk = $this->dbConnect();
                $this->query=$this->insert();

                if(($this->query !== false) && ($this->lnk))
                if(!pg_query($this->query))
                {
                    $r = mysql_error($this->lnk);
                }else{
                    $r ='OK';
                }
                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            }
            
            function updateQuery($table,$what,$where)
            {
                $this->what = $what;
                $this->where =$where;
                $this->table = $table;
                $this->lnk = $this->dbConnect();
                $this->query=$this->update();

                if(($this->query !== false) && ($this->lnk))
                if(!pg_query($this->query))
                {
                    $r = mysql_error($this->lnk);
                }else{
                    $r ='OK';
                }
                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            }

            function delQuery($table,$arr)
            {
                $this->arr = $arr;
                $this->table = $table;
                $this->lnk = $this->dbConnect();
                $this->query=$this->delete();

                if(($this->query !== false) && ($this->lnk))
                {
                    if(!pg_query($this->query))
                    {
                        $r = mysql_error($this->lnk);
                    }else{
                        $r ='OK';
                    }
                }else{$r ='Err. query bad or link_db bad';}

                $this->dbClose();
                return $this->generateHtmlResult($this->query,$r);
            }

    }
?>