<?PHP
include ('config.php');
include('libs/Calc.php');
include('templates/index.php');
?>
