<?PHP
include('calc.php');
include('functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TestCalc</title>
</head>
<body>
    <form method="POST" action="">
    <input type="text" name="a" /><br />
    <input type="text" name="b" /><hr />
    +<input type="radio" name="operation" value="+" checked="true" /> 
    -<input type="radio" name="operation" value="-" /> 
    /<input type="radio" name="operation" value="/" /> 
    *<input type="radio" name="operation" value="*" /> 
    <input type="submit" value="=" name="calc" /><br /><br />
    <input type="submit" value="C" name="Clear" />
    <input type="submit" name="button_1" value="M+" />
    <input type="submit" name="button_2" value="M-" />
    <input type="submit" name="button_3" value="MR" />
    <input type="submit" name="button_4" value="MC" />
    </form><hr />
    <?PHP 
        include('template.php');
    ?>
</body>
</html>