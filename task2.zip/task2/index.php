<?PHP
include ('config.php');
include('libs/Calc.php');
$cl = new Calc(3,5);
$a = $cl->geta();
$b = $cl->getb();
$memory = $cl->setMem(7);
$c = $cl->getMem(2);
echo "[ a=$a , b=$b, m=$c]<br />";
include('templates/index.php');
?>
