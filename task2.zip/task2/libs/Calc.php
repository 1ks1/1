<?PHP

class Calc
{
    private $a;
    private $b;
    protected $memory;
        

    function __construct ($a,$b)
    {
        $this->a = (int)$a;
        $this->b = (int)$b;
        $this->memory = (int)0;
    }


    public function clearAll()
    {
        
        $this->memory = (int)0;
        $this->a = (int)0;
        $this->b = (int)0;
        return true;
    }

    public function getMem()
    { 
        return $this->memory;
    }
    public function setMem($a)
    { 
        $this->memory = (int)$a;
        return $this->memory;
    }
    

    public function memPlus()
    {   
        return ($this->a + $this->memory);
    }
    public function memClear()
    {
        $this->memory = (int)0;
        return true;
    }
    public function memMinus()
    {
        $this->memory = ($this->memory - (int)$this->a);
        return true;
    }
    
    public function plus()
    {
        return ((int)$this->a + (int)$this->b);
    }

    public function minus()
    {
        return ((int)$this->a - (int)$this->b);
    }

    public function division()
    {
        if($this->b == 0)
        return EZ1;
        return ((int)$this->a / (int)$this->b);
    }

    public function multiplication()
    {
        return ((int)$this->a * (int)$this->b);
    }

    public function square()
    {
        return sqrt ((int)$this->a);
    }

    public function onDivTo()
    {
        if($this->a == 0)
        return EZ1;
        return ((int)1 / (int)$this->a);
    }
    
    public function seta($a)
    {
        $this->a = $a;
    }
    public function setb($ab)
    {
        $this->b = $b;
    }

    public function geta()
    {
        return$this->a;
    }
    public function getb()
    {
        return$this->b;
    }

    function __destruct()
    {          
    }
}
?>