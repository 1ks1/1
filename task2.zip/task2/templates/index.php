<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>calc</title>
</head>
<body>
    <?PHP 
       
    ?>
    <hr />
    <table border="1">
        <tr><td>/</td><td><?PHP echo $cl->division(); ?></td></tr>
        <tr><td>-</td><td><?PHP echo $cl->minus(); ?></td></tr>
        <tr>
            <td>+</td>
            <td><?PHP echo $cl->plus(); ?></td>
        </tr>
        <tr>
            <td>*</td>
            <td><?PHP echo $cl->multiplication(); ?>
            </td>
        </tr>
        <tr><td>1/x</td><td><?PHP echo $cl->onDivTo(); ?></td></tr>
        <tr><td>sqrt</td><td><?PHP echo $cl->square(); ?></td></tr>
        <tr><td>M+</td><td><?PHP echo $cl->memPlus(); ?></td></tr>
        <tr><td>M-</td><td><?PHP echo $cl->memMinus(); ?></td></tr>
        <tr><td>MS</td><td><?PHP echo $cl->getMem(); ?></td></tr>
        <tr><td>MR</td><td><?PHP echo $cl->memClear(); ?> (1/0 = true/false)</td></tr>
    </table>
</body>
</html>