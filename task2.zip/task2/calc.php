<?PHP
session_start();
class Calc
{
private $a,$b,$o,$M;
    
    public function clearAll()
    {
        
        $this->M = 0;
        $this->a = 0;
        $this->b = 0;
        $this->o = "";
        $_SESSION['Memory'] = 0;
        $_SESSION['LastRes'] = 0;
    }

    public function getMem()
    { 
        $this->M = $_SESSION['Memory'];
        return $this->M;
    }

    public function memPlus()
    {   
        if (!$_SESSION['LastRes'] == 0)
        {
            $_SESSION['Memory'] += $_SESSION['LastRes'];
            return $_SESSION['Memory'];
        }
        return $_SESSION['Memory'];
    }
    public function memClear()
    {
        $_SESSION['Memory'] = 0;
        return $_SESSION['Memory'];
    }
    public function memMinus()
    {
        if (!$_SESSION['LastRes'] == 0)
        {
            $_SESSION['Memory'] -= $_SESSION['LastRes'];
        }
        return $_SESSION['Memory'];
    }
    
    public function calculate()
    {
        if(isset($_POST['a'])&&isset($_POST['b'])&&isset($_POST['operation']))
        {
            $o = $_POST['operation'];
            $a = ($_POST['a']);
            $b = ($_POST['b']);
            $result = 0;
            switch ($o) 
            {
                case "+":
                $result = $a+$b;
                $_SESSION['LastRes']=$result;
                break;
                case "-":
                $result = $a-$b;
                $_SESSION['LastRes']=$result;
                break;
                case "/":
                $result = $a/$b;
                $_SESSION['LastRes']=$result;
                break;
                case "*":
                $result = $a*$b;
                $_SESSION['LastRes']=$result;
                break;
            }
        $this->lastres = $result;
        return $result;
        }else{return "calculate parameters error";}
    }


    public function set_a($A)
    {
        $this->a = $A;
    }

    public function set_b($B)
    {
        $this->b = $B;
    }

    public function get_a($A)
    {
        return $this->a;
    }

    public function get_b($B)
    {
        return $this->b;
    }

    function __construct()
    { 
                      
    }
    function __destruct()
    {          
    }
}
?>