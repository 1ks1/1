<?PHP
if($_SESSION)
$mm = $_SESSION['Memory'];
if (!$mm == 0)
    echo "&#128276;M <br />";

if (isset($_POST['calc']))
{
    echo $cl->calculate();
}

if (isset($_POST['button_3']))
    echo "<br /> m ".$_SESSION['Memory']."<br />";
?>