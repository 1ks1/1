<?PHP
$cl = new Calc;
if (isset($_POST['Clear']))
{   
    $cl->clearAll();
    unset($_POST['a']);
    unset($_POST['b']);
    unset($_POST['operation']);
    unset($_POST['Clear']);
}

if (isset($_POST['button_1']))
{
    $cl->memPlus();
}
if (isset($_POST['button_4']))
{
    $cl->memClear();
}
if (isset($_POST['button_2']))
{
$cl->memMinus();
}
if (isset($_POST['button_2']))
?>