<?PHP
define( "EZ1","Error! Division by zero.");
?>