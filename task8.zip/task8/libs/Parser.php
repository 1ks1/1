<?PHP

class Parser
{
    protected $myUrl;
    protected $result;
    protected $ch;
    function __constract()
    {
    }

    function setResult($s)
    {
        $this->result = $s;
    }
    function getResult()
    {
        return $this->result;
    }

    function getPageResultSerch($q)
    {
        $fp = fopen (dirname(__FILE__)."/google.txt", "w");
        $this->ch = curl_init($this->myUrl);
        $useragent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3717.0 Safari/537.36';
        $this->myUrl=('http://www.google.com/search?hl=en&tbo=d&site=&source=hp&q='.$q."&num=1");

        $options = Array(
            CURLOPT_RETURNTRANSFER => TRUE,  
            CURLOPT_FOLLOWLOCATION => TRUE,  
            CURLOPT_AUTOREFERER => TRUE,
            CURLOPT_HEADER => 0,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 120,  
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_USERAGENT => $useragent,
            CURLOPT_URL => $this->myUrl, 
            CURLOPT_HTTPHEADER => array("Content-Type: application/text"),
            CURLOPT_REFERER => "http://www.google.com/",
            CURLOPT_HTTPHEADER => array('Content-Length: 0'),
            CURLOPT_FILE => $fp,
            );
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($this->ch, CURLOPT_COOKIEJAR, dirname(__FILE__).'/my_cookies.txt');
        curl_setopt_array($this->ch, $options);
        $data = curl_exec ($this->ch);
        curl_close($this->ch);
        fclose($fp);
    }

}

$cS = new Parser;

if(isset($_GET['search']))
{
        $cS->getPageResultSerch($_GET['search']);
        if (file_exists(dirname(__FILE__).'/google.txt'))
        $datafile = file(dirname(__FILE__).'/google.txt');
        $datafile2 = array();
        $key = false;
        if(is_array($datafile))
        print_r($datafile);
        foreach($datafile as $str)
        {
            if(! strripos ( $str , '<body>' ) === false)
                $key = true;
            if(! strripos ( $str , '</body>' ) === false)
                $key = false;

            if($key)
            $datafile2[]=$str;
        }
        file_put_contents ( dirname(__FILE__).'/google2.txt' , $datafile2);
        $cS->setResult($datafile2);
        //print_r($datafile);
}


?>