<?PHP

class Parser
{
    protected $myUrl;
    protected $result;
    protected $ch;
    protected $uAg;
    function __constract()
    {
    }

    function setResult($s)
    {
        $this->result = $s;
    }
    function getResult()
    {
        return $this->result;
    }

    function getPageResultSerch($q)
    {
        $fp = fopen (dirname(__FILE__)."/google.txt", "w");
        $this->ch = curl_init($this->myUrl);
        $useragent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3717.0 Safari/537.36';
        $this->myUrl=('http://www.google.com.ua/search?hl=en&q='.$q."&num=1");
        //$this->myUrl=('https://worldoftanks.ru/ru/community/accounts/79274938-666__TAHKUCT__666/');

        $options = Array(
            CURLOPT_RETURNTRANSFER => TRUE,  
            CURLOPT_FOLLOWLOCATION => TRUE,  
            CURLOPT_AUTOREFERER => TRUE,
            CURLOPT_HEADER => 0,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 120,  
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_USERAGENT => $useragent,
            CURLOPT_URL => $this->myUrl, 
            CURLOPT_HTTPHEADER => array("Content-type: text/html; charset=utf-8"),
            //CURLOPT_HTTPHEADER => array("Content-Type: application/text"),
            CURLOPT_REFERER => "http://www.google.com.ua/",
            CURLOPT_HTTPHEADER => array('Content-Length: 0'),
            CURLOPT_FILE => $fp,
            );
        curl_setopt_array($this->ch, $options);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($this->ch, CURLOPT_COOKIEJAR, dirname(__FILE__).'/my_cookies.txt');
        
        $data = curl_exec ($this->ch);
        $this->setResult($data);
        curl_close($this->ch);
        fclose($fp);
    }

}

$cS = new Parser;

if(isset($_GET['search']))
{
        $cS->getPageResultSerch($_GET['search']);
        if (file_exists(dirname(__FILE__).'/google.txt'))
        $datafile = file(dirname(__FILE__).'/google.txt');
        
        $str=implode($datafile);
        $prrg = '#<h3.class=\"LC20lb\"(.+?)<\/h3>#su';
        $prrg2 = '#<span.class=\"st\"(.+?)<\/span>#su';
        $pr_r = '#(?<=(<div class=\"r\".+?<\/div>))(<a href=\".*?<\/a>)#su';
        preg_match_all($prrg, $str, $res);
       
        preg_match_all($prrg2, $str, $res3);
        if(count($res[0])>0)
        print_r($res[0][0]);

        if(count($res3[0])>0)
        print_r($res3[0][0]);
        


        
        

        //preg_match_all($prrg, $datafile, $num_all);
        $fs ='';
        foreach($datafile as $n)
        {
            preg_match_all($prrg, $n, $nl);
            //print_r($nl[0]);
            //$fs .= $nl;
        }
        //print_r(($n));
        $page = utf8_decode($fs);
        //print_r(($page));
        foreach($datafile as $str)
        {
            //print_r($str);
        }
        //preg_match_all(#<h3 class="r"><a href="(.*?)".*?</a></h3>#, $file561, $num_all)
        //preg_match_all('#<h3>(.+?)</h3>#su', $datafile, $res);
        //var_dump($res);
}


?>