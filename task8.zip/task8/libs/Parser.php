<?PHP

class Parser
{
    protected $myUrl;
    protected $result;
    protected $ch;
    protected $uAg;
    public $myPage = array();
    function __constract()
    {
    }

    function setResult($s)
    {
        $this->result = $s;
    }
    function getResult()
    {
        return $this->result;
    }

    function getPageResultSerch($q)
    {
        $fp = fopen (dirname(__FILE__)."/google.txt", "w");
        $this->ch = curl_init($this->myUrl);
        $useragent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3717.0 Safari/537.36';
        $this->myUrl=('http://www.google.com.ua/search?hl=en&q='.$q."&num=1");
        //$this->myUrl=('https://worldoftanks.ru/ru/community/accounts/79274938-666__TAHKUCT__666/');

        $options = Array(
            CURLOPT_RETURNTRANSFER => TRUE,  
            CURLOPT_FOLLOWLOCATION => TRUE,  
            CURLOPT_AUTOREFERER => TRUE,
            CURLOPT_HEADER => 0,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 120,  
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_USERAGENT => $useragent,
            CURLOPT_URL => $this->myUrl, 
            CURLOPT_HTTPHEADER => array("Content-type: text/html; charset=utf-8"),
            //CURLOPT_HTTPHEADER => array("Content-Type: application/text"),
            CURLOPT_REFERER => "http://www.google.com.ua/",
            CURLOPT_HTTPHEADER => array('Content-Length: 0'),
            CURLOPT_FILE => $fp,
            );
        curl_setopt_array($this->ch, $options);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($this->ch, CURLOPT_COOKIEJAR, dirname(__FILE__).'/my_cookies.txt');
        
        $data = curl_exec ($this->ch);
        $this->setResult($data);
        curl_close($this->ch);
        fclose($fp);
    }

}



