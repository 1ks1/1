<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parser</title>
</head>
<body>
    <form action="" method="GET">
    <input type="text" name="search" placeholder="Google will look for"/><br />
    <input type="submit" value="GO" />
    </form>
    <hr />
    <p>curl version <?PHP print_r(curl_version()['version']); ?> </p>
    <?PHP $s=$cS->getResult(); print_r($s); //include('libs/google2.txt');?>
    <hr />
</body>
</html>