
    <form action="" method="GET">
    <input type="text" name="search" placeholder="Google will look for"/><br />
    <input type="submit" value="GO" />
    </form>
    <hr />
    <p>curl version <?PHP print_r(curl_version()['version']); ?> </p>
    <?PHP //$s=$cS->getResult(); print_r($s); //include('libs/google2.txt');?>
    <hr />
</body>
</html>