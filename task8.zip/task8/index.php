<?PHP
session_start();
include('libs/Parser.php');
$cS = new Parser;

if(isset($_GET['search']))
{
        $cS->getPageResultSerch($_GET['search']);
        if (file_exists('libs/google.txt'))
        $datafile = file('libs/google.txt');
        
        $str=implode($datafile);
        $prrg = '#(<h3.class=\"LC20lb\"(.+?)<\/h3>)#su';
        $prrg2 = '#(<span.class=\"st\"(.+?)<\/span>)#su';
        $prrg3 = '#((?<=(<cite class="iUh30".))(.+?)(?=(</cite>)))#su';
        preg_match_all($prrg, $str, $res,PREG_PATTERN_ORDER);
        preg_match_all($prrg2, $str, $res2,PREG_PATTERN_ORDER);
        preg_match_all($prrg3, $str, $res3, PREG_PATTERN_ORDER);
        $cS->myPage = '';

        if (count($res[0])>0)
        {
            $cS->myPage[] = $res[0][0];
        }
        if (count($res2[0])>0)
        {
            $cS->myPage[] =  "<p>";
            $cS->myPage[] = ($res2[0][0]);
            $cS->myPage[] =  "</p>";
        }
        
        if (count($res3[0])>0)
        {
            $cS->myPage[] =  '<a href="';
            $cS->myPage[] = ($res3[0][0]);
            $cS->myPage[] =  '" >';
            $cS->myPage[] = ($res3[0][0]);
            $cS->myPage[] =  '</a>';
            $cS->myPage[] = '<hr />';
        }
}        
        include('templates/index.php');

