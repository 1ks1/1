<?PHP
session_start();
include('libs/Parser.php');
$cS = new Parser;
$p = '';
if (isset($_GET['search']))
{
        $pg = $cS->getPageResultSerch(urlencode($_GET['search']));
        if (file_exists('libs/google.txt'))
        $datafile = file_get_contents('libs/google.txt');

        $str = $pg;
        $prrg = '#(<h3 class="LC20lb">(.+?)<\/h3>)#su';
        $prrg2 = '#(<span.class=\"st\"(.+?)<\/span>)#su';
        $prrg3 = '#((?<=(<cite class="iUh30".))(.+?)(?=(</cite>)))#su';
        preg_match_all($prrg, $str, $res,PREG_PATTERN_ORDER);
        preg_match_all($prrg2, $str, $res2,PREG_PATTERN_ORDER);
        preg_match_all($prrg3, $str, $res3, PREG_PATTERN_ORDER);
        $cS->myPage = '';
        

        for ($i=0; $i< count($res[0]); $i++)
        {   
            $p .=  "<hr />";
            $p .= $res[0][$i] . "<br />";
            if (isset($res2[0][$i]))
            $p .= $res2[0][$i] . "<br /><br />";
            if (isset($res3[0][$i]))
            $p .= "<a href=\"" . $res3[0][$i] . "\">" .
            $res3[0][$i] . "</a><br />";
        }

}        
        include('templates/index.php');

