<?PHP
session_start();
include('libs/Parser.php');
include('templates/index.php');
?>