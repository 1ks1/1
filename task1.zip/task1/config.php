<?PHP
    define("UPLFOLDER","files/");
?>