<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FILES</title>
</head>
<body>
<div class="global_wraps">
        <hr />
        <div>
                <table class="mytable table table-striped">
                 
<?PHP
echo $uplerr;
echo $derr;

///// FILES TABLE SHOW /////
if (count($a1)>0)
{
        echo $folder_perms_res;
        echo '<br />';
        echo (count($a1))." file(s) total";
        //generate table list
        for ($i=0; $i < count($a1); $i++)
        {
                $fne = $a1[$i]['name'];
                $fse = $a1[$i]['size'];
                echo '<form method="POST" action="" >';
                echo "<tr>";
                echo "<td> ".($i+1)." </td><td>".$a1[$i]['perms']."</td>";
                echo "<td><a href=\"{$fne}\" title=\"download\">$fne </a></td>";
                echo "<td>$fse</td>";
                //del button
                echo '<td><input type="submit" name = "delfile" value="DEL" />';
                echo '<input type="text" hidden name="fileNameD" value="'.$fne.'"></td>';
                echo "</tr>";
                echo '</form>';
        } 
//if files count is 0 ZERRO
}else{echo "[-]";}
?>     

                </table>
            </div>
</div>

</body>
</html>