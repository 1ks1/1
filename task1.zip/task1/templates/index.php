<?PHP
///// IF UPLOADING FILE /////
if(strlen($uplerr)>1)
print_r($uplerr);

///// IF DELETING /////
if(strlen($derr)>1)
print_r($derr);

///// FILES TABLE SHOW /////
        if (count($a1)>0)
        {
            echo folder_perms();
            echo '<br />';
            echo (count($a1))." file(s) total";
                    //generate table list
                    for ($i=0; $i < count($a1); $i++)
                    {
                            $fne = $a1[$i]['name'];
                            $fse = $a1[$i]['size'];
                            echo '<form method="POST" action="" >';
                            echo "<tr>";
                            echo "<td> ".($i+1)." </td><td>".$a1[$i]['perms']."</td>";
                            echo "<td><a href=\"{$fne}\" title=\"download\">$fne </a></td>";
                            echo "<td>$fse</td>";
                            //del button
                            echo '<td><input type="submit" name = "delfile" value="DEL" />';
                            //start button
                            echo '<input type="submit" name = "START" value="execute" />';
                            echo '<input type="text" hidden name="fileNameD" value="'.$fne.'"></td>';
                            echo "</tr>";
                            echo '</form>';
                    } 
        //if files count is 0 ZERRO
        }else{echo "[-]";}
        

?>     