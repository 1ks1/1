<?PHP
            echo '<form enctype="multipart/form-data" action="" method="POST" class="input-group-text form1">';
            echo '<input type="file" name="uploads">';
            echo '<input type="submit" value="upload">';
            echo '</form>';
?>