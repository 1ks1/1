<?PHP
include('config.php');
include('function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FILES</title>
</head>
<body>
<div class="global_wraps">
<?PHP 
$uf = upload_folder;
$dirpath = root_folder.$uf;
$derr = '';
$uplerr = '';
$a1 = (getFilesInfo($dirpath));
//if !upload_folder then create
if (!is_dir($dirpath)) 
{
     mkdir($dirpath, 0777, true);
}
if($_FILES)
{
    if(upload_myfile()>0)
    $uplerr = "<hr />".upl_err($res)."<hr />";
}
//del file
if(isset($_POST['delfile']))
{
    $file=upload_folder.$_POST['fileNameD'];
    $err = del_file($file);
        if ($err == 0)
        {
            $url=$_SERVER['PHP_SELF'];
            header("Location: $url");
        }else{
            $derr = "Error! $err";
        }
}

//executing files for win//prnt if some error
if(isset($_POST['START']))
{   
  winexec($_POST['fileNameD']);
}

include('templates/upl_form.php');
?>
            <hr />
            <div>
                <table class="mytable table table-striped">
                    <?PHP
                        include('templates/index.php');
                    ?>
                </table>
            </div>
</div>

</body>
</html>