<?PHP
include('config.php');
include ('function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FILES</title>
</head>
<body>
<div class="global_wraps">
<?PHP
include('templates/upl_form.php');
?>
            <hr />
            <div>
                <table class="mytable table table-striped">
                    <?PHP
                        include('templates/index.php');
                    ?>
                </table>
            </div>
</div>
</body>
</html>