<?PHP
include('config.php');

if (!is_dir(UPLFOLDER)) 
{
     mkdir(UPLFOLDER, 0777, true);
}

include('function.php');
$derr = '';
$uplerr = '';
$a1 = (getFilesInfo(UPLFOLDER));


//if !upload_folder then create
if ($_FILES)
{
    if (upload_myfile()>0)
    $uplerr = "<hr />".upl_err($res)."<hr />";
    $url=$_SERVER['PHP_SELF'];
    header("Location: $url");
}


//del file
if (isset($_POST['delfile']))
{

    $file=UPLFOLDER.$_POST['fileNameD'];
    $err = del_file($file);

        if (0 == $err)
        {
            $url=$_SERVER['PHP_SELF'];
            header("Location: $url");
        }else{
            $derr = "Error! $err";
        }
}


include('templates/upl_form.php');
include('templates/index.php');

            