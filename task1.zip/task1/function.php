<?php
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);


  //upluad error codes
function upl_err($i)
{
    switch ($i){
    case 1:
        return "#$i The uploaded file exceeds the upload_max_filesize directive in php.ini";
        break;
    case 2:
        return "#$i The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form";
        break;
    case 3:
        return "#$i The uploaded file was only partially uploaded";
        break;
    case 4:
        return "#$i No file was uploaded";
        break;
    case 5:
        return "#$i -----";
        break;
    case 6:
        return "#$i Missing a temporary folder. Introduced in PHP 5.0.3";
        break;
    case 7:
        return "#$i Failed to write file to disk. Introduced in PHP 5.1.0";
        break;
    case 8:
        return "#$i A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help";
        break;
    }
}

function upload_myfile()
{ 
    //moving file to upl folder
    $ff = root_folder.upload_folder.$_FILES['uploads']['name'];
    $moved = move_uploaded_file($_FILES["uploads"]["tmp_name"], $ff);
        if( $moved ) {
                chmod($ff ,0777);
                $result = 0;        
        } else {
            //get error number for
            $result = $_FILES["uploads"]["error"];
        }
    return $result;
}

function file_perm_info ($filename)
{
    //convert fileperms from 10 to 8 and get last 4
    $info = substr(decoct(fileperms($filename)), -4);
    return $info;
}

function folder_perms()
{
    //check folder perms for 766 
    $rwx = substr(sprintf('%o', fileperms(upload_folder)), -4);
    if($rwx[1]>6)
    if($rwx[2]>5)
    if($rwx[3]>5)
    return ("$rwx for [".basename(upload_folder)."]");
    return "Warning! Folder".basename(upload_folder)." has $rwx perms";
}

function del_file($file)
{
    //get full path $file
    $filePath = realpath(root_folder.upload_folder.$file);
    //if exists
    $path = basename($file);
    $path = root_folder.upload_folder.$path;
    if(file_exists($path)){
        //if file writable
        if (is_writable($path)){
            $res = unlink($path);
            $res=0;
        }else{$res="File not writable";}
    }else{$res="File not exists";}
        return $res;
}

//human size view
function ReadableSize($size)
{
    $base = log($size) / log(1024);
    $suffix = array("", "KB", "MB", "GB", "TB");
    $f_base = floor($base);
    return round(pow(1024, $base - floor($base)), 1) . $suffix[$f_base];
}

//just form my self
function start_exe($file)
{
    $filePath = root_folder.upload_folder."$file";
        if(file_exists($filePath)){
            exec($filePath);
            $res=true;
        }else{$res="Bad path.";}
    return $res;
}

//all files from $dirpath
function scan_my_dir($dirpath)
{
    $cdir = scandir($dirpath);
    return $cdir; 
}

function winexec($file)
{
    $e=start_exe($file);
    if($e)
    {
        $url=$_SERVER['PHP_SELF'];
        header("Location: $url");
    return "";
    }else{
    return "<br />Some error exec!: $e<br />";
    }
}
function getFilesInfo($dir)
{
    $info = array();
    $files = scan_my_dir($dir);
    foreach ($files as $file)
    {
        if ($file != ".." && $file != ".")
        {
            $f = $dir.$file;
            $info[] = array('name'=>$file,'size'=>ReadableSize(filesize($f)),'perms'=>file_perm_info($f));
        }
    }
    return $info;

}

?>