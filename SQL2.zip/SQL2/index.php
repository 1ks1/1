<?PHP
include('config.php');
include('libs/Sql.php');
include('libs/Psql.php');
$MySql = new Sql;
$Psql = new Psql;
$jt = '';
$jtp = '';
$rowsNow = " rows now is ".$MySql->countTableRows()." <br />";
$rowsNowP = $Psql->countTableRows();

    if (isset($_POST['START']))
    {
        $MySql->if_table_create();
        $MySql->generateInsers();
        $jt = "Job time is : ".$MySql->timeW;
    }



    if (isset($_POST['addpk']))
    {
        $MySql->if_table_create();
        $MySql->addPK();
        $jt = "Job time is : ".$MySql->timeW;
    }


    if (isset($_POST['delpk']))
    {
        $MySql->if_table_create();
        $MySql->delPK();
        $jt = "Job time is : ".$MySql->timeW;
    }

//////////PG


    if (isset($_POST['pSTART']))
    {
        $Psql->if_table_create();
        $Psql->generateInsers();
        $jtp = "Job time is : ".$Psql->timeW;
    }



    if (isset($_POST['paddpk']))
    {
        $Psql->if_table_create();
        $Psql->addPK();
        $jtp = "Job time is : ".$Psql->timeW;
    }


    if (isset($_POST['pdelpk']))
    {
        $Psql->if_table_create();
        $Psql->delPK();
        $jtp = "Job time is : ".$Psql->timeW;
    }

include('templates/index.php');

