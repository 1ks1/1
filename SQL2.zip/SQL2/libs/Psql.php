<?PHP 

class Psql
{   public $timeW;
    private $link;
    function dbConn()
        {   $this->link = pg_connect("host=".PHOST." port=5432 dbname=".PDATABASE." user=".PUSER." password=".PPASS);
            pg_query("set names 'utf8'");
            return $this->link;
        }

    function if_table_create()
    {
        $q = 'CREATE TABLE IF NOT EXISTS ' . PTABLE . ' (id serial,
        name text,
        descr text)';
        $link = $this->dbConn();
        $res = pg_query($link,$q);
        pg_close($link);
        return $res;
    }

    function addPK()
    {  
        $q = 'ALTER TABLE ' . PTABLE . ' ADD PRIMARY KEY (id)';
        $link = $this->dbConn();
        $res = pg_query($q,$link);
        pg_close($link);
        return $res;
    }

    function delPK()
    {  
        $q = 'ALTER TABLE '.PTABLE.' DROP PRIMARY KEY';
        $link = $this->dbConn();
        $res = pg_query($q,$link);
        pg_close($link);
        return $res;
    }

    function generatePass()
    {  
        $string = base64_encode(md5(uniqid(rand(), true)) . md5(uniqid(rand(), true)) .
        md5(uniqid(rand(), true)));
        $string;
        return $string;
    }
    function generateInsers()
    {

        ignore_user_abort(true);
        set_time_limit(600);
        $start = microtime(true);           //time period from
        $n = $this->countTableRows();       //get rows count
        $l = $this->dbConn(PDATABASE);
        for ($i=($n+1); $i<=3; $i++)
        {
            $s = $this->generatePass();
            $s = substr(($s.$s), 0, -1);     //generate flood
            //$s = "asdd";
            $q = '';
            $q .= "INSERT INTO ".PTABLE." (id, name, descr) VALUES (";
            $q .= ($i+$n);
            $q .= ", '$s' , '$s' ) ";
            $res = pg_query($q);
            echo "$i,  ";
        }
        pg_close($l);
        $this->timeW = microtime(true) - $start;    //fix job time
        return $this->timeW;

    }
    function countTableRows()
    {
        $conn = $this->dbConn();
        $rows = pg_query($conn, "SELECT count(*) FROM ".PTABLE);
        $r = pg_fetch_assoc($rows);
        pg_close($conn);
        //$res =
        $r = $r['count'];
        return $r; 
    }
}