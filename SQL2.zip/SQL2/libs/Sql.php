<?PHP 

class Sql
{   public $timeW;
    function dbConn($db)
        {
            $link = mysql_connect(HOST, USER, PASS);
            mysql_select_db($db, mysql_connect(HOST, USER, PASS));
            mysql_query("set names 'utf8'");
            return $link;
        }

    function if_table_create()
    {
        $q = 'CREATE TABLE IF NOT EXISTS ' . TABLE . ' (id integer(11),
        name text(255),
        descr text(255))';

        $link = $this->dbConn(DATABASE);
        $res = mysql_query($q,$link);
        mysql_close($link);
        return $res;
    }

    function addPK()
    {  
        $q = 'ALTER TABLE '.TABLE.' ADD PRIMARY KEY (id)';
        $link = $this->dbConn(DATABASE);
        $res = mysql_query($q,$link);
        mysql_close($link);
        return $res;
    }

    function delPK()
    {  
        $q = 'ALTER TABLE '.TABLE.' DROP PRIMARY KEY';
        $link = $this->dbConn(DATABASE);
        $res = mysql_query($q,$link);
        mysql_close($link);
        return $res;
    }

    function generatePass()
    {  
        $string = base64_encode(md5(uniqid(rand(), true)) . md5(uniqid(rand(), true)) .
        md5(uniqid(rand(), true)));
        $string;
        return $string;
    }
    function generateInsers()
    {
        ignore_user_abort(true);
        set_time_limit(600);
        echo "max_execution_time".ini_get('max_execution_time')."<br />";
        $start = microtime(true);           //time period from
        $n = $this->countTableRows();       //get rows count
        $l = $this->dbConn(DATABASE);
        for ($i=($n+1); $i<=900000; $i++)
        {
            $s = $this->generatePass();
            $s = substr(($s.$s), 0, -1);     //generate flood
            //$s = "asdd";
            $q = '';
            $q .= "INSERT INTO ".TABLE." (id, name, descr) VALUES (";
            $q .= ($i+$n);
            $q .= ", '$s' , '$s' ) ";
            $res = mysql_query($q);
            echo "$i,  ";
        }
        mysql_close($l);
        $this->timeW = microtime(true) - $start;    //fix job time
        return $this->timeW;

    }
    function countTableRows()
    {
        $q = "SELECT count(*) FROM ".TABLE;
        $lnk = $this->dbConn(DATABASE);
        $res = mysql_query($q,$lnk);
        $arr = mysql_fetch_assoc($res);
        $result = $arr['count(*)'];
        mysql_close($lnk);
        //$res =
        return $result; 
    }
}