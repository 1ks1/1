<?PHP
define("HOST","127.0.0.1");
define("DATABASE","user11");
define("USER","root");
define("PASS","usbw");
define("TABLE","sqltest");

//-------------------------------
define("PHOST","127.0.0.1");
define("PDATABASE","user11");
define("PUSER","root");
define("PPASS","toor");
define("PTABLE","test.sqltest");
