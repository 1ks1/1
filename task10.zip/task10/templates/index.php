<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Task10</title>
</head>
<body>
    <br />
    <pre>
    Task10: 
    Расширить свой Sql класс, что бы он смог работать c Distinct, <i>Join, Group, Having,</i> Order, Limit
    Join::
    join(): добавляет к запросу INNER JOIN.
    leftJoin(): добавляет к запросу LEFT OUTER JOIN.
    rightJoin(): добавляет к запросу RIGHT OUTER JOIN.
    crossJoin(): добавляет к запросу CROSS JOIN.
    naturalJoin(): добавляет к запросу NATURAL JOIN.
Практика - сделать класс для MySQL/PostgreSQL на PDO c применением “Текучего Интерфейса”
(должно быть использование prepare, execute, bindParam для безопасного выполнения SQL)
</pre>
<a href="https://ru.wikipedia.org/wiki/Fluent_interface">wiki</a> 
<a href=""></a>
<hr />
query:  <?PHP echo $query; ?>;
<br />
<form action="" method="POST">
<input type="text" name="table" value='test'>Table<br />
<input type="text" name="what" placeholder="col1, col2">cols<br />
<input type="text" name="where" placeholder="Where">where<br />
<input type="text" name="values" placeholder="Value1, Value2">values<br />
<input type="nub" name="limit" placeholder="10">Limit<br /><br />
<select name="type">
<option value="select">Select</option>
<option value="insert">Insert</option>
<option value="delete">Delete</option>
<option value="update">Update</option><br />
</select>
order by <input type="text" name="orderfield" placeholder="column">
<select name="order">
<option value="none">none</option>
<option value="desc">Desc</option>
<option value="asc">Asc</option>
</select>
<br />
<input type="checkbox" name="distinct" value="distinct">Distinct<br />
<br /><input type="submit"><br />
</form>
<?PHP
echo "-------------<br />";
echo $result;
echo "-------------<br />";
?>
</body>
</html>