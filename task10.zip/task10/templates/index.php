<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Task10</title>
    <style>
    section{box-shadow:2px 3px 4px #ccc;background:#eee;width:800px;}
    </style>
</head>
<body>
    <br />
    <pre>
    Task10: 
    Расширить свой Sql класс, что бы он смог работать c Distinct, Join, Group, <i>Having,</i> Order, Limit
    Join::
    join(): добавляет к запросу INNER JOIN.
    leftJoin(): добавляет к запросу LEFT OUTER JOIN.
    rightJoin(): добавляет к запросу RIGHT OUTER JOIN.
    crossJoin(): добавляет к запросу CROSS JOIN.
    naturalJoin(): добавляет к запросу NATURAL JOIN.
Практика - сделать класс для MySQL/PostgreSQL на PDO c применением “Текучего Интерфейса”
(должно быть использование prepare, execute, bindParam для безопасного выполнения SQL)
</pre>
<a href="https://ru.wikipedia.org/wiki/Fluent_interface">wiki</a> 
<a href=""></a>
<hr />
<section>
query:  <?PHP echo $query; ?>;
<br />
<form action="" method="POST">
<input type="text" name="table" value='test'>Table<br />
<input type="text" name="what" placeholder="col1, col2">cols<br />
<input type="text" name="where" placeholder="Where">where<br />
<input type="text" name="values" placeholder="Value1, Value2">values<br />
<input type="nub" name="limit" placeholder="10">Limit<br /><br />
</section>
<br />
<section>
For SQL query select type of query as 'SQL'<br />
<input type="sql" name="sql" placeholder="sql">SQL<br /><br />
Type:
<select name="type">
<option value="select">Select</option>
<option value="insert">Insert</option>
<option value="delete">Delete</option>
<option value="update">Update</option>
<option value="sql">SQL</option><br />
</select>
order by:<input type="text" name="orderfield" placeholder="column">
<select name="order">
<option value="none">none</option>
<option value="desc">Desc</option>
<option value="asc">Asc</option>
</select>
<br />
<input type="checkbox" name="distinct" value="distinct">Distinct<br /><br />
</section>
<br />
<section>
Join:
<select name="join">
<option value="none">none</option>
<option value="INNER JOIN">INNER</option>
<option value="LEFT JOIN">LEFT</option>
<option value="RIGHT JOIN">DRIGHT</option>
<option value="CROSS JOIN">CROSS</option>
<option value="NATURAL JOIN">NATURAL</option>
</select>
Table name:<input type="text" name="joinTable" placeholder="Table name"><br />
Table alias:<input type="text" name="joinAlias" placeholder="Table Alias"><br />
ON:<input type="text" name="joinOn" placeholder="join condition"><br /><br />
GROUP BY :<input type="text" name="group" placeholder="table.col"><br />
HAVING :<input type="text" name="having" placeholder="AVG(id) > 2"><br /><br />
</section>




<br /><input type="submit"><br />
<br />

</form>
<?PHP
echo "-------------<br />";
echo $result;
echo "-------------<br />";
?>
</body>
</html>