<?PHP
 class Sql
 {
    protected $where;
    protected $what;
    protected $values;
    protected $joinType;
    protected $joinTable;
    protected $joinAlias;
    protected $joinOn;
    protected $group;
    protected $having;
    protected $limit;
    protected $query;
    protected $pdo;
    protected $order;
    protected $SQL;
    protected $distinct;
    protected $table;

  

    function getQuery()
    {
        return $this->query;
    }

   function setQuery($q)
   {
        $q = htmlspecialchars(trim($q));
        $this->query = $q;
   }

   function setSql($q)
   {
        $q = htmlspecialchars(trim($q));
        if (strlen($q)>14)
        $this->SQL = $q;
   }

   function setWhat($w)
   {    
        $w = trim($w);
        $this->what = '';
        if (strlen($w) > 0)
        $this->what = $w;
        return $this;
   }
   function setValues($v)
   {    
        $v = trim($v);
        $this->values = '';
        if (strlen($v) > 0)
        $this->values = $v;
   }
   function setTable($t)
   {    
        $t = trim($t);
        $this->table = '';
        if (strlen($t) > 0)
        $this->table = $t;
        return $this;
   }
   function setWhere($w)
   {    
        $w = trim($w);
        $this->where = '';
        if (strlen($w) > 0)
        $this->where = $w;
        return $this;
   }
   function setHaving($h)
   {
        $h = trim($h);
        $this->having = '';
        if (strlen($h) > 0)
        $this->having = $h;
   }

   function setLimit($l)
   {
        $l = trim($l);
        $this->limit = '';
        if (strlen($l) > 0)
        $this->limit = $l;
   }

   function setGroup($group)
   {
        $group = trim($group);
        if (strlen($group)>0)
        $this->group = $group;
   }

   function setDistinct($d)
   {
        $this->distinct = $d;
   }

   function setOrder($order,$ordField)
   {
        $ordField = trim($ordField);
        if (strlen($ordField)>0)
        {
            $this->order[0] = $order;
            $this->order[1] = $ordField;
        }
        
   }
   
   function setJoin($join,$joinTable,$joinAlias,$joinOn)
   {
        $this->joinType = $join;
        $this->joinTable = trim($joinTable);
        $this->joinAlias = trim($joinAlias);
        $this->joinOn = trim($joinOn);
   }



   
    //SELECT /////////
    public function select()
    {
        $dist = '';
        if ($this->distinct)
        $dist = "DISTINCT ";

        $ord = '';
        if (strlen($this->order[1]) > 0)
        $ord = "ORDER BY " . $this->order[1] . " " . $this->order[0];

        $heRes = '';
        if (strlen($this->having)>0)
        $heRes = "HAVING " . $this->having;


        //add join here
        $jres = '';
        if ((strlen($this->joinTable) > 0) && 
        (strlen($this->joinOn) > 1) && 
        ($this->joinType != 'none'))
        {
            $jres = " $this->joinType $this->joinTable ";
            if (strlen($this->joinAlias)>0)
            $jres .= $this->joinAlias." ON " . $this->joinOn;
        }

        //what
        $wht='';
        if (strlen($this->what)>0)
        $wht = $this->what;
        
        //where
        $whr='';
        if (strlen($this->where)>1)
        $whr = "WHERE " . $this->where;

        //limit
        $lm = '';
        if (strlen($this->limit)>0)
        $lm = "LIMIT " . $this->limit;

       //group
        $gr = '';
        if (isset($this->group))
        $gr = "GROUP BY " . $this->group;


        
        //construct//
        if (strlen($wht)>0 && strlen($this->table)>0)
        {
            $this->query = "SELECT $dist $wht 
            FROM $this->table $jres $whr $lm $ord $gr $heRes";
        }

        //if handly SQL string
        if (strlen($this->SQL)>14)
        $this->query = $this->SQL;
    
        //print_r(" --select_debug--:  ". $this->query." ---- ");
    }

    public function insert($values)
    {
        $this->query = "INSERT INTO $this->table ($this->what) VALUES ($this->values)";
    }


    public function update()
        {
                $gg = "UPDATE $this->table SET ";
                if(is_array($this->what))
                foreach($this->what as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= "$k=$v ,";
                    }else{  $gg .= "$k='$v' ,";}
                }
                
                $gg = rtrim($gg, ',');
                $gg .= "WHERE $this->where";
                $this->query = $gg;  
                
        }

        public function delete()
        {
            if (strlen($where)>1)
            {
                $w = ' WHERE '.$this->where;
                $gg = "DELETE FROM $this->table $w ";
                $this->query = $gg;
            }
        }

 }
 





 class My_sql extends Sql
 {
    function connect()
     {
         try{
            $dsn = "mysql:host=" . HOST . ";dbname=" . DB . ";charset=" . CHARSET;
            $opt= [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES  => false
            ];
            $this->pdo = new PDO($dsn, USER, PASSWORD, $opt);
        }
        catch(PDOException $e) 
        {  
            return $e->getMessage();  
        }

     }

        //================MAIN POINT START====================//
        function sel($type)
        {
            switch ($type) {
                case 'select':
                    $this->select();
                    break;
                case 'insert':
                    $this->insert($this->values);
                    break;
                case 'update':
                $this->insert($this->values);
                    break;
                case 'delete':
                    $this->delete();
                    break;
                case 'sql':
                    $this->setQuery($q);
                    break;
                }

                
            $this->connect();
            $res = array();
            if (! $this->pdo == false)
            {
                try
                {
                    $stmt = $this->pdo->query($this->query);
                    $row = $stmt->fetchAll();
                    foreach($row as $r)
                    {
                        $res[] = $r;
                    }
                }
                catch(PDOException $e) 
                {  
                    $errorpdo = $e->getMessage();  
                }   
                    if (isset($errorpdo))
                    $res = array('Oops! Pdoerr:',$errorpdo);
                    
            }else{$res = 'Dude! Pdoconnect error';}
            return $res;
        }

     


 }