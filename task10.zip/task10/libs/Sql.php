<?PHP
 class Sql
 {
    protected $distinct;
    protected $databaseType;
    protected $group;
    protected $having;
    protected $limit;
    protected $joinType;
    protected $joinTable;
    protected $joinAlias;
    protected $joinOn;
    protected $order;
    protected $pdo;
    protected $query;
    protected $SQL;
    protected $SQLmode;
    protected $table;
    protected $type;
    protected $values;
    protected $where;
    protected $what;
  

    //resered function
    function getQuery()
    {
        return $this->query;
    }
    //resered function
   function setQuery($queryString)
   {
        $q = '';
        $q = htmlspecialchars(trim($queryString));
        $this->query = $q;
        return $this;
   }
   //for manual mode query
   function setSqlString($SQL)
   {
        $q = $SQL;
        $q = htmlspecialchars(trim($q));
        if (strlen($q)>14)
        $this->SQL = $q;
        return $this;
   }
   //manual mode switch
   function setManualMode($mode)
   {
       if ($mode == true || $mode == false)
       $this->SQLmode = $mode;
        return $this;
   }



   function setTable($t)
   {    
        $t = htmlspecialchars(trim($t));
        if (strlen($t) > 0)
        $this->table = $t;
        return $this;
   }

   function setWhat($w)
   {    
        $this->what = '';
        if (is_array($w))
        {
            $this->what = $w;
        }else{
            $w = htmlspecialchars(trim($w));
            if (strlen($w) > 0)
            $this->what = $w;
        }
        
        return $this;
   }

   function setWhere($w)
   {    
        $w = htmlspecialchars(trim($w));
        $this->where = '';
        if (strlen($w) > 0)
        $this->where = $w;
        return $this;
   }


   function setValues($v)
   {    
        if (is_array($v))
        {
            $this->values = $v;
        }else
        {
        $v = htmlspecialchars(trim($v));
        $this->values = '';
        if (strlen($v) > 0)
        $this->values = $v;
        }
        return $this;
   }

   function setHaving($h)
   {
        $h = trim($h);
        $this->having = '';
        if (strlen($h) > 0)
        $this->having = $h;
        return $this;
   }

   function setLimit($l)
   {
        $l = htmlspecialchars(trim($l));
        $this->limit = '';
        if (strlen($l) > 0)
        $this->limit = $l;
        return $this;
   }

   function setGroup($group)
   {
        $group = htmlspecialchars(trim($group));
        if (strlen($group)>0)
        $this->group = $group;
        return $this;
   }

   function setDistinct($d)
   {
       if ($d == true || $d == false)
        $this->distinct = $d;
        return $this;
   }

   function setOrder($order)
   {
        $ordField = htmlspecialchars(trim($order[1]));
        if (strlen($order[1]) > 0)
        {
            $this->order = $order;
        }
        return $this;
   }
   
   function setJoin($join,$joinTable,$joinAlias,$joinOn)
   {
        $this->joinType = $join;
        $this->joinTable = htmlspecialchars(trim($joinTable));
        $this->joinAlias = htmlspecialchars(trim($joinAlias));
        $this->joinOn = htmlspecialchars(trim($joinOn));
        return $this;
   }

   function setDatabaseType($type)
   {
       if ('mysql' == $type || 1 == $type )
       $this->databaseType = 1;
       if ('pgsql' == $type || 2 == $type )
       $this->databaseType = 2;
   }

//==========prepares====================///
   

   function prepSelect()
   {
        $res = '';
        $d = '';
        if ($this->distinct)
        $d = "DISTINCT";
        
        
        if (is_array($this->what))
        {   
            $c = count ($this->what);
            $w = '';
            foreach ($this->what as $key => $val)
            {
                if (! $c == $key)
                {
                    $w .= $val . ", ";
                }else {$w .= $val;}
            }
        }else{
            if (strlen($this->what) > 0)
            $w = $this->what;
        }
        

        if (strlen($this->table) > 0)
        $t = $this->table;

        if (isset($w) && isset($this->table))
        $res = "SELECT $d $w FROM $this->table";

        return $res;
         
   }

   function prepWhere()
   {
        $whr='';
        if (strlen($this->where) > 1)
        $whr = "WHERE " . $this->where;
        return $whr;
   }

   function prepOrd()
   {
        $ord = '';
        if (strlen($this->order[1]) > 0)
        $ord = "ORDER BY " . $this->order[1] . " " . $this->order[0];
        return $ord;
   }
    
   function prepJoin()
   {

        $jres = '';
        if ((strlen($this->joinTable) > 0) && 
        (strlen($this->joinOn) > 1) && 
        ($this->joinType != 'none'))
        {
            $jres = " $this->joinType $this->joinTable ";
            if (strlen($this->joinAlias)>0)
            $jres .= $this->joinAlias." ON " . $this->joinOn;
        }
        return $jres;
   }

   function prepHaving()
   {
        $h = '';
        if (strlen($this->having) > 0)
        $heRes = "HAVING " . $this->having;
        return $h;
   }

   function prepLimit()
   {
        $lm = '';
        if (strlen($this->limit) > 0)
        $lm = "LIMIT " . $this->limit;
        return $lm;
   }

    function prepGroup()
    {
        $gr = '';
        if (isset($this->group))
        $gr = "GROUP BY " . $this->group;
        return $gr;
    }

    public function select()
    {
        
        $h = $this->prepHaving();
        $o = $this->prepOrd();
        $j =  $this->prepJoin();
        $slct = $this->prepSelect();
        $w = $this->prepWhere();
        $lm = $this->prepLimit();
        $gr = $this->prepGroup();
        
        $this->query = "$slct $j $w $lm $o $gr $h";
        if (strlen($this->SQL)>14)
        $this->query = $this->SQL;
    
    }

    public function insert()
    {
        $values = '';
        if (is_array($this->values))
        {
            $c = count($this->values);
            foreach ($this->values as $key => $vl)
            {
                if (! $c == $key)
                {
                    $values .= $vl . ", ";
                }else{$values .= $vl;}
                
            }

        }else{
            $values = $this->values;
        }

        $w = '';
        $v = '';
        if (isset($this->what))
        $w = "($this->what)";
        $v = "($values)";
        $this->query = "INSERT INTO $this->table $w VALUES $v";
        //print_r($this->query); //debug
    }


    public function update()
        {
                $gg = "UPDATE $this->table SET ";
                if(is_array($this->what))
                foreach($this->what as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= "$k=$v ,";
                    }else{  $gg .= "$k='$v' ,";}
                }
                
                $gg = rtrim($gg, ',');
                $gg .= "WHERE $this->where";
                $this->query = $gg;  
                
        }

        public function delete()
        {
            if (strlen($where)>1)
            {
                $w = ' WHERE '.$this->where;
                $gg = "DELETE FROM $this->table $w ";
                $this->query = $gg;
            }
        }

 }
 





 class My_sql extends Sql
 {
    function connect()
     {
        $dbtype = DBTYPE;
        if (isset($this->databaseType))
        $dbtype = $this->databaseType;

        if (1 == $dbtype)//mysql
        {
            $dsn = "mysql:host=" . HOST . 
            ";dbname=" . DB . ";charset=" . CHARSET;
            $user = USER;
            $password = PASSWORD;

        }

        if (2 == $dbtype)//pgsql
        {
                $dsn = "pgsql:host=" . PHOST . 
                ";dbname=" . PDB;
                $user = PUSER;
                $password = PPASSWORD;
        }

        $opt= [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES  => false
        ];
        //print_r($dsn);
        try{
            $this->pdo = new PDO($dsn, $user, $password, $opt);
        }
        catch(PDOException $e) 
        {  
            return $e->getMessage();  
        }
        
     }



        //================MAIN POINT START====================//
        function sel($type)
        {
            $this->type = $type;
            switch ($type) {
                case 'select':
                    $this->select();
                    break;
                case 'insert':
                    $this->insert($this->values);
                    break;
                case 'update':
                $this->update($this->values);
                    break;
                case 'delete':
                    $this->delete();
                    break;
                case 'sql':
                    $this->SQLmode = true;
                    $this->select();
                    break;
                }

                //print_r($this->query . "<--query connect input--<");   
            $this->connect();
            $res = array();
            if (! $this->pdo == false)
            {
                
                
                try
                {
                    $stmt = $this->pdo->prepare($this->query);
                    //$stmt -> bindParam(':from', 'test');
                    $stmt->execute();
                    ///debug////
                    // $stmt = $this->pdo->query($this->query);
                    // echo '<hr />';
                    // print_r($stmt->rowCount());
                    // echo '<hr />';
                    // print_r(get_class_methods ($stmt));
                    ///debug////
                    $row = $stmt->fetchAll();
                    foreach($row as $r)
                    {
                        $res[] = $r;
                    }
                }
                catch(PDOException $e) 
                {  
                    $errorpdo = $e->getMessage();  
                }   
                    if (isset($errorpdo))
                    $res = array('Oops! Pdoerr:',$errorpdo);
                    
            }else{$res = 'Dude! Pdoconnect error';}
            return $res;
        }

     


 }