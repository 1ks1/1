<?PHP
 class Sql
 {
    protected $query;
    protected $pdo;

    function getQuery()
    {
        return $this->query;
    }

    public function select($distinkt,$what,$table,$where,$limit=10,$order,$orderfield)
    {
        $ord='';
        if (strlen($limit) > 1){$limit = ' LIMIT '.$limit;}
        if (strlen($where) > 1){$where = ' WHERE '.$where;}
        if ('distinct' == $distinkt){$distinkt = " DISTINCT ";}
        if (( 'none' != $order) && (strlen($orderfield) > 0) )
        {
            $ord = " ORDER BY " . $orderfield . " $order";
        }else{$order = '';}

        $this->query = "SELECT $distinkt $what FROM $table $where $limit $ord";
    }

    public function insert($table,$what,$values)
    {
        $this->query = "INSERT INTO $table ($what) VALUES ($values)";
    }

    public function update()
        {
                $gg = "UPDATE $this->table SET ";
                if(is_array($this->what))
                foreach($this->what as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= "$k=$v ,";
                    }else{  $gg .= "$k='$v' ,";}
                }
                
                $gg = rtrim($gg, ',');
                $gg .= "WHERE $this->where";
                $this->query = $gg;  
                
        }


        public function delete($table,$where)
        {
            if (strlen($where)>1)
            {
                $where = ' WHERE '.$where;
                $gg = "DELETE FROM $table $where ";
                if (is_array($this->arr))
                foreach($this->arr as $k=>$v)
                {
                    if(is_numeric($v))
                    {
                            $gg .= $k.'='.$v.',';
                    }else{   $gg .= $k.'=\''.$v.'\',';}
                }
                $gg = rtrim($gg, ',');
                $this->query = $gg;
            }
        }

 }
 
 class My_sql extends Sql
 {
    function connect()
     {
         try{
            $dsn = "mysql:host=" . HOST . ";dbname=" . DB . ";charset=" . CHARSET;
            $opt= [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES  => false
            ];
            $this->pdo = new PDO($dsn, USER, PASSWORD, $opt);
        }
        catch(PDOException $e) 
        {  
            return $e->getMessage();  
        }

     }

        function sel($distinct='',$type,$what,$table,$where,$limit,$values,$order='none',$orderfield)
        {
            
            switch ($type) {
                case 'select':
                    $this->select($distinct,$what,$table,$where,$limit,$order,$orderfield);
                    break;
                case 'insert':
                    $this->insert($table,$what,$values);
                    break;
                case 'update':
                $this->insert($table,$what,$values);
                    break;
                case 'delete':
                    $this->delete($table,$where);
                    break;
                }
                //print_r(' try '.$this->query. ' <br />'); //debug
            $this->connect();
            $res = array();
            if (! $this->pdo == false)
            {
                try
                {
                    $stmt = $this->pdo->query($this->query);
                    $row = $stmt->fetchAll();
                    foreach($row as $r)
                    {
                        $res[] = $r;
                    }
                }
                catch(PDOException $e) 
                {  
                    $errorpdo = $e->getMessage();  
                }   
                    if (isset($errorpdo))
                    $res = array('Oops! Pdoerr:',$errorpdo);
                    
            }else{$res = 'pdoconnect error';}
            return $res;
        }

     


 }