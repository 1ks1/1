<?PHP

 class Connector  ###### PARENT CLASS #######
 {
    protected $pdo;

    function __construct()
    {
        $this->pdo = DB::connect();
    }


    function queryAsk($q)
    {
        $stmt = $this->pdo->prepare($q);
        $res = array();
            if (is_object($this->pdo))
            {
                try
                {
                    $stmt->execute();
                    $row = $stmt->fetchAll();
                    foreach($row as $r)
                    {
                        $res[] = $r;
                    }
                
                }
                catch(PDOException $e) 
                {  
                    $errorpdo = $e->getMessage();
                    //fix database error messages coz encoding is mixed in my sql server probably
                    $var = mb_convert_encoding($errorpdo, "utf-8", "windows-1251");
                    if (preg_match("/([а-я]+)/ui", $var))
                    $errorpdo = $var;
                }   
                

                if (isset($errorpdo))
                $res = array('PDOException: ',$errorpdo); 

            }else{

                if (isset($this->pdo))
                {
                    $res = $this->pdo;
                }else{$res = 'Error(connect)! Have no PDO obj';}

            }
        return $res;
    }

 }