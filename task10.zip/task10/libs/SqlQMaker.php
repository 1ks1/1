<?PHP
 class SqlQMaker extends Connector
 {
    protected $distinct;
    protected $databaseType;
    protected $group;
    protected $having;
    protected $limit;
    protected $joinType;
    protected $joinTable;
    protected $joinAlias;
    protected $joinOn;
    protected $order;
    protected $query;
    protected $SQL;
    protected $SQLmode;
    protected $table;
    protected $type;
    protected $values;
    protected $where;
    protected $what;




    //reserved function
    function getQuery()
    {
        return $this->query;
    }
    //reserved function
   function setQuery($queryString)
   {
        $this->query = $this->validator($queryString);
        return $this;
   }
   //for manual mode query
   function setSqlString($SQL)
   {
        $q = $this->validator($SQL);
        if ( strlen($q) > 14 )
        $this->SQL = $q;
        return $this;
   }
   //manual mode switch
   function setManualMode($mode)
   {
       if ( is_bool($mode) )
       $this->SQLmode = $mode;
        return $this;
   }

   function setTable($t)
   {    
        $t = $this->validator($t);
        if (strlen($t) > 0)
        $this->table = $t;
        return $this; #str
   }

   function setWhat($w)
   {    
    
        $this->what = '';
        if (is_array($w))
        {
            $this->what = $w;
        }else{
            $this->what = explode(', ',$this->validator($w)); #arr
            
        }
        
        return $this; 
   }

   function setWhere($w) #string
   {    
        if (is_string($w) && 1 < strlen(trim($w)))
        $this->where = $this->validator($w);
        return $this; 
   }

   function setValues($v)
   {    
        if (is_array($v))
        {
            $this->values = $v;
        }else
        {
        $v = $this->validator($v);
        if (strlen($v) > 0)
        $this->values = explode(',',$v); #arr
        }
        return $this;
   }

   function setHaving($h)
   {
        $h = trim($h);
        $this->having = '';
        if (strlen($h) > 0)
        $this->having = $h;
        return $this;
   }

   function setLimit($l)
   {
        $l = $this->validator($l);
        $this->limit = '';
        if (strlen($l) > 0)
        $this->limit = $l;
        return $this;
   }

   function setGroup($group)
   {
        $group = $this->validator($group);
        if (strlen($group)>0)
        $this->group = $group;
        return $this;
   }

   function setDistinct($d)
   {
       if ($d == true || $d == false)
        $this->distinct = $d;
        return $this;
   }

   function setOrder($order)
   {
        $ordField =$this->validator($order[1]);
        if (strlen($order[1]) > 0)
        {
            $this->order = $order;
        }
        return $this;
   }
   
   function setJoin($join,$joinTable,$joinAlias,$joinOn)
   {
        $this->joinType = $this->validator($join);
        $this->joinTable = $this->validator($joinTable);
        $this->joinAlias = $this->validator($joinAlias);
        $this->joinOn = $this->validator($joinOn);
        return $this;
   }

   function setDatabaseType($type)
   {
       if ('mysql' == $type || 1 == $type )
       $this->databaseType = 1;
       if ('pgsql' == $type || 2 == $type )
       $this->databaseType = 2;
       return $this;
   }

//==========prepares====================///
   

   function prepSelect()
   {
        $res = '';
        $d = '';
        
        if ($this->distinct)
        $d = "DISTINCT";
   
        if (is_array($this->what))
        {   
            $wt = implode(',',$this->what);
            $wt = $this->validator($wt);
        }else{
            if (strlen(trim($this->what)) >= 1)
            $wt = $this->validator($this->what);
        }
        if (strlen($this->table) > 0)
        $t = $this->table;

        if (isset($wt) && isset($this->table) && strlen($this->table) > 1 && strlen($wt) > 1 )
        $res = "SELECT $d $wt FROM $this->table";
        return $res;
         
   }

   function prepOrd()
   {
        $ord = '';
        if (strlen($this->order[1]) > 0)
        $ord = "ORDER BY " . $this->order[1] . " " . $this->order[0];
        return $ord;
   }
    
   function prepJoin()
   {

        $jres = '';
        if ((strlen($this->joinTable) > 0) && 
        (strlen($this->joinOn) > 1) && 
        ($this->joinType != 'none'))
        {
            $jres = " $this->joinType $this->joinTable ";
            if (strlen($this->joinAlias)>0)
            $jres .= $this->joinAlias." ON " . $this->joinOn;
        }
        return $jres;
   }

   function prepHaving()
   {
        $h = '';
        if (strlen($this->having) > 0)
        $heRes = "HAVING " . $this->having;
        return $h;
   }

   function prepLimit()
   {
        $lm = '';
        if (strlen($this->limit) > 0)
        $lm = "LIMIT " . $this->limit;
        return $lm;
   }

    function prepGroup()
    {
        $gr = '';
        if (isset($this->group))
        $gr = "GROUP BY " . $this->group;
        return $gr;
    }

    function prepWhere()
   {
        $whr='';
        if (strlen($this->where) > 1)
        $whr = "WHERE " . $this->where;
        return $whr;
   }


    function validator($strVal)
    {
        $a = htmlspecialchars(trim($strVal));
        if ($a == '*')
        return '';
        return $a;
    }

    //make SELECT ////////////////

    public function select()
    {
        $h = $this->prepHaving();
        $o = $this->prepOrd();
        $j =  $this->prepJoin();
        $slct = $this->prepSelect();
        $w = $this->prepWhere();
        $lm = $this->prepLimit();
        $gr = $this->prepGroup();
        $query = "$slct $j $w $lm $o $gr $h";  
        $this->query = $this->validator($query);
        

        //if manual mode true and str len
        if (( $this->SQLmode )&&( strlen($this->SQL) > 14))
        {
            $this->query = $this->validator($this->SQL);
            return $this->queryAsk($this->SQL);
        }

        if (1 < strlen($this->query))
        {
            return $this->queryAsk($this->query);
        } 

    }

    public function insert()
    {
        if (is_array($this->values))
        {
            $arr = [];
            foreach($this->values as $v)
            {
                $arr [] = $this->validator($v);
            }
            $values = implode(',',$arr);
        }else{
            $values = $this->values;
        }

        $values = $this->validator($values);
        if ( (count($this->what) == count($this->values)) && isset($this->table) )
        {
            //create array values placeholders (?)
            $valStr = [];
            foreach($this->values as $val)
            {   
                $valStr[] = '?';
            }
            $q = "INSERT INTO $this->table (" . implode(',',$this->what) . ") VALUES (" . implode(',',$valStr) . ")";
            $stmt = $this->pdo->prepare($q);
            $stmt->execute($this->values);
        }else{return 'Error! Count of parameters and values or table set';}
     
    }


    public function update()
        {
            
            if(count($this->what) == count($this->values))
            {
                $newArray = array_combine($this->what, $this->values);

                //create array values placeholders (?)
                $Array1 = [];
                foreach($newArray as $key=>$val)
                $Array1[] = "$key=?";
                $q = "UPDATE $this->table SET " . implode(',',$Array1);
                $q .= " WHERE " . $this->validator($this->where);
                $stmt = $this->pdo->prepare($q);
                $stmt->execute($this->values);
            }else{return 'Error! Field what and field values not valid';}
                
        }

        public function delete()
        {
            $this->where = $this->validator($this->where);
            if (strlen($this->where)>1)
            {
                $w = ' WHERE '.$this->where;
                $gg = "DELETE FROM $this->table $w";
                $this->query = $gg;
                $this->queryAsk($gg);
            }
        }


        function sel($type)
        {
            $this->type = $type;       
            switch ($type) {
                case 'select':
                    return $this->select(); 
                    break;
                case 'insert':
                    $this->insert($this->values);
                    break;
                case 'update':
                $this->update($this->values);
                    break;
                case 'delete':
                    $this->delete();
                    break;
                case 'sql':
                    $this->SQLmode = true; 
                    $this->select();
                    break;
                case 'Default':
                    return 'Error(sel)! Incorrect operation CRUD';
                }
        }

        function test()
        {
            return 'Class SqlQMaker test OK ';
        }

 }
 

