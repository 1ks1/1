<?PHP
define ('DB','user11');
define ('HOST','127.0.0.1:3307');
define ('USER','root');
define ('PASSWORD','usbw');
define ('CHARSET','utf8');
//define ('USER','user11');
//define ('PASSWORD','user11');
?>