<?PHP
include('colletor.php');

$sqlObj = new SqlQMaker;

//test select//////////////
$whatArr = [];
$whatArr[] = 'id';
$whatArr[] = 'name';
$sqlObj->setWhat($whatArr);


////manual-mode test func////////////////////
//$SQL = 'SELECT id,name FROM test';
//$resTest = $sqlObj->setManualMode(true)->queryAsk($SQL);
//$a=[];
//foreach($resTest as $v){$a[]= implode('|',$v) ;}
//echo( implode('|',$resTest) );
//////////////////////////////////////



//$sqlObj->prepSelect();   

    $res = '';
    $query = '';
    $result = '';
    if ($_POST)
    {   
        //print_r($_POST); ///POSTS/////DEBUG///////
        //echo '<br /><br />';///POSTS/////DEBUG///////

        $type = $_POST['type'];         #operation
        $values = $_POST['values'];     

        //select op//
        if ($_POST['type'] == 'select')
        {
            $sqlObj->setWhat($_POST['what'])->setTable($_POST['table']);
        }
        //delete  op//
        if ($_POST['type'] == 'delete')
        {
            $sqlObj->setWhat($_POST['where'])->setTable($_POST['table']);
        }
        //insert  op//
        if ($_POST['type'] == 'insert')
        {
            $sqlObj->setWhat($_POST['what'])->setValues($_POST['values'])->setTable($_POST['table']);
        }
        //manual mode
        if (($_POST['type'] = 'sql')&&(strlen($_POST['sql']) > 14))
        $sqlObj->setSqlString($_POST['sql'])->setManualMode(true);
        ///ch mysql/pgsql set
        if (isset($_POST['databaseType']))
            $sqlObj->setDatabaseType($_POST['databaseType']);

        if (isset($_POST['distinct']))
            $sqlObj->setDistinct(true);

        if (isset($_POST['table']))
            $sqlObj->setTable($_POST['table']);

        if (isset($_POST['having']))
            $sqlObj->setHaving(trim($_POST['having'])); 

        if (isset($_POST['group']))
            $sqlObj->setGroup(trim($_POST['group']));

        if (isset($_POST['limit']))
            $sqlObj->setLimit(trim($_POST['limit']));

        if (isset($_POST['where']))
            $sqlObj->setWhere($_POST['where']);

        if (isset($_POST['values']))
            $sqlObj->setValues(trim($_POST['values']));
            
        if (strlen($_POST['orderfield']) > 0)
        {
            $order[0] = $_POST['order'];
            $order[1] = $_POST['orderfield'];
            $sqlObj->setOrder($order);
        }

        

        
        if ($_POST['join'] != 'none' && 
        strlen(trim($_POST['joinTable']))>0 && 
        strlen(trim($_POST['joinOn']))>1)
        {
            $join = $_POST['join'];
            $joinTable = $_POST['joinTable'];
            $joinAlias = $_POST['joinAlias'];
            $joinOn = $_POST['joinOn'];
            $sqlObj->setJoin($join,$joinTable,$joinAlias,$joinOn);
        }else{
            $join = $_POST['join'];
        }


        //SEND SQL ASK
        //$type is operation (select,insert,delete,update,sql)
        // 'sql' param - for sql string (manual mode)
        $res = $sqlObj->sel($type);  ##START
        if (is_array($res))
        {
            $res = $res;
        }else{
            $res = array('res'=>$res);
        }
        $query = $sqlObj->getQuery();//DEBUG// query string set
    }

    if (isset($res) && is_array($res))
    
    foreach($res as $r)
    {
    if (is_array($r)){$r=implode(" | ",$r);}
    $result .=$r . "<br />";
    }



include('templates/index.php');

