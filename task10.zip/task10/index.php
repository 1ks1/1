<?PHP
include('config.php');
include('libs/Sql.php');
$sqlObj = new My_sql;

    $res = '';
    $query = '';
    $result = '';
    if ($_POST)
    {   
        print_r($_POST); //debug
        $type = $_POST['type'];
        $limit = $_POST['limit'];
        $table = $_POST['table'];
        $what = $_POST['what'];
        $where = $_POST['where'];
        $values = $_POST['values'];
        $order = '';
        $distinct = '';
        $orderfield = '';
        $sql = '';
        $distinkt = '';
        $join = '';
        $joinTable = '';
        $joinAlias = '';
        $group = '';
        $having = '';
        if (isset($_POST['distinct']))
            $distinct = $_POST['distinct'];

        if (isset($_POST['having']))
            $sqlObj->setHaving(trim($_POST['having'])); 

        if (isset($_POST['group']))
            $sqlObj->setGroup(trim($_POST['group']));
        
      

        if (($_POST['order'] != 'none')&&(strlen($_POST['orderfield']) > 0))
        {
            $order = $_POST['order'];
            $orderfield = $_POST['orderfield'];
        }

        if (strlen($_POST['sql']) > 0)
            $sql = $_POST['sql'];
        
        if ($_POST['join'] != 'none' && 
        strlen(trim($_POST['joinTable']))>0 && 
        strlen(trim($_POST['joinOn']))>1)
        {
            $join = $_POST['join'];
            $joinTable = $_POST['joinTable'];
            $joinAlias = $_POST['joinAlias'];
            $joinOn = $_POST['joinOn'];
            $sqlObj->setJoin($join,$joinTable,$joinAlias,$joinOn);
        }else{
            $join = $_POST['join'];
        }


        //ask db
        $res = $sqlObj->sel($sql,$distinct,$type,
        $what,$table,$where,$limit,
        $values,$order,$orderfield);
        if (is_array($res))
        {
            $res = $res;
        }else{
            $res = array('res'=>$res);
        }
        
        $query = $sqlObj->getQuery();//devug
    }

    if (isset($res) && is_array($res))
    foreach($res as $r)
    {
    if (is_array($r)){$r=implode(" | ",$r);}
    $result .=$r . "<br />";
    }

include('templates/index.php');

