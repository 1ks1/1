<?PHP
include('config.php');
include('libs/Sql.php');
$sqlObj = new My_sql;


//send arr for test select
// $whatArr = array();
// $whatArr[] = 'id';
// $whatArr[] = 'name';
// $sqlObj->setWhat($whatArr);
// $sqlObj->prepSelect();   
/////////////////////////

//send arr for test select
// $values = array();
// $values[] = "id='15'";
// $values[] = "name='Test'";
// $sqlObj->setValues($values);
// $sqlObj->setTable('SomeTableName');
// $sqlObj->insert();
/////////////////////////

    $res = '';
    $query = '';
    $result = '';
    if ($_POST)
    {   
        //print_r($_POST); //////////////////////////POSTS////DEBUG///////
        $type = $_POST['type'];
        $values = $_POST['values'];

        //select//
        if ($_POST['type'] == 'select')
        {
            $sqlObj->setWhat($_POST['what'])->setTable($_POST['table']);
        }
        //delete//
        if ($_POST['type'] == 'delete')
        {
            $sqlObj->setWhat($_POST['where'])->setTable($_POST['table']);
        }

        //insert//
        if ($_POST['type'] == 'insert')
        {
            $sqlObj->setWhat($_POST['where'])->setValues($_POST['values'])->setTable($_POST['table']);
        }

        //manual mode
        if (($_POST['type'] = 'sql')&&(strlen($_POST['sql']) > 14))
        $sqlObj->setSqlString($_POST['sql'])->setManualMode(true);



        if (isset($_POST['distinct']))
            $sqlObj->setDistinct(true);

        if (isset($_POST['table']))
            $sqlObj->setTable($_POST['table']);

        if (isset($_POST['having']))
            $sqlObj->setHaving(trim($_POST['having'])); 

        if (isset($_POST['group']))
            $sqlObj->setGroup(trim($_POST['group']));

        if (isset($_POST['limit']))
            $sqlObj->setLimit(trim($_POST['limit']));

        if (isset($_POST['where']))
            $sqlObj->setWhere(trim($_POST['where']));

        if (isset($_POST['values']))
            $sqlObj->setValues(trim($_POST['values']));
            
        if (strlen($_POST['orderfield']) > 0)
        {
            $order[0] = $_POST['order'];
            $order[1] = $_POST['orderfield'];
            $sqlObj->setOrder($order);
        }

        

        
        if ($_POST['join'] != 'none' && 
        strlen(trim($_POST['joinTable']))>0 && 
        strlen(trim($_POST['joinOn']))>1)
        {
            $join = $_POST['join'];
            $joinTable = $_POST['joinTable'];
            $joinAlias = $_POST['joinAlias'];
            $joinOn = $_POST['joinOn'];
            $sqlObj->setJoin($join,$joinTable,$joinAlias,$joinOn);
        }else{
            $join = $_POST['join'];
        }


        //SEND TO MAIN POINT SQL ASK
        $res = $sqlObj->sel($type);

        if (is_array($res))
        {
            $res = $res;
        }else{
            $res = array('res'=>$res);
        }
        $query = $sqlObj->getQuery();//devug
    }

    if (isset($res) && is_array($res))
    
    foreach($res as $r)
    {
    if (is_array($r)){$r=implode(" | ",$r);}
    $result .=$r . "<br />";
    }

include('templates/index.php');

