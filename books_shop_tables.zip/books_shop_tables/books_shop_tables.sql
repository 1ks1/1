CREATE TABLE `books` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	`price` INT(11) NOT NULL,
	`cd` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `autors` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `genres` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `users` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	`email` varchar(250) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

CREATE TABLE `cart` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`user_id` INT(11) NOT NULL,
	`book_id` INT(11) NOT NULL,
	`count` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `orders` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`orderstatus_id` INT(11) NOT NULL,
	`iser_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `orderstatus` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`actual` INT(11) NOT NULL,
	`color` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `cd_dvd` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`url` varchar(250) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `books_back` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(250) NOT NULL,
	`price` varchar(250) NOT NULL,
	`cd` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `book_autor` (
	`id_book` INT(11) NOT NULL,
	`id_autor` INT(11) NOT NULL
);

CREATE TABLE `book_genre` (
	`id_book` INT(11) NOT NULL,
	`id_genre` INT(11) NOT NULL
);

ALTER TABLE `books` ADD CONSTRAINT `books_fk0` FOREIGN KEY (`cd`) REFERENCES `cd_dvd`(`id`);

ALTER TABLE `cart` ADD CONSTRAINT `cart_fk0` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`);

ALTER TABLE `cart` ADD CONSTRAINT `cart_fk1` FOREIGN KEY (`book_id`) REFERENCES `books`(`id`);

ALTER TABLE `orders` ADD CONSTRAINT `orders_fk0` FOREIGN KEY (`orderstatus_id`) REFERENCES `orderstatus`(`id`);

ALTER TABLE `orders` ADD CONSTRAINT `orders_fk1` FOREIGN KEY (`iser_id`) REFERENCES `users`(`id`);

ALTER TABLE `book_autor` ADD CONSTRAINT `book_autor_fk0` FOREIGN KEY (`id_book`) REFERENCES `books`(`id`);

ALTER TABLE `book_autor` ADD CONSTRAINT `book_autor_fk1` FOREIGN KEY (`id_autor`) REFERENCES `autors`(`id`);

ALTER TABLE `book_genre` ADD CONSTRAINT `book_genre_fk0` FOREIGN KEY (`id_book`) REFERENCES `books`(`id`);

ALTER TABLE `book_genre` ADD CONSTRAINT `book_genre_fk1` FOREIGN KEY (`id_genre`) REFERENCES `genres`(`id`);

