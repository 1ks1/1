import { Injectable } from '@angular/core';

@Injectable()
export class ShareService {
  test = 'TEST';
  list = [
    'First',
    'Second'
  ];
  list2 = JSON.parse(localStorage.list2 || '[]');

  constructor() { }

  add(val) {
    this.list.push(val);
  }


  List2Save(newVal) {
    localStorage.list2 = JSON.stringify(newVal);
    }

  

}
