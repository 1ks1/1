import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = 'SHOP Component!';
  allprice = 0;
  item_list = [
    {price:100,name:'Kingston 16',count:1},
    {price:210,name:'Kingston 32',count:1},
    {price:60,name:'Sandisk 16',count:1},
    {price:220,name:'Transend 32',count:1},
    
  ];

cart_list=JSON.parse(localStorage.cart || '[]');

  add(index) {
    
    if (this.cart_list.length == 0){
      this.cart_list.push({
        name: this.item_list[index].name,
        count: 1,
        price: this.item_list[index].price
      });
    }else{
      //console.log('=========');

      var finn = false;
      for (var i = 0; i < this.cart_list.length; i++){

        if (this.item_list[index].name == this.cart_list[i].name){
          this.cart_list[i].count++;
          finn = true;
        }
      }
        if (finn == false){
          this.cart_list.push({
            name: this.item_list[index].name,
            count: 1,
            price: this.item_list[index].price
          });
        }
      
    }
    this.cart(this.cart_list);
  }

  summ(){
 
    var a=0;
    var allpr=0;
    for (var i = 0; i < this.cart_list.length; i++){
      a += this.cart_list[i].count;
      allpr += (this.cart_list[i].count * this.cart_list[i].price);
      console.log(this.cart_list[i]);
    }
    
    this.allprice = allpr;
    return a;
  }

  remove(index) {
    this.cart_list.splice(index, 1);
    this.summ();
    this.cart(this.cart_list);
  }

  cart(newVal) {
    localStorage.cart = JSON.stringify(newVal);
    }
  
}
