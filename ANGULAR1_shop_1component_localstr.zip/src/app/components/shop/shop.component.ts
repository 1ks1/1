import { Component, OnInit } from '@angular/core';
import { ShareService } from '../../services/share.service';


@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css'],
  providers: [
    //ShareService
  ]
})
export class ShopComponent implements OnInit {

  constructor(private ss: ShareService) {}

  ngOnInit() {
  }

  title = 'SHOP Component!';
  baks = (26.18);
  rub = 0.40;
  allprice = 0;
  item_list = [
    {price:100,name:'Kingston 16',count:1},
    {price:210,name:'Kingston 32',count:1},
    {price:60,name:'Sandisk 16',count:1},
    {price:220,name:'Transend 32',count:1},
    
  ];

cart_list=JSON.parse(localStorage.cart || '[]');

  add(index) {
    
    if (this.cart_list.length == 0){
      this.cart_list.push({
        name: this.item_list[index].name,
        count: 1,
        price: this.item_list[index].price
      });
    }else{
      //console.log('=========');

      var finn = false;
      for (var i = 0; i < this.cart_list.length; i++){

        if (this.item_list[index].name == this.cart_list[i].name){
          this.cart_list[i].count++;
          finn = true;
        }
      }
        if (finn == false){
          this.cart_list.push({
            name: this.item_list[index].name,
            count: 1,
            price: this.item_list[index].price
          });
        }
      
    }
    this.cart(this.cart_list);
  }

  baksow(){
    return Math.round(this.allprice/this.baks);
  }

  rubley(){
    return Math.round(this.allprice/this.rub);
  }

  summ(){
 
    var a=0;
    var allpr=0;
    for (var i = 0; i < this.cart_list.length; i++){
      a += this.cart_list[i].count;
      allpr += (this.cart_list[i].count * this.cart_list[i].price);
      console.log(this.cart_list[i]);
    }
    
    this.allprice = allpr;
    return a;
  }

  remove(index) {
    this.cart_list.splice(index, 1);
    this.summ();
    this.cart(this.cart_list);
  }

  cart(newVal) {
    localStorage.cart = JSON.stringify(newVal);
    }

    clearlist2(){
      localStorage.list2 = JSON.parse('[]');
      this.ss.list2 = [];
    }

    mergelists(){
      var tempList = [];
      var fnd = false;
      tempList = this.item_list;
      //tempList.push(this.item_list[i]);
      fnd = false;
      for (var i = 0; i < this.ss.list2.length; i++){
        fnd = false;
          for (var j = 0; j < this.item_list.length; j++){
              if (this.ss.list2[i].name == this.item_list[j].name){
                fnd = true;
              }
          }
          if (fnd == false){
            tempList.push(this.ss.list2[i]);
          }

      }
      this.item_list = tempList;
      this.ss.list2 = [];
    }

  //for LIST2 in services

    addprod(name,price) {

      if (this.ss.list2.length == 0){
        this.ss.list2.push({
          name: name,
          count: 1,
          price: price
        });
  
      }else{
  
            var finn = false;
              for (var i = 0; i < this.ss.list2.length; i++){
                    if (name == this.ss.list2[i].name){
                      this.ss.list2[i].count++;
                      finn = true;
                    }
              }
              
              if (finn == false){
                  this.ss.list2.push({
                    name: name,
                    count: 1,
                    price: price
                  });
              }
           
      }
      this.ss.List2Save(this.ss.list2);  
      //this.mergelists();   
    }
}
