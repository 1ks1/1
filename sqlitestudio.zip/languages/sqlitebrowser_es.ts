<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="64"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;SQLite Database Browser&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Version 2.2-a&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;SQLite Database Browser is an open source, public domain, freeware tool used to create, design and edit SQLite database files.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;For more information on this program please visit our site at: &lt;/span&gt;&lt;a href=&quot;https://sqlitedbrowser.sf.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://sqlitedbrowser.sf.net&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;  or email us at &amp;lt;&lt;/span&gt;&lt;a href=&quot;mailto:sqlitebrowser@blueprint-group.co.ke&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;sqlitebrowser@blueprint-group.co.ke&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;&amp;gt;&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddColumnDialog</name>
    <message>
        <location filename="../src/addcolumndialog.ui" line="14"/>
        <source>Field Editor</source>
        <translation>Editor de campos</translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="22"/>
        <source>Field Name:</source>
        <translation>Nombre del campo:</translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="32"/>
        <source>Data Type:</source>
        <translation>Tipo de dato:</translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="49"/>
        <source>Text</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="54"/>
        <source>Integer Primary Key</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="59"/>
        <source>Integer Primary Key Autoincrement</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="64"/>
        <source>Integer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="69"/>
        <source>Real</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="74"/>
        <source>Blob</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="79"/>
        <source>Null</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="87"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="107"/>
        <source>Not Null</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="121"/>
        <source>Default</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.ui" line="131"/>
        <source>Comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.cpp" line="20"/>
        <source>Data Type</source>
        <translation>Tipo de dato</translation>
    </message>
    <message>
        <location filename="../src/addcolumndialog.cpp" line="20"/>
        <source>Enter the data type</source>
        <translation>Seleccione el tipo de dato</translation>
    </message>
</context>
<context>
    <name>AdvancedSearchDialog</name>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="14"/>
        <source>Advanced Search</source>
        <translation>Busqueda avanzada</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="22"/>
        <source>Column Name:</source>
        <translation>Nombre columna:</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="32"/>
        <source>Criteria:</source>
        <translation>criterio:</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="40"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="45"/>
        <source>Contains</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="50"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="55"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="60"/>
        <source>&gt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="65"/>
        <source>&lt;=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="73"/>
        <source>Search Text:</source>
        <translation>Buscar Texto:</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="83"/>
        <source>Add To Search</source>
        <translation>Agregar a Busqueda</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="93"/>
        <source>Column Name</source>
        <translation>Nombre de la columna</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="98"/>
        <source>Criteria</source>
        <translation>Criterio</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="103"/>
        <source>Search Text</source>
        <translation>Buscar Texto</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.ui" line="113"/>
        <source>Remove Selected</source>
        <translation>Quitar Seleccion</translation>
    </message>
    <message>
        <location filename="../src/advancedsearchdialog.cpp" line="13"/>
        <source>Search Error</source>
        <translation>Error al Buscar</translation>
    </message>
</context>
<context>
    <name>CreateIndexDialog</name>
    <message>
        <location filename="../src/createindexdialog.ui" line="14"/>
        <source>Create a new Index</source>
        <translation>Crear Nuevo Indice</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="27"/>
        <source>Index Name:</source>
        <translation>Nombre del Indice:</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="34"/>
        <source>Define Properties</source>
        <translation>Define Propiedades</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="42"/>
        <source>Field to Index:</source>
        <translation>Campo a indexar:</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="52"/>
        <source>Indexing Order:</source>
        <translation>Ordenacion del Indice:</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="66"/>
        <source>Ascending</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="71"/>
        <source>Descending</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="79"/>
        <source>Duplicate Values:</source>
        <translation>valores Duplicados:</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="87"/>
        <source>Allowed</source>
        <translation>Permitir</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.ui" line="92"/>
        <source>Not Allowed</source>
        <translation>No permitir</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.cpp" line="21"/>
        <location filename="../src/createindexdialog.cpp" line="53"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.cpp" line="32"/>
        <source>Warning</source>
        <translation>Atencion</translation>
    </message>
    <message>
        <location filename="../src/createindexdialog.cpp" line="32"/>
        <source>Please enter the index name.</source>
        <translation>Por favor, introduzca nombre del indice.</translation>
    </message>
</context>
<context>
    <name>CreateTableDialog</name>
    <message>
        <location filename="../src/createtabledialog.ui" line="14"/>
        <source>Create Table</source>
        <translation>Crear Tabla</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="26"/>
        <source>Table Name:</source>
        <translation>Nombre de la Tabla:</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="51"/>
        <source>Fields</source>
        <translation>campos</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="59"/>
        <source>New Column</source>
        <translation>Nueva Columna</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="64"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="69"/>
        <source>Not Null</source>
        <translation>No Nulo</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="74"/>
        <source>Default</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="84"/>
        <source>Add Field</source>
        <translation>Agregar Campo</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.ui" line="91"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.cpp" line="91"/>
        <location filename="../src/createtabledialog.cpp" line="97"/>
        <location filename="../src/createtabledialog.cpp" line="103"/>
        <location filename="../src/createtabledialog.cpp" line="127"/>
        <location filename="../src/createtabledialog.cpp" line="133"/>
        <location filename="../src/createtabledialog.cpp" line="139"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/createtabledialog.cpp" line="91"/>
        <location filename="../src/createtabledialog.cpp" line="97"/>
        <location filename="../src/createtabledialog.cpp" line="103"/>
        <location filename="../src/createtabledialog.cpp" line="127"/>
        <location filename="../src/createtabledialog.cpp" line="133"/>
        <location filename="../src/createtabledialog.cpp" line="139"/>
        <source>Table Error:
%1</source>
        <translation>Error en la Tabla:
%1</translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <location filename="../src/database.cpp" line="20"/>
        <source>SQL Error</source>
        <translation>Error en SQL</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="28"/>
        <location filename="../src/database.cpp" line="280"/>
        <source>Error executing: %1.</source>
        <translation>Error al ejecutar: %1.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="46"/>
        <source>Cannot get databases list. %1</source>
        <translation>Imposible obtener la lista de bases de datos. %1</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="61"/>
        <source>Error while dropping table %1: %2.</source>
        <translation>Error al Eliminar la tabla %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="74"/>
        <location filename="../src/database.cpp" line="104"/>
        <source>Error while getting the fileds of %1: %2.</source>
        <translation>Error al obtener los campos %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="129"/>
        <source>Error while the list of %1: %2.</source>
        <translation>Error al listar %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="151"/>
        <location filename="../src/database.cpp" line="168"/>
        <source>Error while the list of the system catalogue: %2.</source>
        <translation>Error en la lista del catalogo del sistema: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="180"/>
        <source>Error while dropping the view %1: %2.</source>
        <translation>Error al eliminar la Vista %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="193"/>
        <source>Error while dropping the index %1: %2.</source>
        <translation>Error al eliminar el indice %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="205"/>
        <source>Unable to open file %1 for writing.</source>
        <translation>Imposible abrir el fichero %1 para escribir.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="217"/>
        <source>Error while exporting SQL: %1.</source>
        <translation>Error al exportar SQL: %1.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="236"/>
        <source>Error while describe object %1: %2.</source>
        <translation>Errormientras describo el objeto %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="253"/>
        <source>Error while dropping the trigger %1: %2.</source>
        <translation>Error al eliminar el disparador-trigger %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/database.cpp" line="286"/>
        <source>Not Set</source>
        <translation>Not Set</translation>
    </message>
</context>
<context>
    <name>ImportCSVDialog</name>
    <message>
        <location filename="../src/importcsvdialog.ui" line="14"/>
        <source>Import CSV</source>
        <translation>Importar CSV</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="20"/>
        <source>File Name: </source>
        <translation>Nombre de Fichero:</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="29"/>
        <source>Table Name:</source>
        <translation>Nombre de Tabla:</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="43"/>
        <source>Field Separator:</source>
        <translation>Separador de Campos</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="56"/>
        <source>,</source>
        <translation>,</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="63"/>
        <source>Field Enclosed By:</source>
        <translation>Campo Encerrado entre:</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="76"/>
        <source>&quot;</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.ui" line="98"/>
        <source>Use first row as column header</source>
        <translation>Usar primera fila como cabecera de columna</translation>
    </message>
    <message>
        <location filename="../src/importcsvdialog.cpp" line="12"/>
        <source>File Name: %1</source>
        <translation>Nombre de Fichero: %1</translation>
    </message>
</context>
<context>
    <name>LogDialog</name>
    <message>
        <location filename="../src/logdialog.ui" line="14"/>
        <source>SQLite Browser Log</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/logdialog.ui" line="22"/>
        <source>Show SQL Submitted By:</source>
        <translation>Mostrar SQL enviada por:</translation>
    </message>
    <message>
        <location filename="../src/logdialog.ui" line="29"/>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="../src/logdialog.ui" line="39"/>
        <source>Application</source>
        <translation>aplicacion</translation>
    </message>
    <message>
        <location filename="../src/logdialog.ui" line="59"/>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="29"/>
        <source>Database Browser</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>Object</source>
        <translation>Objeto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="51"/>
        <source>Schema</source>
        <translation>esquema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="60"/>
        <source>Browse Data</source>
        <translation>Buscar Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Select Table:</source>
        <translation>Seleccione la tabla:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="111"/>
        <source>Refresh</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="118"/>
        <source>New Record</source>
        <translation>Nuevo Registro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <source>Delete Record</source>
        <translation>Eliminar Registro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <source>Save Changes</source>
        <translation>guardar Cambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="147"/>
        <source>Search:</source>
        <translation>buscar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Advanced Search</source>
        <translation>Busqueda Avanzada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Execute SQL</source>
        <translation>Ejecutar SQL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="217"/>
        <source>Query:</source>
        <translation>Consulta:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="247"/>
        <source>Execute Query</source>
        <translation>ejecutar Consulta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="269"/>
        <source>Error message from database engine:</source>
        <translation>Mensaje de error desde el motor de la Base de Datos:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="311"/>
        <source>File</source>
        <translation>Fichero</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="315"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="355"/>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="361"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <location filename="../src/mainwindow.cpp" line="99"/>
        <source>New Database</source>
        <translation>Nueva Base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Creates a new SQLite Database file</source>
        <translation>Crear un nuevo fichero de Base de Datos SQLite</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="415"/>
        <source>Open Database</source>
        <translation>Abrir Database</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Opens an existing SQLite Database file</source>
        <translation>Abrir una Base de Datos existente SQLite</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <source>Close Database</source>
        <translation>Cerrar Base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="426"/>
        <source>Closes the current Database</source>
        <translation>Cerrar Base de Datos actual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="435"/>
        <source>Save Database</source>
        <translation>guardar Base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="438"/>
        <source>Saves changes made to the Database</source>
        <translation>Cambios guardados en la Base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="447"/>
        <source>Revert Database</source>
        <translation>Revertir base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Compact Database</source>
        <translation>Compactar Base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="457"/>
        <source>Database From SQL File</source>
        <translation>base de Datos a partir de fichero SQL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Table From CSV File</source>
        <translation>Tabla a partir de fichero CSV</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="467"/>
        <source>Databse As SQL File</source>
        <translation>Fichero SQL como Base de Datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="472"/>
        <source>Table as CSV File</source>
        <translation>Tabla como fichero CSV</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="477"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="486"/>
        <source>Create Table</source>
        <translation>Crear Tabla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="495"/>
        <source>Delete Table</source>
        <translation>Eliminar la tabla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>Modify Table</source>
        <translation>Modificar la tabla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="513"/>
        <source>Create Index</source>
        <translation>Crear un indice</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="522"/>
        <source>Delete Index</source>
        <translation>Eliminar Indice</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="527"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>SQL Log</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="544"/>
        <source>About</source>
        <translation>Acerca de ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="555"/>
        <source>English</source>
        <translation>Ingles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="89"/>
        <source>Open File</source>
        <translation>abrir Fichero</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="107"/>
        <source>About %1</source>
        <translation>Acerca de ... %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="119"/>
        <location filename="../src/mainwindow.cpp" line="126"/>
        <location filename="../src/mainwindow.cpp" line="333"/>
        <location filename="../src/mainwindow.cpp" line="369"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="119"/>
        <source>Database Error.
%1</source>
        <translation>Error en la Base de Datos %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="126"/>
        <source>Database Error.
%1 is probably not an sqlite database</source>
        <translation>Error. %1 no es, probablemente, una base de datos SQLite</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="131"/>
        <source>Opened file: %1</source>
        <translation>Fichero abierto: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="143"/>
        <source>SQLite Browser - %1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>SQLite Browser</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="235"/>
        <source>%1 %2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="271"/>
        <source>There is a pending transaction in progress. That cannot be commited now.
Error: %1
Perform rollback?</source>
        <translation>Esta en proceso una transaccion. No se puede confirmar ahora.
Error: %1
Ejecutar Rollback?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="326"/>
        <location filename="../src/mainwindow.cpp" line="361"/>
        <source>Confirm Drop</source>
        <translation>Confirme Eliminacion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="326"/>
        <source>Are you sure you want to delete this table?
CAUTION!!!You will lose all data.</source>
        <translation>Esta seguro de eliminar esta tabla?
ATENCION! Perdera todos los datos.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="333"/>
        <location filename="../src/mainwindow.cpp" line="369"/>
        <source>Drop Table Error:
%1</source>
        <translation>Error al Eliminar Tabla: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="339"/>
        <source>Select a table</source>
        <translation>Seleccione una tabla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <source>Select an Index</source>
        <translation>Seleccione un un indice</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="361"/>
        <source>Are you sure you want to delete this index?
CAUTION!!!This action cannot be undone.</source>
        <translation>esta seguro de eliminar el indice?
ATENCION! Esta acción no podra ser anulada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="425"/>
        <source>Could not create export file.
%1</source>
        <translation>Imposible crear fichero de exportacion
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="440"/>
        <source>Export completed</source>
        <translation>Exportacion completa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="454"/>
        <location filename="../src/mainwindow.cpp" line="471"/>
        <location filename="../src/mainwindow.cpp" line="472"/>
        <source>SQL Import</source>
        <translation>Importar SQL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="455"/>
        <source>Cannot read file %1:
%2.</source>
        <translation>Imposible leer el fichero %1: %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="471"/>
        <location filename="../src/mainwindow.cpp" line="619"/>
        <source>Error:
%1</source>
        <translation>Error: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="472"/>
        <source>SQL File imported successfully</source>
        <translation>Fichero SQL importado con exito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="509"/>
        <location filename="../src/mainwindow.cpp" line="511"/>
        <source>CSV Export</source>
        <translation>Exportar a CSV</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="509"/>
        <source>Export succeeded.</source>
        <translation>Exportacion completada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="511"/>
        <source>Export error.
%1</source>
        <translation>error al Exportar: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="517"/>
        <source>Select a CSV File</source>
        <translation>Seleccione fichero CSV</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="517"/>
        <source>CSV Files (*csv)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="524"/>
        <source>Import completed</source>
        <translation>Importacion completa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <source>Please enter search text.</source>
        <translation>Introduzca Texto a Buscar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <source>Search Error</source>
        <translation>Error al Buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="619"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>Export Error</source>
        <translation>Error al exportar</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../src/preferencesdialog.ui" line="14"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../src/preferencesdialog.ui" line="22"/>
        <source>Database Browser Font:</source>
        <translation>buscar Fuente para la Base de Datos:</translation>
    </message>
    <message>
        <location filename="../src/preferencesdialog.ui" line="32"/>
        <location filename="../src/preferencesdialog.ui" line="56"/>
        <location filename="../src/preferencesdialog.ui" line="87"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../src/preferencesdialog.ui" line="46"/>
        <source>Table / Query Explorer Font:</source>
        <translation>Fuente del Explorador de Tabla / Consulta:</translation>
    </message>
    <message>
        <location filename="../src/preferencesdialog.ui" line="70"/>
        <source>Query Editor Font:</source>
        <translation>Fuente del Editor de Consultas:</translation>
    </message>
</context>
<context>
    <name>SelectObjectDialog</name>
    <message>
        <location filename="../src/selectobjectdialog.ui" line="14"/>
        <location filename="../src/selectobjectdialog.h" line="15"/>
        <source>Select Object</source>
        <translation>Seleccione Objecto</translation>
    </message>
    <message>
        <location filename="../src/selectobjectdialog.ui" line="22"/>
        <source>Select Table:</source>
        <translation>Seleccione Tabla:</translation>
    </message>
</context>
<context>
    <name>SqlQueryModel</name>
    <message>
        <location filename="../src/sqlmodels.cpp" line="193"/>
        <source>NULL value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/sqlmodels.cpp" line="206"/>
        <source>BLOB value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SqlTableModel</name>
    <message>
        <location filename="../src/sqlmodels.cpp" line="58"/>
        <source>NULL value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/sqlmodels.cpp" line="74"/>
        <source>BLOB value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
