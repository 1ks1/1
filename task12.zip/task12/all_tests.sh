#! /bin/bash


echo "===== START ====="> all.txt
echo " ">> all.txt
for file in `find . -type f -name "*.php"`
do
echo "===== $file =====">> all.txt
C:/php/php.exe ./phpunit-3.7.38.phar $file >> all.txt
echo "-------------------------------------------------">> all.txt
done
echo " ">> all.txt
echo "===== END =====">> all.txt
##C:/php/php.exe phpunit-3.7.38.phar StackTest.php
