<?PHP
//include('/home/user11/public_html/PHP/task1/function.php');

function getFilesList($dirpath){
    if (file_exists($dirpath) && is_dir($dirpath)) {
        $result = array();
        $cdir = scandir($dirpath); 
            foreach ($cdir as $value){
                if ($value != ".." && $value != "."){
                    echo "<br /> $value ";
                };
            } 
        return(true);    
    } 

}

getFilesList(folder);
