<?PHP
    define('folder','/home/user11/public_html/PHP/task1/files');
    define('workfolder','/home/user11/public_html/PHP/task1/');
    define('template','/home/user11/public_html/PHP/task1/template/index.php');
?>