<?php
include('/home/user11/public_html/PHP/task1/config.php');

function upload_myfile($filename){
    if (isset($_FILES['filename'])){
        $uploaddir = '/home/user11/public_html/PHP/task1/files/';
                if (move_uploaded_file($_FILES['filename']['tmp_name'], $uploaddir.
                    $_FILES["filename"]['name'])){
                     $result = true;
                } else {
                    $result = false;
                }
    }else{echo"asdasd";}
    return (true) ;
}






function del_file (){
    if (isset($__GET)){

    }
}



?>