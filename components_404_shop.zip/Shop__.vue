<template>
<div><router-link to="/">HOME</router-link><h2>{{msg}}</h2>
            <ul>
                    
                <li v-for="(item, index) in items" :key="index" >
                    <button @click="add(index)">+</button>
                        {{ item.name }} - {{ item.price }} 
                
                </li><br  />
                <li v-for="(itm, key, summ) in cart" :key="key" >
                        <button @click="remove(key)">-</button>
                            {{itm.name}}  
                    
                    </li><br />
                <span v-if="count_items > 0">Total:{{count_items}} ({{allPrice}}) UAN </span>
            </ul>
  </div>


</template>

<script>
export default {

  name: 'Shop',
  data () {
			return {
			  msg: 'SHOP'
			};
			
			cart: JSON.parse(localStorage.cart || '[]');
			
			items:[
                    { name: 'Kingston',price: 240,id: 1,count: 1 },
                    { name: 'Transsend',price: 110,id: 2,count: 1 },
                    { name: 'Sandisk',price: 90,id: 3,count: 1 },
                    { name: 'SD',price: 310,id: 4,count: 1 }
            ];
  },
  
  
  methods: {
            add: function(index) {
                console.log(this.items[index].count + '---');
                if (this.cart.indexOf(this.items[index]) === -1) {
                    this.cart.push(this.items[index]);
                }else{this.items[index].count += 1;}

                
            },
			
            remove: function(key, e) {
                    this.cart.splice(key, 1);
                }
    },
  
  computed: {
     
            allPrice: function() {
                var sum = 0;
                for (let i = 0; i < this.cart.length; i++) {
                    sum += this.cart[i].price * this.cart[i].count;
                }
                console.log(sum);
               return sum;
            },
            
            count_items: function() {
                return this.cart.length
            }
            
    },
	
    watch: {
            cart: function(newVal) {
            localStorage.cart = JSON.stringify(newVal);
            },
            //������ �� ������������� � �������
            //deep: true;
    }
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
