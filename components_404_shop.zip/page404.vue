<template>
<div>404</div>
</template>

<script>
export default {

  name: 'page404',
  data () {
			return {
			  msg: 'this 404 page'
			}
  }
  
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
