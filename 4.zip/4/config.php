<?PHP
define("USER","user11");
define("PASSWD","user11");
define("DATABASE","user11");
define("HOST","127.0.0.1");
//define("USER","root");
//define("PASSWD","usbw");
?>