<?PHP

    class pSQLquery
    {
        protected $where;
        protected $what;
        protected $db;
        protected $table;
        protected $limit;
        protected $columns;


        function __construct()
        {
        }

        public function Qvalid($fields)
        {
            if(strpos($fields, '*') === false)
            return true;
            return false;

        }

        public function select()
        {
            if($this->Qvalid($this->what))
                return "SELECT '$this->what' FROM $this->table WHERE $this->where";
                return false;
        }
        public function insert()
        {
            if($this->Qvalid($this->what))
                return "INSERT INTO $this->table SET $this->columns='$this->what'";
                return false;
        }
        public function update()
        {
            if($this->Qvalid($this->what))
                return "UPDATE $this->table SET $this->columns='$this->what' WHERE $this->where";
                return false;
        }
        public function delete()
        {
            if($this->Qvalid($this->what))
                return " DELETE FROM $this->table WHERE $this->where";
                return false;
        }
    }

    class Psql extends pSQLquery 
    {
        
        
        function __construct($db,$table,$what,$where,$limit,$columns)
        {
            $this->db = $db;
            $this->table = $table;
            $this->what = $what;
            $this->where = $where;
            $this->limit = $limit;
            $this->columns = $columns;
        }

        
        function dbConnect()
        {
            $connection_string = "host=".HOST." port=5432 dbname=".DATABASE." user=".USER." password=".PASSWD;
            $lnk = pg_connect ($connection_string);
            return $lnk;
            
        }
        


        function query($m)
        {
            switch($m)
            {
                case 's':
                $query=$this->select();
                break;
                case 'i':
                $query=$this->insert();
                break;
                case 'd':
                $query=$this->delete();
                break;
                case 'u':
                $query=$this->update();
                break;
            }

            $l = $this->dbConnect();
            if($query !== false)
            {
                if (!$l) 
                {
				    die($result ='Wrong query: ' . mysql_error());
			    }else{
                    $res = pg_query($l, $query);
                       $st = '';
                        $arr = pg_fetch_assoc($res);
                        print_r($arr);

                        foreach($arr as $key=>$v)
                        {
                            $st .= $v;
                        }

                        //fi SQL ERROR
                        $r = $st."<hr />"."<br />";
                    return $r;
                    
                }
            }else{$result = 'Error! Coz [*] is danied.';}
            return $result;
            
        }

    }
?>