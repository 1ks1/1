<?php
define('TEMPLATE', 'template/index.php');
define('MAILTO', 'vhq16977@cndps.com');