<html>
<head>
	<title>%TITLE%</title>
</head>
<body>
<div><h2>Contact Form</h2></div>
<form action="" method="POST">
<div style="color: #008; font-size: 15px;"><strong>%ERfio%</strong></div>
	<input type="text" name="fioName"  placeholder="FIO" value="%fio%" /><br /><br />
	<div style="color: #008; font-size: 15px;"><strong>%ERfrom%</strong></div>
	<input type="email" name="email_from"  placeholder="from" value="%from%" /><br /><br />
	<div style="color: #008; font-size: 15px;"><strong>%ERsel%</strong></div>
	
	<select name="mTheme" >
		<option value="option1" selected>Please Select</option>
		<option value="option2">option2</option>
		<option value="option3">option3</option>
	</select><br /><br />
	<div style="color: #008; font-size: 15px;"><strong>%ERmsg%</strong></div>
	<textarea name="message" id="" cols="30" rows="3" placeholder="email text">%mbody%</textarea><br /><br />
	<input type="submit" name="submit"  /><input type="reset" /><br />
</form>
</body>
</html>